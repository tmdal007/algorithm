package com.ssafy.attraction.model;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AttractionTypeDto {
     int attractionTypeId;
     String attractionTypeName;
}
