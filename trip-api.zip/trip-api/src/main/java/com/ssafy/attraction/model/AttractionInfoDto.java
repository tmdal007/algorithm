package com.ssafy.attraction.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AttractionInfoDto {
	private int no;
	private int contentId;
	private int contentTypeId;
	private String title;
	private String addr1;
	private String addr2;
	private String tel;
	private String firstImage1;
	private String firstImage2;
	private int sidoCode;
	private int sigunguCode;
	private double latitude;
	private double longitude;
	private String mlevel;
	private String homepage;
	private String overview;
	private boolean isLiked;
	private String userId;
}
