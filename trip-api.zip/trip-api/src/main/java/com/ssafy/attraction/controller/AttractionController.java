package com.ssafy.attraction.controller;

import java.nio.charset.Charset;
import java.util.Collections;
import java.util.List;

import com.ssafy.attraction.model.*;
import com.ssafy.like.model.LikeDto;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ssafy.attraction.model.service.AttractionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/attraction")
@CrossOrigin("*")
@Tag(name = "관광지 관련 API", description = "관광지 정보 조회 및 상세 정보 제공")
public class AttractionController {

    private final AttractionService attractionService;

    public AttractionController(AttractionService attractionService) {
        this.attractionService = attractionService;
    }

    @Operation(summary = "관광지 목록 조회", description = "조건에 맞는 관광지 목록을 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "목록 조회 성공"),
            @ApiResponse(responseCode = "204", description = "조회 결과 없음"),
            @ApiResponse(responseCode = "500", description = "서버 에러")
    })
    @PostMapping("/list")
    public ResponseEntity<?> attractionList(@RequestBody AttractionInfoDto attractionInfoDto) {
        try {
            System.out.println("Received userId: " + attractionInfoDto.getUserId()); // userId 확인
            List<AttractionInfoDto> list = attractionService.attractionList(attractionInfoDto);
//            for (int i = 0; i < list.size(); i++) {
//                System.out.println("attraction list ::: "+list.get(i).toString());
//            }
            HttpHeaders headers = createHeaders();
            if (list != null && !list.isEmpty()) {
                return ResponseEntity.ok().headers(headers).body(list != null ? list : Collections.emptyList());
            } else {
                return new ResponseEntity<>("No attractions found", HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            return exceptionHandling(e);
        }
    }


    @Operation(summary = "구군 목록 조회", description = "시도 코드에 따른 구군 목록을 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "목록 조회 성공"),
            @ApiResponse(responseCode = "204", description = "조회 결과 없음"),
            @ApiResponse(responseCode = "500", description = "서버 에러")
    })
    @GetMapping("/gugun/{selectedSido}")
    public ResponseEntity<?> gugunList(@PathVariable("selectedSido") int sidoCode) {
        try {
            List<GugunDto> list = attractionService.gugunList(sidoCode);
            System.out.println("Sido List: " + list); // 로그 추가
            HttpHeaders headers = createHeaders();
            if (list != null && !list.isEmpty()) {
                return ResponseEntity.ok().headers(headers).body(list);
            } else {
                return new ResponseEntity<>("No gugun found", HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            return exceptionHandling(e);
        }
    }

    @Operation(summary = "시도 목록 조회", description = "전체 시도의 목록을 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "목록 조회 성공"),
            @ApiResponse(responseCode = "204", description = "조회 결과 없음"),
            @ApiResponse(responseCode = "500", description = "서버 에러")
    })
    @GetMapping("/sido")
    public ResponseEntity<?> sidoList() {
        try {
            List<SidoDto> list = attractionService.sidoList();
            HttpHeaders headers = createHeaders();
            if (list != null && !list.isEmpty()) {
                return ResponseEntity.ok().headers(headers).body(list);
            } else {
                return new ResponseEntity<>("No sido found", HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            return exceptionHandling(e);
        }
    }

    @Operation(summary = "관광지 유형 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "목록 조회 성공"),
            @ApiResponse(responseCode = "204", description = "조회 결과 없음"),
            @ApiResponse(responseCode = "500", description = "서버 에러")
    })
    @GetMapping("attractionType")
    public ResponseEntity<?> attractionTypeList(){
        try {
            List<AttractionTypeDto> list=attractionService.attractionTypeList();
            HttpHeaders headers = createHeaders();
            if (list != null && !list.isEmpty()) {
                return ResponseEntity.ok().headers(headers).body(list);
            } else {
                return new ResponseEntity<>("No type found", HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            return exceptionHandling(e);
        }
    }



    @Operation(summary = "관광지 상세 조회", description = "관광지 ID를 사용하여 상세 정보를 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "상세 정보 조회 성공"),
            @ApiResponse(responseCode = "204", description = "조회 결과 없음"),
            @ApiResponse(responseCode = "500", description = "서버 에러")
    })
    @GetMapping("/getAttraction/{contentId}")
    public ResponseEntity<?> getAttraction(@PathVariable("contentId") int contentId) {
        try {
            AttractionInfoDto attractionInfoDto = attractionService.getAttraction(contentId);
            if (attractionInfoDto != null) {
                return new ResponseEntity<>(attractionInfoDto, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Attraction not found", HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            return exceptionHandling(e);
        }
    }

    @Operation(summary = "관광지 상세 조회", description = "관광지 NO를 사용하여 상세 정보를 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "상세 정보 조회 성공"),
            @ApiResponse(responseCode = "204", description = "조회 결과 없음"),
            @ApiResponse(responseCode = "500", description = "서버 에러")
    })
    @GetMapping("/getAttractionNo/{attractionNo}")
    public ResponseEntity<?> getAttractionNo(@PathVariable("attractionNo") int attractionNo) {
        try {
            AttractionInfoDto attractionInfoDto = attractionService.getAttractionNo(attractionNo);
            if (attractionInfoDto != null) {
                return new ResponseEntity<>(attractionInfoDto, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Attraction not found", HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            return exceptionHandling(e);
        }
    }


    @Operation(summary = "관광지 상세정보 조회", description = "관광지 ID를 사용하여 상세 정보를 가져옵니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "상세 정보 조회 성공"),
            @ApiResponse(responseCode = "204", description = "조회 결과 없음"),
            @ApiResponse(responseCode = "500", description = "서버 에러")
    })
    @GetMapping("/getOverview/{contentId}")
    public ResponseEntity<?> getOverview(@PathVariable("contentId") int contentId) {
        try {
            AttractionDescriptionDto attractionDescriptionDto = attractionService.getOverview(contentId);
            if (attractionDescriptionDto != null) {
                return new ResponseEntity<>(attractionDescriptionDto, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Overview not found", HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            return exceptionHandling(e);
        }
    }

    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(new MediaType("application", "json", Charset.forName("UTF-8")));
        return headers;
    }

    private ResponseEntity<String> exceptionHandling(Exception e) {
        log.error("Exception: ", e);
        return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
