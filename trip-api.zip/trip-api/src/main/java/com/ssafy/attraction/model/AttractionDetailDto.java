package com.ssafy.attraction.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AttractionDetailDto {

    private int no;                 // a.no
    private int contentId;          // a.content_id
    private int contentTypeId;      // a.content_type_id
    private String title;           // a.title
    private String addr1;           // a.addr1
    private String addr2;           // a.addr2
    private String tel;             // a.tel
    private String firstImage1;     // a.first_image1
    private String firstImage2;     // a.first_image2
    private int areaCode;           // a.area_code
    private int siGunGuCode;        // a.si_gun_gu_code
    private double latitude;        // a.latitude
    private double longitude;       // a.longitude
    private int mapLevel;           // a.map_level
    private String time;            // ap.time
    private int orderNo;			// ap.order_no
}
