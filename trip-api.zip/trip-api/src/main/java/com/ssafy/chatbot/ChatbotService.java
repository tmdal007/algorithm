package com.ssafy.chatbot;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ChatbotService {

    @Value("${openai.api.key}")
    private String apiKey;

    public String getChatbotResponse(String userMessage) {
        String apiUrl = "https://chatgpt.com/g/g-67441231a440819188c483494182e52f-myujig-teuraebeul-gaideu";

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + "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");
        headers.set("Content-Type", "application/json");

        Map<String, Object> body = new HashMap<>();
        body.put("model", "gpt-4o-mini");
        body.put("messages", new Object[] { Map.of("role", "user", "content", userMessage) });

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

        try {
            System.out.println("Sending request to OpenAI API with body: " + body);
            ResponseEntity<Map> response = restTemplate.exchange(apiUrl, HttpMethod.POST, request, Map.class);
            System.out.println("OpenAI API response: " + response.getBody());
            Map responseBody = response.getBody();

            if (responseBody != null && responseBody.containsKey("choices")) {
                List<Map> choices = (List<Map>) responseBody.get("choices");
                if (!choices.isEmpty()) {
                    Map firstChoice = choices.get(0);
                    Map message = (Map) firstChoice.get("message");
                    return (String) message.get("content");
                }
            }
            return "No response from the chatbot.";
        } catch (Exception e) {
            e.printStackTrace(); // 콘솔에 예외 출력
            return "Error occurred while communicating with the chatbot API: " + e.getMessage();
        }
    }


}
