package com.ssafy.plan.model.service;

import com.ssafy.attraction.model.AttractionDetailDto;
import com.ssafy.attraction.model.AttractionInfoDto;
import com.ssafy.plan.model.AttractionDto;
import com.ssafy.plan.model.DayPlanDto;
import com.ssafy.plan.model.PlanDto;
import com.ssafy.plan.model.mapper.PlanMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
public class PlanServiceImpl implements PlanService {

    private final PlanMapper planMapper;

    public PlanServiceImpl(PlanMapper planMapper) {
        this.planMapper = planMapper;
    }

    @Transactional
    @Override
    public void createPlan(PlanDto planDto, List<DayPlanDto> dayPlans) {
        planMapper.insertPlan(planDto);
        for (DayPlanDto dayPlan : dayPlans) {
            dayPlan.setPlanNo(planDto.getPlanNo());
            planMapper.insertDayPlan(dayPlan);
            for (AttractionDto attraction : dayPlan.getAttractions()) {
                attraction.setDayPlanNo(dayPlan.getDayPlanNo());
//                log.info("플랜 생성 시 관광지 정보요!!!! : "+ String.valueOf(attraction));
                planMapper.insertAttraction(attraction);
            }
        }
    }

    @Transactional
    @Override
    public void updatePlan(PlanDto planDto, List<DayPlanDto> dayPlans) {
        planMapper.updatePlan(planDto);
        planMapper.deleteDayPlans(planDto.getPlanNo());
        for (DayPlanDto dayPlan : dayPlans) {
            dayPlan.setPlanNo(planDto.getPlanNo());
            planMapper.insertDayPlan(dayPlan);
            for (AttractionDto attraction : dayPlan.getAttractions()) {
                attraction.setDayPlanNo(dayPlan.getDayPlanNo());
                planMapper.insertAttraction(attraction);
            }
        }
    }
    
    // 삭제 수정 - plan 삭제!
    @Transactional
    @Override
    public void deletePlan(int planNo) {
        // 1. 연관된 attraction_plan 삭제
        List<Integer> dayPlanNos = planMapper.selectDayPlanNos(planNo);
        for (int dayPlanNo : dayPlanNos) {
        	planMapper.deleteAttractions(dayPlanNo);
        }

        // 2. 연관된 day_plan 삭제
        planMapper.deleteDayPlans(planNo);

        // 3. 최종적으로 plan 삭제
        planMapper.deletePlan(planNo);
    }

    @Override
    public PlanDto getPlan(int planNo) {
        return planMapper.selectPlan(planNo);
    }

    @Override
    public List<PlanDto> getAllPlans() {
        return planMapper.selectAllPlans();
    }

    @Override
    public void addDayPlan(DayPlanDto dayPlanDto) {
        planMapper.insertDayPlan(dayPlanDto);
    }

    @Override
    public void deleteDayPlan(int dayPlanNo) {
        planMapper.deleteAttractions(dayPlanNo);
        planMapper.deleteDayPlan(dayPlanNo);
    }
    // 하루 일정과 관광지 데이터를 함께 가져오는 경우
    @Override
    public List<DayPlanDto> getDayPlans(int planNo) {
        return planMapper.selectDayPlans(planNo);
    }

    @Override
    public void addAttraction(AttractionDto attractionDto) {
        planMapper.insertAttraction(attractionDto);
    }

    @Override
    public void deleteAttraction(int dayPlanNo, int attractionNo) {
        planMapper.deleteAttraction(dayPlanNo, attractionNo);
    }

    @Override
    public List<AttractionDto> getAttractions(int dayPlanNo) {
        return planMapper.selectAttractions(dayPlanNo);
    }
    // attraction_plan time 수정
    @Override
    public void updateAttractionTime(int dayPlanNo, int attractionNo, String time) {
    	planMapper.updateAttractionTime(dayPlanNo, attractionNo, time);
    }
    // attraction_plan order_no 순서 수정
	@Override
	public void updateAttractionsOrder(int dayPlanNo, List<AttractionDto> attractions) {
		planMapper.updateAttractionsOrder(dayPlanNo, attractions);		
	}

    @Override
    public int getMaxPlanNo(String userId) {
        return planMapper.selectMaxPlanNo(userId);
    }
    
    // 사용자의 여행 계획 가져오기
    @Override
    public List<PlanDto> getUserPlans(String userId) {
        return planMapper.selectUserPlans(userId); // PlanDto 리스트 반환
    }

	@Override
	public List<AttractionDetailDto> getAttractionInfo(int dayPlanNo) {
		return planMapper.selectAttractionInfo(dayPlanNo);
	}

}
