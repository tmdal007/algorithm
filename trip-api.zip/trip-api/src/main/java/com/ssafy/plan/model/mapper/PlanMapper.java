package com.ssafy.plan.model.mapper;

import com.ssafy.attraction.model.AttractionDetailDto;
import com.ssafy.attraction.model.AttractionInfoDto;
import com.ssafy.plan.model.AttractionDto;
import com.ssafy.plan.model.DayPlanDto;
import com.ssafy.plan.model.PlanDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PlanMapper {

    // 여행 계획 관련
    void insertPlan(PlanDto planDto);
    void updatePlan(PlanDto planDto);
    void deletePlan(int planNo);
    PlanDto selectPlan(int planNo);
    List<PlanDto> selectAllPlans();

    // 하루 일정 관련
    void insertDayPlan(DayPlanDto dayPlanDto);
    void deleteDayPlan(int dayPlanNo);
    void deleteDayPlans(int planNo);
    List<DayPlanDto> selectDayPlans(int planNo);

    // 관광지 관련
    void insertAttraction(AttractionDto attractionDto);
    void deleteAttraction(int dayPlanNo, int attractionNo);
    void deleteAttractions(int dayPlanNo);
    List<AttractionDto> selectAttractions(int dayPlanNo);
    void updateAttractionTime(@Param("dayPlanNo") int dayPlanNo, 
            @Param("attractionNo") int attractionNo, 
            @Param("time") String time);
    void updateAttractionsOrder(@Param("dayPlanNo") int dayPlanNo,
            @Param("attractions") List<AttractionDto> attractions);
    

    // 사용자 관련
    int selectMaxPlanNo(String userId);
    List<PlanDto> selectUserPlans(String userId);
    
    // dayPlan attraction 정보 가져오기
    List<AttractionDetailDto> selectAttractionInfo(int dayPlanNo); // 특정 하루 일정의 관광지 정보 가져오기
	List<Integer> selectDayPlanNos(int planNo);
}
