package com.ssafy.plan.controller;

import com.ssafy.attraction.model.AttractionDetailDto;
import com.ssafy.attraction.model.AttractionInfoDto;
import com.ssafy.plan.model.AttractionDto;
import com.ssafy.plan.model.DayPlanDto;
import com.ssafy.plan.model.PlanDto;
import com.ssafy.plan.model.PlanRequestDto;
import com.ssafy.plan.model.service.PlanService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/plans")
public class PlanController {

    private final PlanService planService;

    public PlanController(PlanService planService) {
        this.planService = planService;
    }

//    // 여행 계획 생성
//    @PostMapping
//    public ResponseEntity<?> createPlan(@RequestBody PlanDto planDto, @RequestBody List<DayPlanDto> dayPlans) {
//        try {
//        	System.out.println("여행 플랜 !  ----  "+planDto);
//        	System.out.println("day 플랜 !  ----  "+dayPlans);
//            planService.createPlan(planDto, dayPlans);
//            return new ResponseEntity<>("여행 일정 생성 성공", HttpStatus.CREATED);
//        } catch (Exception e) {
//            log.error("여행 일정 생성 실패: ", e);
//            return new ResponseEntity<>("여행 일정 생성 실패", HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }

    // 여행 계획 생성
    @PostMapping
    public ResponseEntity<?> createPlan(@RequestBody PlanRequestDto planRequestDto) {
        try {
            log.info("Plan Request: {}", planRequestDto);
            PlanDto planDto = planRequestDto.getPlanDto();
            List<DayPlanDto> dayPlans = planRequestDto.getDayPlans();

            planService.createPlan(planDto, dayPlans);
            return new ResponseEntity<>("여행 일정 생성 성공", HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("여행 일정 생성 실패: ", e);
            return new ResponseEntity<>("여행 일정 생성 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 여행 계획 수정
    @PutMapping("/{planNo}")
    public ResponseEntity<?> updatePlan(@PathVariable int planNo, @RequestBody PlanDto planDto, @RequestBody List<DayPlanDto> dayPlans) {
        try {
            planDto.setPlanNo(planNo);
            planService.updatePlan(planDto, dayPlans);
            return ResponseEntity.ok("여행 일정 수정 성공");
        } catch (Exception e) {
            log.error("여행 일정 수정 실패: ", e);
            return new ResponseEntity<>("여행 일정 수정 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 여행 계획 삭제
    @DeleteMapping("/{planNo}")
    public ResponseEntity<?> deletePlan(@PathVariable int planNo) {
        try {
            planService.deletePlan(planNo);
            return ResponseEntity.ok("여행 일정 삭제 성공");
        } catch (Exception e) {
            log.error("여행 일정 삭제 실패: ", e);
            return new ResponseEntity<>("여행 일정 삭제 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 특정 여행 계획 조회
    @GetMapping("/{planNo}")
    public ResponseEntity<PlanDto> getPlan(@PathVariable int planNo) {
        try {
            PlanDto plan = planService.getPlan(planNo);
            return ResponseEntity.ok(plan);
        } catch (Exception e) {
            log.error("여행 일정 조회 실패: ", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 전체 여행 계획 조회
    @GetMapping
    public ResponseEntity<List<PlanDto>> getAllPlans() {
        try {
            List<PlanDto> plans = planService.getAllPlans();
            return ResponseEntity.ok(plans);
        } catch (Exception e) {
            log.error("전체 여행 일정 조회 실패: ", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 특정 여행 계획의 하루 일정 조회 - !!
    @GetMapping("/{planNo}/day-plans")
    public ResponseEntity<List<DayPlanDto>> getDayPlans(@PathVariable int planNo) {
        try {
            List<DayPlanDto> dayPlans = planService.getDayPlans(planNo);
            return ResponseEntity.ok(dayPlans);
        } catch (Exception e) {
            log.error("하루 일정 조회 실패: ", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 특정 하루 일정의 관광지 정보 가져오기
    @GetMapping("/day-plan/{dayPlanNo}/attractions")
    public ResponseEntity<List<AttractionDetailDto>> getAttractionInfo(@PathVariable int dayPlanNo) {
        try {
            List<AttractionDetailDto> attractions = planService.getAttractionInfo(dayPlanNo);
            if (attractions == null || attractions.isEmpty()) {
                log.info("관광지 데이터가 없습니다. DayPlanNo: {}", dayPlanNo);
                return ResponseEntity.ok(Collections.emptyList());
            }
            log.info("하루 일정 관광지 정보: {}", attractions);
            return ResponseEntity.ok(attractions);
        } catch (Exception e) {
            log.error("하루 일정 관광지 정보 조회 중 에러 발생: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
    // attraction_plan time 수정
    @PutMapping("/{dayPlanNo}/{attractionNo}/time")
    public String updateAttractionTime(@PathVariable int dayPlanNo, @PathVariable int attractionNo,@RequestParam String time) {
    	planService.updateAttractionTime(dayPlanNo, attractionNo, time);
        return "Attraction time updated successfully.";
    }
    
    // attraction_plan 순서 관리(order_no update)
    @PutMapping("/day-plan/{dayPlanNo}/attractions/order")
    public ResponseEntity<Void> updateAttractionsOrder(
            @PathVariable int dayPlanNo,
            @RequestBody List<AttractionDto> attractions) {
    	planService.updateAttractionsOrder(dayPlanNo, attractions);
        return ResponseEntity.ok().build();
    }

    

    // 특정 사용자의 최대 여행 계획 번호 조회
    @GetMapping("/max-plan/{userId}")
    public ResponseEntity<Integer> getMaxPlanNo(@PathVariable String userId) {
        try {
            int maxPlanNo = planService.getMaxPlanNo(userId);
            return ResponseEntity.ok(maxPlanNo);
        } catch (Exception e) {
            log.error("최대 여행 계획 번호 조회 실패: ", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 특정 사용자의 모든 여행 계획 번호 조회
    @GetMapping("/user-plans/{userId}")
    public ResponseEntity<List<PlanDto>> getUserPlans(@PathVariable String userId) {
        try {
            List<PlanDto> userPlans = planService.getUserPlans(userId);
            return ResponseEntity.ok(userPlans);
        } catch (Exception e) {
            log.error("사용자 여행 계획 번호 조회 실패: ", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 하루 일정 추가
    @PostMapping("/{planNo}/day-plans")
    public ResponseEntity<?> addDayPlan(@PathVariable int planNo, @RequestBody DayPlanDto dayPlanDto) {
        try {
            dayPlanDto.setPlanNo(planNo);
            planService.addDayPlan(dayPlanDto);
            return new ResponseEntity<>("하루 일정 추가 성공", HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("하루 일정 추가 실패: ", e);
            return new ResponseEntity<>("하루 일정 추가 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 관광지 추가
    @PostMapping("/day-plan/{dayPlanNo}/attractions")
    public ResponseEntity<?> addAttraction(@PathVariable int dayPlanNo, @RequestBody AttractionDto attractionDto) {
        try {
            attractionDto.setDayPlanNo(dayPlanNo);
            planService.addAttraction(attractionDto);
            return new ResponseEntity<>("관광지 추가 성공", HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("관광지 추가 실패: ", e);
            return new ResponseEntity<>("관광지 추가 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 하루 일정 삭제
    @DeleteMapping("/day-plan/{dayPlanNo}")
    public ResponseEntity<?> deleteDayPlan(@PathVariable int dayPlanNo) {
        try {
            planService.deleteDayPlan(dayPlanNo);
            return ResponseEntity.ok("하루 일정 삭제 성공");
        } catch (Exception e) {
            log.error("하루 일정 삭제 실패: ", e);
            return new ResponseEntity<>("하루 일정 삭제 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 관광지 삭제
    @DeleteMapping("/day-plan/{dayPlanNo}/attractions/{attractionNo}")
    public ResponseEntity<?> deleteAttraction(@PathVariable int dayPlanNo, @PathVariable int attractionNo) {
        try {
            planService.deleteAttraction(dayPlanNo, attractionNo);
            return ResponseEntity.ok("관광지 삭제 성공");
        } catch (Exception e) {
            log.error("관광지 삭제 실패: ", e);
            return new ResponseEntity<>("관광지 삭제 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
