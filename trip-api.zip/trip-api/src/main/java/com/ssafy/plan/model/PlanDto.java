package com.ssafy.plan.model;

import java.sql.Date;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PlanDto {
	private int planNo;
	private String planName;
	private Date startDate;
	private Date endDate;
	private String userId;
}
