package com.ssafy.post.controller;

import com.ssafy.post.model.PostDto;
import com.ssafy.post.model.service.PostService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/posts")
@Tag(name = "PostController", description = "여행 일정 후기 관리 API")
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @Operation(summary = "후기 생성", description = "새로운 후기를 작성합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "후기 작성 성공"),
            @ApiResponse(responseCode = "400", description = "잘못된 요청")
    })
    @PostMapping
    public ResponseEntity<?> createPost(@RequestBody PostDto postDto) {
        postService.createPost(postDto);
        return new ResponseEntity<>("후기 작성 성공", HttpStatus.CREATED);
    }

    @Operation(summary = "후기 조회", description = "특정 후기를 조회합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "후기 조회 성공"),
            @ApiResponse(responseCode = "404", description = "후기 없음")
    })
    @GetMapping("/{postNo}")
    public ResponseEntity<?> getPost(@PathVariable int postNo) {
        PostDto post = postService.getPost(postNo);
        if (post != null) {
            return ResponseEntity.ok(post);
        }
        return new ResponseEntity<>("후기를 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
    }

    @Operation(summary = "특정 일정의 후기 목록 조회", description = "특정 여행 일정의 모든 후기를 조회합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "후기 목록 조회 성공")
    })
    @GetMapping("/plan/{planNo}")
    public ResponseEntity<List<PostDto>> getPostsByPlan(@PathVariable int planNo) {
        List<PostDto> posts = postService.getPostsByPlan(planNo);
        return ResponseEntity.ok(posts);
    }

    @Operation(summary = "후기 수정", description = "특정 후기를 수정합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "후기 수정 성공"),
            @ApiResponse(responseCode = "400", description = "잘못된 요청")
    })
    @PutMapping("/{postNo}")
    public ResponseEntity<?> updatePost(@PathVariable int postNo, @RequestBody PostDto postDto) {
        postDto.setPostNo(postNo);
        postService.updatePost(postDto);
        return ResponseEntity.ok("후기 수정 성공");
    }

    @Operation(summary = "후기 삭제", description = "특정 후기를 삭제합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "후기 삭제 성공"),
            @ApiResponse(responseCode = "404", description = "후기 없음")
    })
    @DeleteMapping("/{postNo}")
    public ResponseEntity<?> deletePost(@PathVariable int postNo) {
        postService.deletePost(postNo);
        return ResponseEntity.ok("후기 삭제 성공");
    }
}
