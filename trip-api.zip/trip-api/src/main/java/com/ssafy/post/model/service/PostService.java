package com.ssafy.post.model.service;

import com.ssafy.post.model.PostDto;

import java.util.List;

public interface PostService {
    void createPost(PostDto postDto); // C
    PostDto getPost(int postNo); // R
    List<PostDto> getPostsByPlan(int planNo); // R
    void updatePost(PostDto postDto); // U
    void deletePost(int postNo); // D
}
