package com.ssafy.post.model.service;

import com.ssafy.post.model.CommentDto;
import com.ssafy.post.model.mapper.CommentMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {

    private final CommentMapper commentMapper;

    public CommentServiceImpl(CommentMapper commentMapper) {
        this.commentMapper = commentMapper;
    }

    @Override
    public List<CommentDto> getCommentsByPost(int postNo) {
        return commentMapper.getCommentsByPost(postNo);
    }

    @Override
    public void addComment(CommentDto commentDto) {
        commentMapper.insertComment(commentDto);
    }

    @Override
    public void editComment(CommentDto commentDto) {
        commentMapper.updateComment(commentDto);
    }

    @Override
    public void removeComment(int commentNo) {
        commentMapper.deleteComment(commentNo);
    }

    @Override
    public List<CommentDto> getCommentsByUser(String userId) {
        return commentMapper.getCommentsByUser(userId);
    }

    @Override
    public String getCommentAuthor(int commentNo) {
        return commentMapper.getCommentAuthor(commentNo);
    }
}
