package com.ssafy.post.model.mapper;

import com.ssafy.post.model.PostDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PostMapper {
    void insertPost(PostDto postDto); // C - 후기 생성
    PostDto selectPost(int postNo); // R - 후기 상세 조회
    List<PostDto> selectPostsByPlan(int planNo); // R - 특정 여행 일정(plan)의 모든 후기 조회
    void updatePost(PostDto postDto); // U - 후기 수정
    void deletePost(int postNo); // D - 후기 삭제
}
