package com.ssafy.post.model;

import java.sql.Date;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PostDto {
	private int postNo;
	private int planNo;
	private String content;
	private int score;
	private int person;
	private int money;
	private Date register;
	private int hit;
}
