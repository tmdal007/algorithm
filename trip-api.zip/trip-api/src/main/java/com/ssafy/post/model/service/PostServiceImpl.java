package com.ssafy.post.model.service;

import com.ssafy.post.model.PostDto;
import com.ssafy.post.model.mapper.PostMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostServiceImpl implements PostService {

    private final PostMapper postMapper;

    public PostServiceImpl(PostMapper postMapper) {
        this.postMapper = postMapper;
    }

    @Override
    public void createPost(PostDto postDto) {
        postMapper.insertPost(postDto);
    }

    @Override
    public PostDto getPost(int postNo) {
        return postMapper.selectPost(postNo);
    }

    @Override
    public List<PostDto> getPostsByPlan(int planNo) {
        return postMapper.selectPostsByPlan(planNo);
    }

    @Override
    public void updatePost(PostDto postDto) {
        postMapper.updatePost(postDto);
    }

    @Override
    public void deletePost(int postNo) {
        postMapper.deletePost(postNo);
    }
}
