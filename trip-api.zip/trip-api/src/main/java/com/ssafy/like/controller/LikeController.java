package com.ssafy.like.controller;

import java.util.List;

import com.ssafy.attraction.model.AttractionInfoDto;
import com.ssafy.util.JWTUtil;
import jakarta.websocket.server.PathParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ssafy.like.model.DetailDto;
import com.ssafy.like.model.LikeDto;
import com.ssafy.like.model.service.LikeService;
import com.ssafy.user.model.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@Slf4j
@RestController
@RequestMapping("/like")
@Tag(name = "LikeController", description = "관광지 조회, 상세 정보 보기, 찜한 관광지 추가, 조회, 삭제 등을 처리하는 클래스")
public class LikeController {

    private final LikeService likeService;
    private final JWTUtil jwtUtil;

	public LikeController(LikeService likeService, JWTUtil jwtUtil) {
		super();
        this.likeService = likeService;
        this.jwtUtil = jwtUtil;
	}

    // Create (찜한 관광지 추가
    @Operation(summary = "찜한 관광지 추가", description = "새로운 찜한 관광지를 추가.")
    @PostMapping("/attraction")
    public ResponseEntity<String> insertAttractionLike(@RequestBody LikeDto likeDto) {
        try {
//            log.info("======");
//            log.info(likeDto.toString());
            likeService.insertLike(likeDto);
            return ResponseEntity.ok("관광지가 찜 목록에 추가되었습니다.");
        } catch (Exception e) {
            log.error("관광지 즐겨찾기 등록 실패 : {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("찜하기에 실패했습니다. 서버 오류가 발생했습니다.");
        }
    }


    // Retrieve (찜한 관광지 목록 조회)
    @Operation(summary = "찜한 관광지 목록 조회", description = "찜한 관광지 목록을 조회.")
    @GetMapping("attractionList")
    public ResponseEntity<?> getLikeList(@RequestParam("userId") String userId) {
        List<AttractionInfoDto> likeList = likeService.getLikeList(userId);
        return ResponseEntity.ok(likeList);
    }

    // 관광지 상세 조회
    @Operation(summary = "관광지 상세 정보 조회", description = "지정된 contentId에 대한 관광지 상세 정보를 조회.")
    @GetMapping("/details/{contentId}")
    public ResponseEntity<DetailDto> getLikeById(@PathVariable String contentId) {
        DetailDto detail = likeService.getLikeById(contentId);
        return detail != null ? ResponseEntity.ok(detail) : ResponseEntity.notFound().build();
    }

    // 찜한 관광지 상세 조회
    @Operation(summary = "찜한 관광지 상세 정보 조회", description = "지정된 listNo에 대한 찜한 관광지 상세 정보를 조회.")
    @GetMapping("/{listNo}")
    public ResponseEntity<LikeDto> getLikeByNo(@PathVariable int listNo) {
        LikeDto like = likeService.getLikeByNo(listNo);
        return like != null ? ResponseEntity.ok(like) : ResponseEntity.notFound().build();
    }

    // Delete (찜한 관광지 삭제)
    @Operation(summary = "찜한 관광지 삭제", description = "지정된 listNo에 대한 찜한 관광지를 삭제.")
    @DeleteMapping("/{listNo}")
    public ResponseEntity<String> deleteLike(@PathVariable int listNo) {
        int result = likeService.deleteLike(listNo);
        return result > 0 ? ResponseEntity.ok("관광지가 찜 목록에서 삭제되었습니다.") : ResponseEntity.notFound().build();
    }

    // 특정 제목의 관광지 존재 여부 확인
    @Operation(summary = "관광지 중복 확인", description = "특정 제목의 관광지가 찜한 관광지를 저장하는 데이터베이스에 존재하는지 여부 확인.")
    @GetMapping("/exists")
    public ResponseEntity<Boolean> existsByTitle(@RequestParam String title) {
        boolean exists = likeService.existsByTitle(title);
        return ResponseEntity.ok(exists);
    }

}
