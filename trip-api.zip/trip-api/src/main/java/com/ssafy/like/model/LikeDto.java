package com.ssafy.like.model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class LikeDto {
	String userId;
//	int attractionNo;
	int contentId;
	int postNo;

}

