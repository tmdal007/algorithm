package com.ssafy.notice.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ssafy.notice.model.NoticeDto;
import com.ssafy.notice.model.NoticeListDto;
import com.ssafy.notice.model.service.NoticeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/notice")
@CrossOrigin("*")
@Tag(name="NoticeController", description = "공지사항 게시글 목록과 상세보기, 등록, 수정, 삭제 등을 처리하는 클래스")
public class NoticeController {

    private final NoticeService noticeService;

    public NoticeController(NoticeService noticeService) {
        this.noticeService = noticeService;
    }

    @Operation(summary="게시글 목록 조회", description = "게시글 전체 목록을 조회.")
    @ApiResponses(value= {
        @ApiResponse(responseCode = "200", description = "목록 조회 성공"),
        @ApiResponse(responseCode = "404", description = "페이지 없음"),
        @ApiResponse(responseCode = "500", description = "서버 에러")
    })
    @GetMapping
    public ResponseEntity<?> getAllArticles(
    		@RequestParam @Parameter(description = "게시글을 얻기위한 부가정보.", required = true) Map<String, String> map) {
    	NoticeListDto articles;
		try {
			articles = noticeService.getAllArticles(map);
	        HttpHeaders header = new HttpHeaders();
			header.setContentType(new MediaType("application", "json", Charset.forName("UTF-8")));
	        return ResponseEntity.ok().headers(header).body(articles);
		} catch (SQLException e) {
			return exceptionHandling(e);
		}
    }

    @Operation(summary="게시글 작성", description = "새로운 게시글을 작성.")
    @ApiResponses(value= {
        @ApiResponse(responseCode = "201", description = "게시글 작성 성공"),
        @ApiResponse(responseCode = "400", description = "잘못된 요청")
    })
    @PostMapping
    public ResponseEntity<?> createArticle(@RequestBody NoticeDto noticeDto) {
    	noticeService.createArticle(noticeDto);
        return new ResponseEntity<Void>(HttpStatus.CREATED) ;
    }

    @Operation(summary="특정 게시글 조회", description = "게시글 ID를 사용해 특정 게시글을 조회.")
    @ApiResponses(value= {
        @ApiResponse(responseCode = "200", description = "게시글 조회 성공"),
        @ApiResponse(responseCode = "404", description = "게시글 없음")
    })
    @GetMapping("/{articleNo}")
    public ResponseEntity<NoticeDto> getArticle(@PathVariable int articleNo) {
    	noticeService.updateHit(articleNo);
        NoticeDto noticeDto = noticeService.getArticle(articleNo);
        if (noticeDto != null) {
            return new ResponseEntity<>(noticeDto, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @Operation(summary="게시글 수정", description = "게시글 ID와 수정할 데이터를 받아 게시글을 수정.")
    @ApiResponses(value= {
        @ApiResponse(responseCode = "200", description = "게시글 수정 성공"),
        @ApiResponse(responseCode = "404", description = "게시글 없음")
    })
    @PutMapping("/{articleNo}")
    public ResponseEntity<String> updateArticle(@PathVariable int articleNo, @RequestBody NoticeDto noticeDto) {
        if (noticeDto == null || noticeDto.getSubject() == null || noticeDto.getContent() == null) {
            return new ResponseEntity<>("Invalid request data", HttpStatus.BAD_REQUEST);
        }
        noticeDto.setArticleNo(articleNo);
        if (noticeService.updateArticle(noticeDto)) {
            return new ResponseEntity<>("Article updated successfully", HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    @Operation(summary="게시글 삭제", description = "게시글 ID를 사용해 특정 게시글을 삭제.")
    @ApiResponses(value= {
        @ApiResponse(responseCode = "200", description = "게시글 삭제 성공"),
        @ApiResponse(responseCode = "404", description = "게시글 없음")
    })
    @DeleteMapping("/{articleNo}")
    public ResponseEntity<String> deleteArticle(@PathVariable int articleNo) {
        if (noticeService.deleteArticle(articleNo)) {
            return ResponseEntity.ok("Article deleted successfully");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Article not found");
    }

    
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return new ResponseEntity<String>("Error : " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
