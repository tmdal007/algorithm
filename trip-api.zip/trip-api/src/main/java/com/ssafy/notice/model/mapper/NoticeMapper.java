package com.ssafy.notice.model.mapper;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.notice.model.NoticeDto;


@Mapper
public interface NoticeMapper {

	List<NoticeDto> getAllArticles(Map<String, Object> param);
	
	int getTotalArticleCount(Map<String, Object> param) throws SQLException;

	NoticeDto getArticle(int articleNo);

	void createArticle(NoticeDto boardDto);

	int updateArticle(NoticeDto boardDto);

	int deleteArticle(int articleNo);

	void updateHit(int articleNo);


}