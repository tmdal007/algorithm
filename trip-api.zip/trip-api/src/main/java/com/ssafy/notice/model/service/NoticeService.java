package com.ssafy.notice.model.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.notice.model.NoticeDto;
import com.ssafy.notice.model.NoticeListDto;

public interface NoticeService {

    // 게시글 전체 목록 조회
	NoticeListDto getAllArticles(Map<String, String> map) throws SQLException;

    // 특정 게시글 조회
    NoticeDto getArticle(int articleNo);

    // 게시글 작성
    void createArticle(NoticeDto boardDto);

    // 게시글 수정
    boolean updateArticle(NoticeDto boardDto);

    // 게시글 삭제
    boolean deleteArticle(int articleNo);

	void updateHit(int articleNo);
}
