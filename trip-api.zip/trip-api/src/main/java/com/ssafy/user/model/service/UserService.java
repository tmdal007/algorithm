package com.ssafy.user.model.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.user.model.UserDto;

public interface UserService {

//	int idCheck(String userId) throws Exception;
//	void joinMember(MemberDto memberDto) throws Exception;
//	MemberDto loginMember(Map<String, String> map) throws Exception;
	
	UserDto login(UserDto memberDto) throws Exception;
	UserDto userInfo(String userId) throws Exception;
	void saveRefreshToken(String userId, String refreshToken) throws Exception;
	Object getRefreshToken(String userId) throws Exception;
	void deleRefreshToken(String userId) throws Exception;
	
	/* Admin */
	List<UserDto> listMember(Map<String, Object> map) throws Exception;
	UserDto getMember(String userId) throws Exception;
	void updateMember(UserDto memberDto) throws Exception;
	void deleteMember(String userid) throws Exception;
	
	
	boolean isIdDuplicate(String userId);
	boolean register(UserDto memberDto);
	
	boolean updateUserField(String userId, String currentPassword, String newPassword) throws Exception;
	boolean updateEmail(String userId, String emailId, String emailDomain);
	
	//회원 탈퇴
	boolean withdrawMember(String userId, String password) throws SQLException;
}
