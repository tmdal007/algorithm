<script setup>
import { ref, computed, onMounted } from "vue";

const selAreas = ref([
  { name: "서울", code: "1168064000", weathers: [] },
  { name: "경기", code: "4111353000", weathers: [] },
  { name: "대전", code: "3020052600", weathers: [] },
  { name: "광주", code: "2915573000", weathers: [] },
  { name: "부산", code: "2611057000", weathers: [] },
  { name: "강원", code: "4277025300", weathers: [] },
  { name: "제주", code: "5013031000", weathers: [] },
]);
onMounted(async () => {
  for (const area of selAreas.value) {
    await getWeather(area);
  }
});

const getWeather = async (area) => {
  try {
    const response = await fetch(
      `/kma-api/wid/queryDFSRSS.jsp?zone=${area.code}`
    );
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.text();
    makeList(data, area);
  } catch (error) {
    console.error(`${area.name} 날씨 데이터 조회 실패:`, error);
    area.weathers = [{ error: true, message: '날씨 정보를 불러올 수 없습니다.' }];
  }
};
const makeList = (data, area) => {
  let parser = new DOMParser();
  const xml = parser.parseFromString(data, "application/xml");
  let datas = xml.querySelectorAll("data");
  datas.forEach((weather) => {
    let obj = new Object();
    obj.hour = weather.querySelector("hour").textContent;
    obj.icon = weather.querySelector("wfEn").textContent;
    obj.temp = weather.querySelector("temp").textContent;
    obj.wfKor = weather.querySelector("wfKor").textContent;
    obj.reh = weather.querySelector("reh").textContent;
    area.weathers.push(obj);
  });
};

const filteredAreas = computed(() => {
  return selAreas.value.filter((area) => area.weathers.length > 0);
});
</script>

<template>
  <div id="current-weather-div">
    <h2 id="current-weather" class="weather-title"><b></b></h2>
    <table id="current-weather-table">
      <tr style="font-family: 'Pretendard-Regular', sans-serif">
        <td v-for="(area, index) in filteredAreas" :key="index" class="weather-card">
          <template v-if="area.weathers[0]?.error">
            <h2>{{ area.name }}</h2>
            <div class="error-message">{{ area.weathers[0].message }}</div>
          </template>
          <template v-else-if="area.weathers.length > 0">
            <h2>{{ area.name }}</h2>
            <div>
              <img
                class="w-img"
                :src="`./src/assets/${area.weathers[0].icon.replace('/', '_')}.png`"
                alt=""
              />
            </div>
            <div>{{ area.weathers[0].temp }}°C</div>
            <div>{{ area.weathers[0].wfKor }}</div>
            <div>{{ area.weathers[0].reh }}%</div>
          </template>
        </td>
      </tr>
    </table>
  </div>
</template>

<style scoped>
/* 기존 스타일 */
.error-message {
  color: #ff4444;
  padding: 10px;
  margin: 10px 0;
  font-size: 0.9em;
}

@font-face {
  font-family: "Pretendard-Regular";
  src: url("https://cdn.jsdelivr.net/gh/Project-Noonnu/noonfonts_2107@1.1/Pretendard-Regular.woff")
    format("woff");
  font-weight: 400;
  font-style: normal;
}
template {
  font-family: "Pretendard-Regular, sans-serif";
}
.weather-title {
  margin-top: 30px;
}
template {
  font-family: "Pretendard-Regular", sans-serif;
}

#current-weather-table {
  margin-left: auto;
  margin-right: auto;
  width: 90%;
  border-collapse: collapse;
  margin-top: 20px;
}
tr,
td {
  text-align: center;
}
th {
  border-bottom: 2px solid darkgray;
}
.w-img {
  width: 80px;
}
#current-weather {
  width: 83%;
  margin-right: 10px;
}
#current-weather-div {
  width: 83%;
  margin: 10px;
}

/* 추가된 스타일 */
.weather-card {
  padding: 10px;
  border: 1px solid #ddd; /* 경계선 */
  border-radius: 8px; /* 둥근 모서리 */
  transition: box-shadow 0.3s ease; /* 부드러운 애니메이션 */
}
.weather-card:hover {
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2); /* 그림자 */
  transform: scale(1.02); /* 살짝 확대 */
}
</style>
