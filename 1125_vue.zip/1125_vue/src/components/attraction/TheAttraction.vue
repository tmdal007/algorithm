<script setup>
import VKakaoMap from "@/components/attraction/VKakaoMap.vue";
import { ref, watch, onMounted } from "vue";
import { sidoList, gugunList,attractionTypeList, attractionListJs } from "@/api/attraction.js";
import noImage from "@/assets/no_image.jpg";

// 이벤트 정의
const emit = defineEmits(["select-attraction"]);

const attraction = ref({
  sidoCode: 0,
  sigunguCode: 0,
  contentTypeId: 0,
  title: "",
});

const sido = ref([]);
const gugun = ref([]);
const trips = ref([]);
const attractions = ref([]);

// 지역(시도) 정보 가져오기
const fetchSido = () => {
  sidoList(
    ({ data }) => {
      sido.value = data;
    },
    (error) => {
      console.error("Error fetching sido:", error);
    }
  );
};

// 구군 목록 가져오기
watch(
  () => attraction.value.sidoCode,
  (newValue) => {
    if (newValue !== 0) {
      gugunList(
        newValue,
        ({ data }) => {
          gugun.value = data;
        },
        (error) => {
          console.error("Error fetching gugun:", error);
        }
      );
    }
  }
);

// 관광지 타입 가져오기
const searchTrips = async () => {
  attractionTypeList(response => { 
    const data=response.data;
    trips.value=data;
  }, error => {
    console.error('Error fetching areas:', error);
  })
};


onMounted(() => {
  fetchSido();
  searchTrips();
});

// 관광지 검색
const searchAttraction = () => {
  attractionListJs(
    attraction.value,
    ({ data }) => {
      console.log("관광지 정보 검색시 : !!",attraction);
      attractions.value = data;
    },
    (error) => {
      console.error("Error fetching attractions:", error);
    }
  );
};

// 선택된 관광지를 부모로 emit
const emitAttraction = (attraction) => {
  emit("select-attraction", attraction);
};

// 지도와 관련된 상태 및 함수
const selectAttraction = ref(null); // 선택된 관광지 정보
const viewAttraction = (attraction) => {
  selectAttraction.value = attraction; // 선택된 관광지 정보 저장
};

// 마커 클릭 시 부모로 contentId 전달
const contentId = ref(0);
const addPlan = (markerContentId) => {
  contentId.value = markerContentId;
  console.log("마커 클릭 이벤트 발생, 전달된 contentId:", markerContentId);
};
</script>

<template>
  <div class="container">
    <!-- <h4 class="fw-bold">관광지 검색</h4> -->

    <!-- 검색 폼 -->
    <form class="d-flex my-3" @submit.prevent="searchAttraction">
      <select v-model="attraction.sidoCode" class="form-select me-2">
        <option value="0">시도 선택</option>
        <option v-for="si in sido" :key="si.sidoCode" :value="si.sidoCode">
          {{ si.sidoName }}
        </option>
      </select>

      <select v-model="attraction.sigunguCode" class="form-select me-2">
        <option value="0">구군 선택</option>
        <option v-for="gu in gugun" :key="gu.gugunCode" :value="gu.gugunCode">
          {{ gu.gugunName }}
        </option>
      </select>

      <select v-model="attraction.contentTypeId" class="form-select me-2">
          <option value="0">관광지 유형</option>
          <option v-for="type in trips" :key="type.attrationTypeId" :value="type.attractionTypeId">
            {{ type.attractionTypeName }}
          </option>
        </select>

      <input
        v-model="attraction.title"
        class="form-control me-2"
        type="text"
        placeholder="검색어"
      />
      <button class="btn btn-outline-success" type="submit">검색</button>
    </form>

    <!-- 카카오 지도 -->
    <VKakaoMap
      :attractions="attractions"
      :selectAttraction="selectAttraction"
      @addPlan="addPlan"
    />

    <!-- 관광지 리스트 -->
    <div class="attractions-container mt-3">
      <div v-if="attractions.length > 0" class="row flex-nowrap px-3" style="overflow-x: auto;">
        <div v-for="attraction in attractions" :key="attraction.contentId" class="col-auto">
          <div
            class="card attraction-card"
            style="width: 200px;"
            @click="emitAttraction(attraction); viewAttraction(attraction)"
          >
            <img
              :src="attraction.firstImage1 || noImage"
              class="card-img-top"
              :alt="attraction.title"
              style="height: 200px; object-fit: cover;"
            />
            <div class="card-body">
              <h5 class="card-title text-truncate">{{ attraction.title }}</h5>
            </div>
          </div>
        </div>
      </div>
      <p v-else>검색 결과가 없습니다.</p>
    </div>
  </div>
</template>

<style scoped>
.attractions-container {
  -webkit-overflow-scrolling: touch;
  scrollbar-width: thin;
  scrollbar-color: rgba(0, 0, 0, 0.2) transparent;
}

.attractions-container::-webkit-scrollbar {
  height: 8px;
}

.attractions-container::-webkit-scrollbar-thumb {
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 4px;
}

.attraction-card {
  transition: transform 0.2s;
  cursor: pointer;
}

.attraction-card:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.container {
  padding: 0px 20px 20px 20px;
}

h4 {
  font-size: 24px;
  color: #333;
  margin-bottom: 15px;
}
</style>
