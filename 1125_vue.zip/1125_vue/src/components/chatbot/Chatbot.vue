<script>
import { localAxios } from "@/util/http-commons";

const local = localAxios();

export default {
  data() {
  return {
      userMessage: "",
      messages: [],
      isLoading: false
  };
  },
  methods: {
      async sendMessage() {
          if (!this.userMessage.trim()) {
              console.error("User message is empty.");
              return;
          }

          this.messages.push({ role: "user", content: this.userMessage });
          this.isLoading = true;

          try {
              const response = await local.post("/api/chat", {
              message: this.userMessage
              });

              this.messages.push({ role: "bot", content: response.data });
          } catch (error) {
              console.error("Error fetching chatbot response:", error);
              this.messages.push({
              role: "bot",
              content: "Sorry, there was an error."
              });
          } finally {
              this.userMessage = "";
              this.isLoading = false;
          }
      }

  }
};
</script>

<template>
    <div id="chatbot">
      <div id="messages">
        <div v-for="(message, index) in messages" :key="index" class="message">
          <strong>{{ message.role === 'user' ? 'You:' : 'Bot:' }}</strong>
          <p>{{ message.content }}</p>
        </div>
      </div>
      <input
        type="text"
        v-model="userMessage"
        @keyup.enter="sendMessage"
        placeholder="Type your message here..."
      />
      <button @click="sendMessage">Send</button>
    </div>
</template>
  
  
  <style>
  #chatbot {
      border: 1px solid #ccc;
      padding: 10px;
      width: 400px;
      height: 500px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
  }
  #messages {
      flex-grow: 1;
      overflow-y: auto;
  }
  .message {
      margin-bottom: 10px;
  }
  </style>
  