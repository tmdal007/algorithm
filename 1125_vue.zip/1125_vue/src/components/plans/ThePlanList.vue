<!--ThePlanList.vue-->
<script setup>
import { ref, onMounted, watch } from "vue";
import { getUserPlans, deletePlan } from "@/api/myplan.js";
import { useMemberStore } from "@/stores/member";

const memberStore = useMemberStore();
const userId = ref("");
const plans = ref([]);
const emit = defineEmits(['selectPlan']);

const loadUserInfo = async () => {
  const token = sessionStorage.getItem("accessToken");
  if (token) {
    try {
      await memberStore.getUserInfo(token);
      if (memberStore.userInfo) {
        userId.value = memberStore.userInfo.userId || "";
      }
    } catch (error) {
      console.error("사용자 정보 로드 실패:", error);
    }
  }
};

const loadPlans = () => {
  if (!userId.value) {
    console.error("사용자 ID가 없습니다.");
    return;
  }
  getUserPlans(
    userId.value,
    (response) => {
      plans.value = response.data;
    },
    (error) => {
      console.error("사용자 여행 계획 로드 실패:", error);
    }
  );
};

const handleDeletePlan = (planNo, event) => {
  event.stopPropagation(); // 이벤트 버블링 방지
  if (confirm('정말로 이 여행 계획을 삭제하시겠습니까?')) {
    deletePlan(
      planNo,
      () => {
        alert('여행 계획 삭제 완료!');
        loadPlans(); // 목록 새로고침
      },
      (error) => {
        console.error('여행 계획 삭제 실패:', error);
        alert('여행 계획 삭제에 실패했습니다.');
      }
    );
  }
};

onMounted(async () => {
  await loadUserInfo();
  loadPlans();
});
</script>

<template>
  <div>
    <div class="plan-list">
      <div
        v-for="plan in plans"
        :key="plan.planNo"
        class="plan-card"
      >
        <div class="plan-content" @click="$emit('selectPlan', plan.planNo)">
          <h5>{{ plan.planName }}</h5>
          <span>{{ plan.startDate }} ~ {{ plan.endDate }}</span>
        </div>
        <button 
          @click="(e) => handleDeletePlan(plan.planNo, e)"
          class="delete-btn"
        >
          삭제
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.plan-list {
  display: flex;
  gap: 20px;
  overflow-x: auto;
  padding: 20px 0;
}

.plan-card {
  min-width: 250px;
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.plan-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.plan-card.selected {
  border-color: #4CAF50;
  box-shadow: 0 4px 12px rgba(76,175,80,0.2);
}

.plan-content {
  margin-bottom: 15px;
}

.plan-content h5 {
  margin: 0 0 8px 0;
  font-size: 1.2em;
  color: #333;
}

.plan-content span {
  color: #666;
  font-size: 0.9em;
}

.delete-btn {
  width: 70px;
  height: 40px;
  background-color: #973131;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.delete-btn:hover {
  background-color: #cc0000;
}
</style>