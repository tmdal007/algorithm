<script setup>
import { ref, onMounted,computed } from "vue";
import { createPlan, getMaxPlanNo } from "@/api/myplan";
import { useMemberStore } from "@/stores/member";

const memberStore = useMemberStore();

const props = defineProps({
  dayPlans: Array, // 부모로부터 전달된 dayPlans
  selectedDayIndex: Number, // 부모로부터 전달된 선택된 일차
});

const emit = defineEmits(['select-day', 'generate-plans']);

const info = ref({
  planTitle: "",
  startDay: "",
  endDay: "",
});

// 일정 생성 (부모로 이벤트 전송)
const generateDayPlans = () => {
  if (info.value.startDay && info.value.endDay) {
    emit('generate-plans', info.value.startDay, info.value.endDay);
  }
};

// 일정 선택 (부모로 선택된 일차 전달)
const selectDay = (index) => {
  emit('select-day', index);
};

// 관광지 제거
const removeAttraction = (dayIndex, attractionIndex) => {
  props.dayPlans[dayIndex].attractions.splice(attractionIndex, 1);
};

const num = ref(0); // 사용자가 작성하는 계획

// userId를 ref로 정의
const userId = ref("");

// onMounted에서 userId 값을 할당
onMounted(() => {
  userId.value = memberStore.userInfo?.userId || "알 수 없음";
});

// 최대 여행 계획 번호 가져오기

const fetchMaxPlanNo = async () => {
  const userId = memberStore.userInfo?.userId;
  if (!userId) {
    alert("로그인이 필요합니다.");
    return;
  }

  await getMaxPlanNo(
    userId,
    (response) => {
      num.value = response.data.maxPlanNo || 0; // 최대 번호 설정 (없으면 0)
    },
    (error) => {
      console.error("최대 여행 계획 번호 가져오기 실패:", error);
      num.value = 0;
    }
  );
};

// 여행 계획 저장
const addPlanList = async () => {
  if (!info.value.startDay || !info.value.endDay || props.dayPlans.length === 0) {
    alert("여행 시작일, 종료일, 일정을 확인해주세요.");
    return;
  }

  // 로그인한 사용자의 userId 가져오기
  const userId = memberStore.userInfo?.userId;

  if (!userId) {
    alert("로그인이 필요합니다.");
    return;
  }

  // 최대 여행 계획 번호 가져오기
  await fetchMaxPlanNo();

  const planDto = {
    planName: info.value.planTitle, // 최대 번호 기반으로 planName 설정
    startDate: info.value.startDay,
    endDate: info.value.endDay,
    userId: userId,
  };

  createPlan(
    planDto,
    props.dayPlans,
    (response) => {
      console.log("여행 계획 저장 성공: ", response);
      alert("여행 계획이 성공적으로 저장되었습니다.");
      resetPlans();
    },
    (error) => {
      console.error("여행 계획 저장 실패: ", error);
      alert("여행 계획 저장에 실패했습니다.");
    }
  );
};

const resetPlans = () => {
  num.value += 1;
  info.value = { planTitle: "", startDay: "", endDay: "" };
  emit('generate-plans', "", "");
};
</script>

<template>
  <div class="container py-3">
    <div class="row">
      <div class="col-12">
        <h4 class="fw-bold mb-3">{{ userId }}님의 여행 계획</h4>
        <label for="plan-name" class="form-label">여행 계획 제목:</label>
          <input
            id="plan-name"
            class="form-control"
            type="text"
            v-model="info.planTitle"
            placeholder="여행 계획 제목 입력"
          />
        
        <!-- Date inputs -->
        <div class="mb-3">
          <label for="start-day" class="form-label">시작일:</label>
          <input 
            type="date" 
            id="start-day" 
            class="form-control" 
            v-model="info.startDay" 
            @change="generateDayPlans"
          />
        </div>
        
        <div class="mb-3">
          <label for="end-day" class="form-label">종료일:</label>
          <input 
            type="date" 
            id="end-day" 
            class="form-control" 
            v-model="info.endDay" 
            @change="generateDayPlans"
          />
        </div>

        <!-- Day Plans -->
        <h5 class="fw-bold mt-4 mb-3">여행 일정</h5>
        <div class="row">
          <div 
            v-for="(dayPlan, index) in dayPlans" 
            :key="index"
            class="col-12 mb-4"
          >
            <div 
              class="card shadow-sm"
              :class="{ 'border-primary': selectedDayIndex === index }"
              @click="selectDay(index)"
            >
              <div class="card-header bg-light">
                <h6 class="fw-bold mb-0">{{ index + 1 }}일차</h6>
              </div>
              <div class="card-body">
                <textarea
                  class="form-control mb-3"
                  v-model="dayPlan.memo"
                  placeholder="메모를 입력하세요"
                  rows="2"
                ></textarea>
                
                <!-- Attractions List -->
                <div class="attractions">
                  <h6 class="fw-bold mb-3">관광지 리스트</h6>
                  <div class="row g-2">
                    <div 
                      v-for="(attraction, i) in dayPlan.attractions" 
                      :key="attraction.contentId"
                      class="col-12"
                    >
                      <div class="card mb-2">
                        <div class="card-body d-flex justify-content-between align-items-center">
                          <div>
                            <h6 class="fw-bold mb-0">{{ attraction.title }}</h6>
                            <!-- 시간 입력 폼 추가 -->
                            <input
                              v-model="attraction.time"
                              type="time"
                              class="form-control"
                              placeholder="방문 시간 입력"
                              style="width: 200px; margin-top: 10px;"
                            />
                          </div>
                          <button 
                            class="btn btn-outline-danger btn-sm"
                            @click="removeAttraction(index, i)"
                          >
                            삭제
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Action Buttons -->
    <div class="d-flex gap-2 mt-3">
      <button class="btn btn-primary" @click="addPlanList">
        여행 계획 추가
      </button>
      <button class="btn btn-secondary" @click="resetPlans">
        초기화
      </button>
    </div>
  </div>
</template>

<style scoped>
.card {
  transition: all 0.3s ease;
}

.card:hover {
  transform: translateY(-2px);
}
</style>
