<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useMemberStore } from "@/stores/member";
import { withdrawUser } from "@/api/user";
import UserNavbar from "@/components/layout/UserNavbar.vue"; // UserNavbar 컴포넌트 import

const router = useRouter();
const memberStore = useMemberStore();

const password = ref("");
const passwordError = ref("");

// store에서 사용자 정보가 없는 경우를 처리
if (!memberStore.isLogin || !memberStore.userInfo) {
  alert("로그인이 필요한 서비스입니다.");
  router.push({ name: "user-login" });
}


// 회원 탈퇴
const withdrawUserHandler = async () => {
  // 비밀번호 입력 확인
  if (!password.value) {
    passwordError.value = "비밀번호를 입력해주세요.";
    return;
  }

  // userInfo에 저장된 userId 사용
  if (!memberStore.userInfo || !memberStore.userInfo.userId) {
    alert("사용자 정보를 찾을 수 없습니다.");
    return;
  }

  const param = {
    userId: memberStore.userInfo.userId, // userInfo 객체에서 userId를 가져옴
    password: password.value
  };
  
  console.log("회원탈퇴 요청 데이터:", param); // 데이터 확인용 로그

  try {
    await withdrawUser(
      param,
      () => {
        alert("회원 탈퇴가 완료되었습니다.");
        memberStore.userLogout(); // store의 로그아웃 함수 사용
        router.push({ name: "user-login" });
      },
      (error) => {
        console.log("에러 응답:", error.response);
        if (error.response && error.response.status === 400) {
          passwordError.value = "비밀번호가 일치하지 않습니다.";
        } else {
          alert("회원 탈퇴 중 오류가 발생했습니다.");
        }
      }
    );
  } catch (err) {
    console.error("예기치 못한 오류:", err);
    alert("회원 탈퇴 요청이 실패했습니다.");
  }
};
</script>

<template>
  <div class="withdraw-container">
    <UserNavbar/>
    <h2>회원 탈퇴</h2>
    <p>회원 탈퇴를 진행하려면 비밀번호를 입력해주세요.</p>
    <div class="form-group">
      <label for="password"></label>
      <input
        id="password"
        type="password"
        v-model="password"
        class="input-field"
        placeholder="비밀번호를 입력하세요"
      />
      <p v-if="passwordError" class="error-message">{{ passwordError }}</p>
    </div>
    <button class="withdraw-button" @click="withdrawUserHandler">회원 탈퇴</button>
  </div>
</template>

<style scoped>

.withdraw-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #f7e6d4;
  min-height: 100vh;
}


h2 {
  text-align: center;
  margin-top: 25px;
  margin-bottom: 20px;
}

p{
  margin-top: 25px;
  color: red;
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  color: #755645;
}

.input-field {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 25px;
  font-size: 16px;
  background-color: #fff;
}

.withdraw-button {
  padding: 10px 20px;
  border: none;
  border-radius: 25px;
  font-size: 14px;
  color: #fff;
  background-color: #d5a67d;
  cursor: pointer;
}

.withdraw-button:hover{
  background-color: #c1906d;
}

.error-message {
  color: red;
  font-size: 12px;
  margin-top: 5px;
}
</style>
