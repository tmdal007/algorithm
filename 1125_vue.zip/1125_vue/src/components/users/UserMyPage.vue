<script setup>
import UserNavbar from "@/components/layout/UserNavbar.vue"; // UserNavbar 컴포넌트 import
import { ref, onMounted } from "vue";
import { useMemberStore } from "@/stores/member";

const memberStore = useMemberStore();

// 유저 정보 바인딩 변수
const name = ref("");
const userId = ref("");
const userPwd = ref("");
const email = ref("");

// 비밀번호 변경을 위한 변수들
const newPassword = ref("");
const confirmPassword = ref("");
const showPasswordModal = ref(false);

// 이메일 오류 메시지
const emailError = ref("");
const passwordError = ref("");
const currentPasswordError = ref("");

// 페이지 로드 시 사용자 정보 가져오기
onMounted(async () => {
  const token = sessionStorage.getItem("accessToken");
  if (token) {
    try {
      await memberStore.getUserInfo(token);
      if (memberStore.userInfo) {
        name.value = memberStore.userInfo.userName || "";
        userId.value = memberStore.userInfo.userId || "";
        email.value = `${memberStore.userInfo.emailId || ""}@${memberStore.userInfo.emailDomain || ""}`;
        userPwd.value = memberStore.userInfo.userPwd || "";
      }
    } catch (error) {
      console.error("유저 정보 가져오기 실패:", error);
    }
  }
});

// 비밀번호 변경 함수
const changePassword = async () => {
  passwordError.value = "";
  currentPasswordError.value = "";

  if (!userPwd.value) {
    currentPasswordError.value = "현재 비밀번호를 입력해주세요.";
    return;
  }

  if (!newPassword.value || !confirmPassword.value) {
    passwordError.value = "새 비밀번호와 확인을 모두 입력해주세요.";
    return;
  }

  if (newPassword.value !== confirmPassword.value) {
    passwordError.value = "새 비밀번호가 일치하지 않습니다.";
    return;
  }

  try {
    await memberStore.updateUser({
      userId: userId.value,
      column: "user_password",
      value: newPassword.value,
      currentPassword: userPwd.value,
    });
    alert("비밀번호가 성공적으로 변경되었습니다.");
    userPwd.value = newPassword.value;
    newPassword.value = "";
    confirmPassword.value = "";
    showPasswordModal.value = false;
  } catch (error) {
    alert("비밀번호 변경에 실패했습니다.");
  }
};

// 이메일 변경 함수
const changeEmail = async () => {
  emailError.value = "";

  if (!email.value) {
    emailError.value = "이메일을 입력해주세요.";
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.value)) {
    emailError.value = "올바른 이메일 형식을 입력해주세요.";
    return;
  }

  try {
    await memberStore.updateUser({
      userId: userId.value,
      column: "email",
      value: email.value,
    });
    alert("이메일이 성공적으로 변경되었습니다.");
  } catch (error) {
    console.error("이메일 변경 실패:", error);
    alert("이메일 변경에 실패했습니다.");
  }
};
</script>

<template>
  <div class="mypage-container">
    <!-- UserNavbar 컴포넌트 사용 -->
    <UserNavbar />
    <div class="mypage-content">
      <h2>회원정보</h2>
      <div class="form-group">
        <label>이름</label>
        <input type="text" v-model="name" class="input-field" disabled />
      </div>
      <div class="form-group">
        <label>아이디</label>
        <input type="text" v-model="userId" class="input-field" disabled />
      </div>
      
      <!-- 비밀번호 변경 섹션 -->
      <div class="form-group">
        <label>현재 비밀번호</label>
        <input type="password" v-model="userPwd" class="input-field" />
        <p v-if="currentPasswordError" class="error-message">{{ currentPasswordError }}</p>
      </div>
      <div v-if="showPasswordModal" class="password-change-section">
        <div class="form-group">
          <label>새 비밀번호</label>
          <input type="password" v-model="newPassword" class="input-field" />
        </div>
        <div class="form-group">
          <label>새 비밀번호 확인</label>
          <input type="password" v-model="confirmPassword" class="input-field" />
        </div>
      </div>
      <button 
        class="change-button" 
        @click="showPasswordModal ? changePassword() : showPasswordModal = true"
      >
        {{ showPasswordModal ? '비밀번호 변경' : '비밀번호 변경하기' }}
      </button>
      
      <!-- 비밀번호 오류 메시지 -->
      <p v-if="passwordError" class="error-message">{{ passwordError }}</p>

      <!-- 이메일 수정 섹션 -->
      <div class="form-group">
        <label>이메일</label>
        <input type="email" v-model="email" class="input-field" />
        <!-- 이메일 오류 메시지 -->
        <p v-if="emailError" class="error-message">{{ emailError }}</p>
      </div>
      <button class="update-button" @click="changeEmail">이메일 수정</button>
    </div>
  </div>
</template>

<style scoped>
.mypage-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #f7e6d4;
  min-height: 100vh;
}

.mypage-content {
  margin-top: 30px;
  width: 80%;
  max-width: 600px;
  position: relative;
}

h2 {
  text-align: center;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  color: #755645;
}

.input-field {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 25px;
  font-size: 16px;
  background-color: #fff;
}

.change-button, .update-button {
  padding: 10px 20px;
  border: none;
  border-radius: 25px;
  font-size: 14px;
  color: #fff;
  background-color: #d5a67d;
  cursor: pointer;
}

.change-button:hover, .update-button:hover {
  background-color: #c1906d;
}

.error-message {
  color: red;
  font-size: 12px;
  margin-top: 5px;
}
</style>
