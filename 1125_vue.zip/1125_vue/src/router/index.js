import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'main',
      component: () => import('@/views/TheMainView.vue'),
    },
    {
      path: "/user",
      name: "user",
      component: () => import("@/views/TheUserView.vue"),
      children: [
        {
          path: "login",
          name: "user-login",
          component: () => import("@/components/users/UserLogin.vue"),
        },
        {
          path: "join",
          name: "user-join",
          component: () => import("@/components/users/UserRegister.vue"),
        },
        {
          path: "mypage",
          name: "user-mypage",
          component: () => import("@/components/users/UserMyPage.vue"),
        },
        {
          path: "withdraw",
          name: "user-withdraw",
          component: () => import("@/components/users/UserWithdraw.vue"),
        },
      ],
    },
    {
      path: "/chatbot",
      name: "chatbot",
      component: () => import("@/components/chatbot/Chatbot.vue"),
    },
    {
      path: "/search",
      name: "search",
      component: () => import("../views/TheMap.vue"),
    },
    {
      path: "/plans",
      name: "plans",
      component: () => import("../views/TheMyPlan.vue"),
    },
    {
      path: "/myplan",
      name: "myplan",
      component: () => import("../views/ThePlanView.vue"),
    },
    {
      path: "/notice",
      name: "notice",
      component: () => import("../views/TheNoticeView.vue"),
      redirect: { name: "article-list" },
      children: [
        {
          path: "list",
          name: "article-list",
          component: () => import("@/components/notices/NoticeList.vue"),
        },
        {
          path: "view/:articleno",
          name: "article-view",
          component: () => import("@/components/notices/NoticeDetail.vue"),
        },
        {
          path: "write",
          name: "article-write",
          component: () => import("@/components/notices/NoticeWrite.vue"),
        },
        {
          path: "modify/:articleno",
          name: "article-modify",
          component: () => import("@/components/notices/NoticeModify.vue"),
        },
      ],
    },
  ],
})
export default router
