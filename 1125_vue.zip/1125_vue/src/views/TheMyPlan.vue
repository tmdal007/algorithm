<script setup>
import PlanMake from "@/components/plans/PlanMake.vue";
import TheAttraction from "@/components/attraction/TheAttraction.vue";
import TheLikeAttraction from "@/components/attraction/TheLikeAttraction.vue";
import { ref } from "vue";

const dayPlans = ref([]); // PlanMake로 전달할 일정 데이터
const selectedDayIndex = ref(null); // 현재 선택된 일차
const mapCenterAttraction = ref(null); // VKakaoMap에 전달할 중심 관광지
const showAttractionSearch = ref(true); // 관광지 검색과 즐겨찾기 검색 전환 상태

// 관광지 선택 처리 함수
const handleAttractionSelect = (attraction) => {
  console.log("관광지 정보", attraction);
  if (selectedDayIndex.value === null) {
    // 선택된 일차가 없는 경우 중심 이동을 위해 관광지 정보를 저장
    mapCenterAttraction.value = attraction;
  } else {
    console.log("여행 계획 입력!", attraction);
    const selectedAttraction = {
      attractionNo: attraction.no,
      title: attraction.title,
      time: attraction.time,
    };

    // 선택된 일차의 attractions 배열에 추가
    dayPlans.value[selectedDayIndex.value].attractions.push(selectedAttraction);
  }
};

// 일정 선택 처리 함수 (선택 해제 포함)
const selectDay = (index) => {
  if (selectedDayIndex.value === index) {
    // 이미 선택된 경우 해제
    selectedDayIndex.value = null;
  } else {
    selectedDayIndex.value = index;
  }
};

// 일정 초기화
const generateDayPlans = (startDate, endDate) => {
  const days =
    Math.ceil(
      (new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)
    ) + 1;

  dayPlans.value = Array.from({ length: days }, (_, i) => ({
    days: i + 1,
    memo: "",
    attractions: [],
  }));
};
</script>

<template>
  <div class="container-fluid px-0">
    <!-- TheAttraction 또는 TheLikeAttraction -->
    <div class="row g-0">
      <div class="col-12 col-md-8 g-0">
          <!-- 버튼을 지도 위쪽에 배치 -->
          <div class="button-container">
            <button
              class="btn btn-success"
              @click="showAttractionSearch = true"
              :disabled="showAttractionSearch"
            >
              관광지 검색
            </button>
            <button
              class="btn btn-success"
              @click="showAttractionSearch = false"
              :disabled="!showAttractionSearch"
            >
              즐겨찾기 검색
            </button>
          </div>
        <div v-if="showAttractionSearch">
          <TheAttraction
            @select-attraction="handleAttractionSelect"
            :selectedDayIndex="selectedDayIndex"
          />
        </div>
        <div v-else>
          <TheLikeAttraction
            @select-attraction="handleAttractionSelect"
            :selectedDayIndex="selectedDayIndex"
          />
        </div>
      </div>

      <!-- PlanMake: 여행 계획 생성 -->
      <div class="col-12 col-md-4 g-0">
        <PlanMake
          :dayPlans="dayPlans"
          :selectedDayIndex="selectedDayIndex"
          @select-day="selectDay"
          @generate-plans="generateDayPlans"
        />
      </div>
    </div>
  </div>
</template>

<style scoped>
/* 버튼 스타일 */
.button-container {
  text-align: left;
  padding: 30px;

}

.button-container button {
  margin-right: 20px;
}

/* 화면 크기에 따라 컴포넌트 크기를 조정 */
@media (max-width: 767px) {
  .container-fluid {
    padding: 0;
  }

  .row.g-0 {
    display: flex;
    flex-direction: column;
  }

  /* PlanMake가 TheAttraction 아래로 배치되도록 */
  .col-12 {
    width: 100%;
  }
}

@media (min-width: 768px) {
  .row.g-0 {
    display: flex;
    flex-direction: row;
  }

  /* TheAttraction 또는 TheLikeAttraction은 화면의 2/3 크기 (col-md-8) */
  .col-md-8 {
    width: 66.6667%;
  }

  /* PlanMake는 화면의 1/3 크기 (col-md-4) */
  .col-md-4 {
    width: 33.3333%;
  }
}
</style>
