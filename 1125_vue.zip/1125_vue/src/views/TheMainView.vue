<script setup>
import WeatherView from "@/components/weather/WeatherView.vue";
import Chatbot from "@/components/chatbot/Chatbot.vue"
</script>

<template>
  <Chatbot/>
  <div class="main-container">
    <img src="@/assets/logo.PNG" alt="Logo">
    <div style="margin-top: 75px"></div>
  </div>
</template>

<style scoped>
.main-container {
  background-color: #eee0d1;
  min-height: 100vh; /* 화면을 꽉 채우도록 */
  display: flex;
  justify-content: center;
  align-items: center;
}

img {
  max-width: 100%;
  height: auto;
}
</style>
