<script setup>
import { onMounted } from "vue";
import { useMemberStore } from "@/stores/member";
import { RouterView } from "vue-router";
import TheNavbar from "@/components/layout/TheNavbar.vue";


const memberStore = useMemberStore();

onMounted(async () => {
  // 로그인 상태 초기화
  await memberStore.initializeLoginState();
});
</script>

<template>
  <div>
    <TheNavbar />
    <router-view></router-view>
  </div>
</template>

<style scoped>

</style>