import { localAxios } from "@/util/http-commons";

const local = localAxios();

// 여행 일정 생성
function createPlan(planDto, dayPlans, success, fail) {
  console.log("여행 일정 생성: ", { planDto, dayPlans });
  const payload = {
    planDto,
    dayPlans,
  };
  local
    .post(`/plans`, JSON.stringify(payload), {
      headers: {
        "Content-Type": "application/json",
      },
    })
    .then(success)
    .catch(fail);
}

// 여행 일정 수정
function updatePlan(planNo, planDto, dayPlans, success, fail) {
  console.log(`여행 일정 수정 (PlanNo: ${planNo}): `, { planDto, dayPlans });
  const payload = {
    planDto,
    dayPlans,
  };
  local
    .put(`/plans/${planNo}`, JSON.stringify(payload), {
      headers: {
        "Content-Type": "application/json",
      },
    })
    .then(success)
    .catch(fail);
}

// 여행 일정 삭제
function deletePlan(planNo, success, fail) {
  console.log(`여행 일정 삭제 (PlanNo: ${planNo})`);
  local
    .delete(`/plans/${planNo}`)
    .then(success)
    .catch(fail);
}

// 특정 여행 일정 조회
function getPlan(planNo, success, fail) {
  console.log(`특정 여행 일정 조회 (PlanNo: ${planNo})`);
  local
    .get(`/plans/${planNo}`)
    .then(success)
    .catch(fail);
}

// 전체 여행 일정 조회
function getAllPlans(success, fail) {
  console.log("전체 여행 일정 조회");
  local
    .get(`/plans`)
    .then(success)
    .catch(fail);
}

// 특정 여행 일정의 하루 일정 조회
function getDayPlans(planNo, success, fail) {
  console.log(`특정 여행 일정의 하루 일정 조회 (PlanNo: ${planNo})`);
  local
    .get(`/plans/${planNo}/day-plans`)
    .then(success)
    .catch(fail);
}

// 특정 하루 일정의 관광지 조회
function getAttractions(dayPlanNo, success, fail) {
  console.log(`특정 하루 일정의 관광지 조회 (DayPlanNo: ${dayPlanNo})`);
  local
    .get(`/plans/day-plan/${dayPlanNo}/attractions`)
    .then(success)
    .catch(fail);
}

// 하루 일정 추가
function addDayPlan(planNo, dayPlanDto, success, fail) {
  console.log(`하루 일정 추가 (PlanNo: ${planNo}): `, dayPlanDto);
  local
    .post(`/plans/${planNo}/day-plans`, JSON.stringify(dayPlanDto), {
      headers: {
        "Content-Type": "application/json",
      },
    })
    .then(success)
    .catch(fail);
}

// 관광지 추가
function addAttraction(dayPlanNo, attractionDto, success, fail) {
  console.log(`관광지 추가 (DayPlanNo: ${dayPlanNo}): `, attractionDto);
  local
    .post(`/plans/day-plan/${dayPlanNo}/attractions`, JSON.stringify(attractionDto), {
      headers: {
        "Content-Type": "application/json",
      },
    })
    .then(success)
    .catch(fail);
}

// 하루 일정 삭제
function deleteDayPlan(dayPlanNo, success, fail) {
  console.log(`하루 일정 삭제 (DayPlanNo: ${dayPlanNo})`);
  local
    .delete(`/plans/day-plan/${dayPlanNo}`)
    .then(success)
    .catch(fail);
}

// 관광지 삭제
function deleteAttraction(dayPlanNo, attractionNo, success, fail) {
  console.log(`관광지 삭제 (DayPlanNo: ${dayPlanNo}, AttractionNo: ${attractionNo})`);
  local
    .delete(`/plans/day-plan/${dayPlanNo}/attractions/${attractionNo}`)
    .then(success)
    .catch(fail);
}

// 관광지(attraction_plan) time 수정
function updateAttractionTime(dayPlanNo, attractionNo, time, success, fail) {
  console.log(`관광지 시간 수정 (DayPlanNo: ${dayPlanNo}, AttractionNo: ${attractionNo}, Time: ${time})`);
  local
    .put(`/plans/${dayPlanNo}/${attractionNo}/time`, null, {
      params: { time }, // Query parameter로 시간 전달
    })
    .then(success)
    .catch(fail);
}

// 관광지(attraction_plan) order_no 순서 관리
// 관광지 순서 저장
function saveAttractionsOrder(dayPlanNo, attractions, success, fail) {
  console.log("순서 저장 (DayPlanNo:", dayPlanNo, "Attractions:", attractions, ")");
  local
    .put(`/plans/day-plan/${dayPlanNo}/attractions/order`, attractions)
    .then(success)
    .catch(fail);
}



// 특정 사용자의 최대 여행 계획 번호 조회
function getMaxPlanNo(userId, success, fail) {
  console.log(`최대 여행 계획 번호 조회 (UserId: ${userId})`);
  local
    .get(`/plans/max-plan/${userId}`)
    .then(success)
    .catch(fail);
}

// 특정 사용자의 모든 여행 계획 번호 조회
function getUserPlans(userId, success, fail) {
  console.log(`사용자의 여행 계획 번호 조회 (UserId: ${userId})`);
  local
    .get(`/plans/user-plans/${userId}`)
    .then(success)
    .catch(fail);
}

export {
  createPlan,
  updatePlan,
  deletePlan,
  getPlan,
  getAllPlans,
  getDayPlans,
  getAttractions,
  addDayPlan,
  addAttraction,
  deleteDayPlan,
  deleteAttraction,
  updateAttractionTime,
  saveAttractionsOrder,
  getMaxPlanNo,
  getUserPlans,
};
