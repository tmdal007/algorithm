package com.ssafy.member.dto;

public class MemberDto {
	private String userID;
	private String userName;
	private String userPwd;
	private String eId;
	private String eDomain;
	private String joinDate;
	
	public MemberDto() {
		super();
	}

	public MemberDto(String userID, String userName, String userPwd, String eId, String eDomain, String joinDate) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userPwd = userPwd;
		this.eId = eId;
		this.eDomain = eDomain;
		this.joinDate = joinDate;
	}
	
	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String geteId() {
		return eId;
	}

	public void seteId(String eId) {
		this.eId = eId;
	}

	public String geteDomain() {
		return eDomain;
	}

	public void seteDomain(String eDomain) {
		this.eDomain = eDomain;
	}

	public String getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}

	public String toString() {
		return "MemberDto [userID=" + userID + ", userName=" + userName + ", userPwd=" + userPwd + ", eId=" + eId
				+ ", eDomain=" + eDomain + ", joinDate=" + joinDate + "]";
	}
	
	
}
