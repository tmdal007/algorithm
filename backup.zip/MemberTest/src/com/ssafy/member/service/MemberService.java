package com.ssafy.member.service;

import java.util.List;

import com.ssafy.member.dao.MemberDao;
import com.ssafy.member.dto.*;

//dao ȣ��
public class MemberService {
	
	private MemberService() {}
	private static MemberService instance = new MemberService();
	public static MemberService getInstance() {
		return instance;
	}
	
	MemberDao dao = MemberDao.getInstance();
	
	public List<MemberDto> getMemberList(){
		return dao.getMemberList();
	}
}
