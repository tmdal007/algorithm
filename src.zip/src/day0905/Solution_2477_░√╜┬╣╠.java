package day0905;

public class Solution_2477_곽승미 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
