package day0821;

public class Solution_6782_곽승미 {

	public static void main(String[] args) {
		

	}

}
