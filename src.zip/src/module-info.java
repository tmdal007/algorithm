/**
 * 
 */
/**
 * 
 */
module algorithm {
}