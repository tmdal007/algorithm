package day0819;

public class Solution_4012_곽승미 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
