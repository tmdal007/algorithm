//package com.trip.board;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import com.trip.board.model.UserDto;
//import com.trip.util.DBUtil;
//
//public class select {
//	
//	static BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
//	
//	
//	static void userInfo() throws NumberFormatException, IOException {
//		
//		
//		
//		try {
//			
//			conn = dbu.getConnection();
//			UserDto uto = new UserDto();
//			
//			System.out.println("1. 회원 가입"); // INSERT
//			System.out.println("2. 정보 수정"); // UPDATE
//			System.out.println("3. 특정 회원 조회"); // SELECT
//			System.out.println("4. 전체 회원 조회");
//			System.out.println("5. 회원 탈퇴"); // DELETE
//			System.out.print("번호를 입력해주세요 : ");
//			
//			int n = Integer.parseInt(bf.readLine());
//			
//			if (n == 1) {	
//				
//				System.out.print("사용할 아이디를 입력하세요 :");
//				uto.setUser_id(bf.readLine());
//				
//				System.out.print("사용자 이름를 입력하세요 :");
//				uto.setUser_name(bf.readLine());
//				
//				System.out.print("사용할 비밀번호를 입력하세요 :");
//				uto.setUser_pwd(bf.readLine());
//				
//				System.out.print("사용할 이메일을 입력하세요 :");
//				uto.seteId(bf.readLine());
//	
//				StringBuilder sql = new StringBuilder("insert into user_info (user_id, user_name, user_pwd, email_id) \n");
//				sql.append("values (?, ?, ?, ?)");
//				pstmt = conn.prepareStatement(sql.toString());
//				
//				pstmt.setString(1, uto.getUser_id());
//				pstmt.setString(2, uto.getUser_name());
//				pstmt.setString(3, uto.getUser_pwd());
//				pstmt.setString(4, uto.geteId());
//				
//				pstmt.executeUpdate();
//				
//				System.out.println("등록성공");
//				
//			} else if (n == 2) {
//				
//				System.out.print("비밀번호를 찾을 아이디를 입력해주세요 :");
//				
//				String id = bf.readLine();
//				
//				StringBuilder sql = new StringBuilder("update user_info \n");
//				sql.append("set user_pwd \n");
//				sql.append("where user_id = ? ");
//				
//				pstmt = conn.prepareStatement(sql.toString());
//				
//				pstmt.setString(1, id);
//				
//				pstmt.executeUpdate();
//				
//			} else if (n == 3) {
//				
//				System.out.println("찾으실 사용자 이름을 적어주세요 : ");
//				
//				StringBuilder sql = new StringBuilder("select * from user_info where user_name = \""+bf.readLine()+"\"");
//				pstmt = conn.prepareStatement(sql.toString());
//				
//				rs = pstmt.executeQuery();
//				
//				while(rs.next()) {
//
//					uto.setUser_id(rs.getString("user_id"));
//					uto.setUser_name(rs.getString("user_name"));
//					uto.seteId(rs.getString("email_id"));
//					uto.setJoinDate(rs.getString("join_data"));
//					uto.setUser_no(rs.getInt("user_no"));
//					
//					System.out.println(uto.toString());
//				}
//				
//			} else if (n == 4){
//				
//				StringBuilder sql = new StringBuilder("select * from user_info");
//				pstmt = conn.prepareStatement(sql.toString());
//				
//				rs = pstmt.executeQuery();
//				
//				while(rs.next()) {
//
//					uto.setUser_id(rs.getString("user_id"));
//					uto.setUser_name(rs.getString("user_name"));
//					uto.seteId(rs.getString("email_id"));
//					uto.setJoinDate(rs.getString("join_data"));
//					uto.setUser_no(rs.getInt("user_no"));
//					
//					System.out.println(uto.toString());
//				}
//			} else {
//				System.out.println("삭제하실 아이디를 입력해주세요 : ");
//				
//				StringBuilder sql = new StringBuilder("delete from user_info where user_id = \""+bf.readLine()+"\"");
//				pstmt = conn.prepareStatement(sql.toString());
//				
//				pstmt.executeUpdate();
//			
//				System.out.println("삭제되었습니다.");
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} finally {
//			dbu.close(rs, pstmt, conn);
//		}
//	}
//	
//	static void login() throws NumberFormatException, IOException {
//		
//		DBUtil dbu = DBUtil.getInstance();
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		
//		try {
//			conn = dbu.getConnection();
//			UserDto uto = new UserDto();
//			
//			System.out.println("1. 로그인"); // SELECT 있으면 성공 없으면 실패 -> 가입
//			System.out.println("2. 로그아웃"); // 하나 띄워주자,,
//			System.out.println("3. 비밀번호 찾기"); // SELECT
//			System.out.print("번호를 입력해 주세요 : ");
//			
//			int n = Integer.parseInt(bf.readLine());
//			
//			if (n == 1) {
//				
//				System.out.print("아이디 입력해주세요 :");
//				String id = bf.readLine();
//				System.out.print("비밀번호 입력해주세요 :");
//				String pwd = bf.readLine();
//				
//				StringBuilder sql = new StringBuilder("select * from user_info where user_id = \""+id+"\" and user_pwd = \""+pwd+"\" ");
//				pstmt = conn.prepareStatement(sql.toString());
//				
//				rs = pstmt.executeQuery();
//				
//				if (rs.next()) {
//					System.out.println("로그인 성공");
//				} else {
//					System.out.println("로그인 실패");
//				}
//			} else if (n == 2) {
//				
//				System.out.println("로그아웃 되었습니다");
//				
//			} else {
//				System.out.println("비밀번호를 찾을 아이디를 입력해주세요");
//				String id = bf.readLine();
//				
//				System.out.println("이메일을 입력해주세요");
//				String email = bf.readLine();
//				
//				StringBuilder sql = new StringBuilder("select user_pwd from user_info where user_id = \""+id+"\" and email_id = \""+email+"\" ");
//				pstmt = conn.prepareStatement(sql.toString());
//				
//				rs = pstmt.executeQuery();
//				
//				if (rs.next()) {
//					uto.setUser_pwd(rs.getString("user_pwd"));
//					System.out.println("비밀번호 : " + uto.getUser_pwd());
//				} else {
//					System.out.println("다시!");
//				}
//			}
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	static void boardManager() throws NumberFormatException, IOException {
//		
//		DBUtil dbu = DBUtil.getInstance();
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		
//		try {
//			conn = dbu.getConnection();
//			
//			System.out.println("1. 공유게시판");
//			System.out.println("2. 공지사항");
//			System.out.println("번호를 입력하세요 (공지사항 등록, 수정, 삭제 시 관리자 로그인 필) : ");
//			
//			int n = Integer.parseInt(bf.readLine());
//			
//			if (n == 1) {
//				
//				
//				
//			} else {
//				
//				
//				
//			}
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}
//
//	public static void main(String[] args) throws NumberFormatException, IOException {
//		
//		while(true) {
//			
//			System.out.println("1. 회원 관리");
//			System.out.println("2. 관광지 조회");
//			System.out.println("3. 게시판 관리");
//			System.out.println("4. 로그인 관리");
//			System.out.println("5. 종료");
//			
//			System.out.print("번호를 선택하세요 : ");
//			
//			int n = Integer.parseInt(bf.readLine());
//			
//			if (n == 1) {
//				
//				userInfo();
//				
//			} else if (n == 2) {
//				
//				tourInfo();
//				
//			} else if (n == 3) {
//				
//				boardManager();
//				
//			} else if (n == 4){
//				
//				login();
//				
//			} else if (n == 5){
//				break;
//			}
//		}
//
//	}
//
//}
