package com.trip.board.model;

public class TourDto {
	
	private String title;
	private String image1;
	private String image2;
	
	public TourDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TourDto(String title, String image1, String image2) {
		super();
		this.title = title;
		this.image1 = image1;
		this.image2 = image2;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImage1() {
		return image1;
	}

	public void setImage1(String image1) {
		this.image1 = image1;
	}

	public String getImage2() {
		return image2;
	}

	public void setImage2(String image2) {
		this.image2 = image2;
	}

	@Override
	public String toString() {
		return "TourDto [title=" + title + ", image1=" + image1 + ", image2=" + image2 + "]";
	}


}
