package com.trip.board.model;

public class NoticeDto {

	private int article_no;
	private String subject;
	private String content;
	private String register_time;
	
	public NoticeDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoticeDto(int article_no, String subject, String content, String register_time) {
		super();
		this.article_no = article_no;
		this.subject = subject;
		this.content = content;
		this.register_time = register_time;
	}

	public int getArticle_no() {
		return article_no;
	}

	public void setArticle_no(int article_no) {
		this.article_no = article_no;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegister_time() {
		return register_time;
	}

	public void setRegister_time(String register_time) {
		this.register_time = register_time;
	}

	@Override
	public String toString() {
		return "NoticeDto [article_no=" + article_no + ", subject=" + subject + ", content=" + content
				+ ", register_time=" + register_time + "]";
	}
	
}
