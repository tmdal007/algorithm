package com.trip.board.model.dao;

import java.io.IOException;
import java.util.List;

import com.trip.board.model.BoardDto;
import com.trip.board.model.NoticeDto;
import com.trip.board.model.TourDto;
import com.trip.board.model.UserDto;

public interface BoardDao {
	int selectSido() throws NumberFormatException, IOException;
	int selectGugun(int sido) throws NumberFormatException, IOException;
	public List<TourDto> tourInfo(int sido, int gugun) throws NumberFormatException, IOException;
	void userJoin() throws NumberFormatException, IOException;
	void userUpdate() throws NumberFormatException, IOException;
	List<UserDto> userSearchOne() throws NumberFormatException, IOException;
	List<UserDto> userSearchAll() throws NumberFormatException, IOException;
	void userDelete() throws NumberFormatException, IOException;
	void cWriting (int x) throws IOException;
	public void cUpdate(int x);
	public void cDelete(int x);
	public List<BoardDto> cSelect();
	public List<NoticeDto> nSelect();
	
}
