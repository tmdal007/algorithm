package com.trip.board.model.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.trip.board.model.BoardDto;
import com.trip.board.model.LocalDto;
import com.trip.board.model.NoticeDto;
import com.trip.board.model.TourDto;
import com.trip.board.model.UserDto;
import com.trip.util.DBUtil;

public class BoardDaoImpl implements BoardDao{
	static BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	
	private static BoardDao boardDao = new BoardDaoImpl();
	
	private BoardDaoImpl() {
	}

	public static BoardDao getBoardDao() {
		return boardDao;
	}
	
	public int selectSido() throws NumberFormatException, IOException{
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int sido = 0;
		try {
			conn = dbu.getConnection();
			
			StringBuilder sql = new StringBuilder("select sido_code, sido_name from sidos");
			pstmt = conn.prepareStatement(sql.toString());
			
			rs = pstmt.executeQuery();
			
			System.out.println("시 / 도의 번호를 입력해주세요");
			
			LocalDto dto = new LocalDto();
			while(rs.next()) {
				dto.setSido_code(rs.getInt(1));
				dto.setSido_name(rs.getString(2));
				
				System.out.println(dto.getSido_code() + " " + dto.getSido_name());
			}
			System.out.print("번호 입력 : ");
			sido = Integer.parseInt(bf.readLine());
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbu.close(rs, pstmt, conn);
		}
		return sido;
	}
	
	
	public int selectGugun(int sido) throws NumberFormatException, IOException{
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int gugun = 0;
		
		try {
			conn = dbu.getConnection();
			
			StringBuilder sql = new StringBuilder("select gugun_code, gugun_name from guguns where sido_code = "+sido+"");
			pstmt = conn.prepareStatement(sql.toString());
			
			rs = pstmt.executeQuery();
			
			System.out.println("구/군을 입력해주세요");
			
			LocalDto dto = new LocalDto();
			while(rs.next()) {
				dto.setGugun_code(rs.getInt("gugun_code"));
				dto.setGugun_name(rs.getString("gugun_name"));
				
				System.out.println(dto.getGugun_code() + " " + dto.getGugun_name());
			}
			
			System.out.print("구/군 입력 : ");
			gugun = Integer.parseInt(bf.readLine());
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbu.close(rs, pstmt, conn);
		}
		return gugun;
	}
	
	public List<TourDto> tourInfo(int sido, int gugun) throws NumberFormatException, IOException {
		
		List<TourDto> list = new ArrayList<TourDto>();
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		System.out.println("원하는 컨텐츠를 선택하세요");
		System.out.println("1. 관광지");
		System.out.println("2. 숙박");
		System.out.println("3. 음식점");
		System.out.println("4. 문화시설");
		System.out.println("5. 축제공연행사");
		System.out.println("6. 여행코스");
		System.out.println("7. 쇼핑");
		System.out.println("8. 레포츠");
		
		System.out.print("컨텐츠 입력 : ");
		
		String content = bf.readLine();
		
		try {
			conn = dbu.getConnection();
			
			StringBuilder sql = new StringBuilder("select title, first_image1, first_image2 from attractions where content_type_id = (select content_type_id from contenttypes where content_type_name = \""+content+"\") and si_gun_gu_code = "+gugun+" and area_code = "+sido+"");
			pstmt = conn.prepareStatement(sql.toString());
			
			rs = pstmt.executeQuery();

			
			while(rs.next()) {
				TourDto tto = new TourDto();
				tto.setTitle(rs.getString("title"));
				tto.setImage1(rs.getString("first_image1"));
				tto.setImage2(rs.getString("first_image2"));
				
				list.add(tto);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbu.close(rs, pstmt, conn);
		}
		return list;
	}
	
	public void userJoin() throws NumberFormatException, IOException{
	
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			conn = dbu.getConnection();
			UserDto uto = new UserDto();
				
			System.out.print("사용할 아이디를 입력하세요 :");
			uto.setUser_id(bf.readLine());
			
			System.out.print("사용자 이름를 입력하세요 :");
			uto.setUser_name(bf.readLine());
			
			System.out.print("사용할 비밀번호를 입력하세요 :");
			uto.setUser_pwd(bf.readLine());
			
			System.out.print("사용할 이메일을 입력하세요 :");
			uto.seteId(bf.readLine());

			StringBuilder sql = new StringBuilder("insert into user_info (user_id, user_name, user_pwd, email_id) \n");
			sql.append("values (?, ?, ?, ?)");
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setString(1, uto.getUser_id());
			pstmt.setString(2, uto.getUser_name());
			pstmt.setString(3, uto.getUser_pwd());
			pstmt.setString(4, uto.geteId());
			
			pstmt.executeUpdate();
			
			System.out.println("등록성공");
		
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbu.close(rs, pstmt, conn);
		}
	}
	public void userUpdate() throws NumberFormatException, IOException{
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			conn = dbu.getConnection();
				
			System.out.print("비밀번호를 수정할 아이디를 입력해주세요 :");
			
			String id = bf.readLine();
			
			System.out.print("수정할 비밀번호 입력하세요 :");
			String pwd = bf.readLine();
			
			StringBuilder sql = new StringBuilder("update user_info \n");
			sql.append("set user_pwd = ? \n");
			sql.append("where user_id = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, pwd);
			pstmt.setString(2, id);
			
//			pstmt.executeUpdate();
			System.out.println(pstmt.executeUpdate());
			
			System.out.println("수정 성공");
		
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbu.close(rs, pstmt, conn);
		}
	}
	public List<UserDto> userSearchOne() throws NumberFormatException, IOException{
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<UserDto> list = new ArrayList<UserDto>();
		
		try {
			
			conn = dbu.getConnection();
				
			System.out.println("찾으실 사용자 이름을 적어주세요 : ");
			
			StringBuilder sql = new StringBuilder("select * from user_info where user_name = \""+bf.readLine()+"\"");
			pstmt = conn.prepareStatement(sql.toString());
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				UserDto uto = new UserDto();
				uto.setUser_id(rs.getString("user_id"));
				uto.setUser_name(rs.getString("user_name"));
				uto.seteId(rs.getString("email_id"));
				uto.setJoinDate(rs.getString("join_data"));
				uto.setUser_no(rs.getInt("user_no"));
				
				list.add(uto);
			}
		
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbu.close(rs, pstmt, conn);
		}
		
		return list;
	}
	public List<UserDto> userSearchAll() throws NumberFormatException, IOException{
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<UserDto> list = new ArrayList<UserDto>();
		
		try {
			
			conn = dbu.getConnection();
				
			StringBuilder sql = new StringBuilder("select * from user_info");
			pstmt = conn.prepareStatement(sql.toString());
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				UserDto uto = new UserDto();
				uto.setUser_id(rs.getString("user_id"));
				uto.setUser_name(rs.getString("user_name"));
				uto.setUser_pwd(rs.getString("user_pwd"));
				uto.seteId(rs.getString("email_id"));
				uto.setJoinDate(rs.getString("join_data"));
				uto.setUser_no(rs.getInt("user_no"));
				
				list.add(uto);
			}
		
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbu.close(rs, pstmt, conn);
		}
		
		return list;
	}
	public void userDelete() throws NumberFormatException, IOException{
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			conn = dbu.getConnection();
				
			System.out.println("삭제하실 아이디를 입력해주세요 : ");
			
			StringBuilder sql = new StringBuilder("delete from user_info where user_id = \""+bf.readLine()+"\"");
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.executeUpdate();
			
			System.out.println("삭제 성공");
	
		
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbu.close(rs, pstmt, conn);
		}
	}
	// 글 작성		
		public void cWriting (int x) throws IOException {
			
			DBUtil dbu = DBUtil.getInstance();
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			BoardDto bto = new BoardDto();
			NoticeDto nto = new NoticeDto();

			try {
				conn = dbu.getConnection();
				
				// 공용
				if (x == 1) {
					
					System.out.print("글을 등록할 아이디를 입력하세요 : ");
					bto.setUser_id(bf.readLine());
					
					System.out.print("글 제목을 입력하세요 : ");
					bto.setSubject(bf.readLine());
					
					System.out.print("글 내용을 입력하세요 : ");
					bto.setContent(bf.readLine());
		
					StringBuilder sql = new StringBuilder("insert into board (user_id, subject, content) \n");
					sql.append("values (?, ?, ?)");
					pstmt = conn.prepareStatement(sql.toString());
					
					pstmt.setString(1, bto.getUser_id());
					pstmt.setString(2, bto.getSubject());
					pstmt.setString(3, bto.getContent());
					
					pstmt.executeUpdate();
					
					System.out.println("등록성공");
				
				// 공지사항
				} else {
					
					System.out.println("관리자 아이디 입력 : ");
					String mid = bf.readLine();
					
					System.out.println("관리자 비밀번호 입력 : ");
					String mpwd = bf.readLine();
					
					StringBuilder sql = new StringBuilder("select manager_name from manager_info where manager_id = \""+mid+"\" and manager_pwd = \""+mpwd+"\" ");
					pstmt = conn.prepareStatement(sql.toString());
					
					rs = pstmt.executeQuery();
					
					if (rs.next()) {

						System.out.print("글 제목을 입력하세요 : ");
						nto.setSubject(bf.readLine());
						
						System.out.print("글 내용을 입력하세요 : ");
						nto.setContent(bf.readLine());
			
						sql = new StringBuilder("insert into notice_board (subject, content) \n");
						sql.append("values (?, ?)");
						pstmt = conn.prepareStatement(sql.toString());
						
						pstmt.setString(1, nto.getSubject());
						pstmt.setString(2, nto.getContent());
						
						pstmt.executeUpdate();
						
						System.out.println("등록성공");
					} else {
						System.out.println("관리자 아님");
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				dbu.close(rs, pstmt, conn);
			}
			
			
		}
		
		// 글 수정
		public void cUpdate(int x) {
			
			DBUtil dbu = DBUtil.getInstance();
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			BoardDto bto = new BoardDto();
			NoticeDto nto = new NoticeDto();
			
			try {
				conn = dbu.getConnection();
				
				if (x == 1) {
					
					System.out.println("수정할 글 번호를 알려주세요 : ");
					int no = Integer.parseInt(bf.readLine());
					
					System.out.println("수정할 글 제목 : ");
					String subject = bf.readLine();
					
					System.out.println("수정할 글 내용 : ");
					String content = bf.readLine();
					
					
					StringBuilder sql = new StringBuilder("update board \n");
					sql.append("set subject = ?, content = ? \n");
					sql.append("where article_no = ? ");
					
					pstmt = conn.prepareStatement(sql.toString());
					
					pstmt.setString(1, subject);
					pstmt.setString(2, content);
					pstmt.setInt(3, no);
					
					pstmt.executeUpdate();
					
					System.out.println("수정성공");
					
				} else {
					
					System.out.println("관리자 아이디 입력 : ");
					String mid = bf.readLine();
					
					System.out.println("관리자 비밀번호 입력 : ");
					String mpwd = bf.readLine();
					
					StringBuilder sql = new StringBuilder("select manager_name from manager_info where manager_id = \""+mid+"\" and manager_pwd = \""+mpwd+"\" ");
					pstmt = conn.prepareStatement(sql.toString());
					
					rs = pstmt.executeQuery();
					
					if (rs.next()) {

						System.out.print("수정할 공지사항 번호를 입력하세요 : ");
						nto.setArticle_no(Integer.parseInt(bf.readLine()));
						
						System.out.print("수정 글 제목을 입력하세요 : ");
						nto.setSubject(bf.readLine());
						
						System.out.print("수정 글 내용을 입력하세요 : ");
						nto.setContent(bf.readLine());
			
						sql = new StringBuilder("update board \n");
						sql.append("set subject = ?, content = ? \n");
						sql.append("where article_no = ? ");
						
						pstmt = conn.prepareStatement(sql.toString());
						
						pstmt.setString(1, nto.getSubject());
						pstmt.setString(2, nto.getContent());
						pstmt.setInt(3, nto.getArticle_no());
						
						pstmt.executeUpdate();
						
						System.out.println("수정 성공");
					} else {
						System.out.println("관리자 아님");
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				dbu.close(rs, pstmt, conn);
			}
		}
		
		// 글 삭제
		public void cDelete(int x) {
			
			DBUtil dbu = DBUtil.getInstance();
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			BoardDto bto = new BoardDto();
			NoticeDto nto = new NoticeDto();
			
			try {
				conn = dbu.getConnection();
				
				if (x == 1) {
					
					System.out.println("삭제할 글 번호를 알려주세요 : ");
					int no = Integer.parseInt(bf.readLine());
					
					StringBuilder sql = new StringBuilder("delete from into board where article_no = "+no+" ");
					pstmt = conn.prepareStatement(sql.toString());
					
					pstmt.executeUpdate();
					
					System.out.println("삭제성공");
					
				} else {
					
					System.out.println("관리자 아이디 입력 : ");
					String mid = bf.readLine();
					
					System.out.println("관리자 비밀번호 입력 : ");
					String mpwd = bf.readLine();
					
					StringBuilder sql = new StringBuilder("select manager_name from manager_info where manager_id = \""+mid+"\" and manager_pwd = \""+mpwd+"\" ");
					pstmt = conn.prepareStatement(sql.toString());
					
					rs = pstmt.executeQuery();
					
					if (rs.next()) {

						System.out.print("삭제할 공지사항 번호를 입력하세요 : ");
						int no = Integer.parseInt(bf.readLine());
			
						sql = new StringBuilder("delete from into notice_board where article_no = "+no+"");
						pstmt = conn.prepareStatement(sql.toString());

						pstmt.executeUpdate();
						
						System.out.println("삭제 성공");
					} else {
						System.out.println("관리자 아님");
					}
					
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				dbu.close(rs, pstmt, conn);
			}
			
		}
		
		public List<BoardDto> cSelect() {
			
			DBUtil dbu = DBUtil.getInstance();
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			BoardDto bto = new BoardDto();
			List<BoardDto> list = new ArrayList<BoardDto>();
			
			try {
				conn = dbu.getConnection();
				
				StringBuilder sql = new StringBuilder("select * from board");
				pstmt = conn.prepareStatement(sql.toString());
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					bto.setArticle_no(rs.getInt("article_no"));
					bto.setUser_id(rs.getString("user_id"));
					bto.setSubject(rs.getString("subject"));
					bto.setContent(rs.getString("content"));
					bto.setRegister_time(rs.getString("resgister_time"));
					
					list.add(bto);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				dbu.close(rs, pstmt, conn);
			}
			
			return list;
		}

		public List<NoticeDto> nSelect() {
			
			DBUtil dbu = DBUtil.getInstance();
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			NoticeDto nto = new NoticeDto();
			List<NoticeDto> list = new ArrayList<NoticeDto>();
			
			try {
				conn = dbu.getConnection();
				
				StringBuilder sql = new StringBuilder("select * from notice_board");
				pstmt = conn.prepareStatement(sql.toString());
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					nto.setArticle_no(rs.getInt("article_no"));
					nto.setSubject(rs.getString("subject"));
					nto.setContent(rs.getString("content"));
					nto.setRegister_time(rs.getString("resgister_time"));
					
					list.add(nto);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return list;
		}

}
