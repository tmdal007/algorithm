<script setup>

</script>

<template>
  <section id="featured-services" class="featured-services">
    <div class="container">
      <div class="row gy-4">
        <!-- 이 달의 추천 여행지 -->
        <div class="col-xl-3 col-md-6 d-flex" data-aos="zoom-out">
          <div class="service-item position-relative">
            <div class="icon"><i class="bi bi-map-fill"></i></div>
            <h4>
              <a href="#" class="stretched-link"
                >추천 관광지</a
              >
            </h4>
            <p>여행지를 정하지 못하셨나요?</p>
            <p><b>Miyeo</b>가 추천하는 추천 관광지를 살펴보세요!</p>
          </div>
        </div>
        <!-- End Service Item -->

        <!-- 여행 계획 짜기 -->
        <div class="col-md-3 d-flex" data-aos="zoom-out" data-aos-delay="400">
          <div class="service-item position-relative">
            <div class="icon"><i class="bi bi-send-plus"></i></div>
            <h4>
              <router-link :to="{ name: 'plans' }" class="stretched-link">여행 계획</router-link>
            </h4>
            <p>여행을 떠나시나요?</p>
            <p>나만의 여행 계획을 짜고, 공유해보세요!</p>
          </div>
        </div>
        <!-- End Service Item -->

        <!-- 후기 보기 -->
          <div
          class="col-xl-3 col-md-3 d-flex"
          data-aos="zoom-out"
          data-aos-delay="200"
        >
          <div class="service-item position-relative">
            <div class="icon"><i class="bi bi-file-earmark-check-fill"></i></div>
            <h4>
              <a href="#recommandreview" class="stretched-link">후기 확인하기</a>
            </h4>

            <p>다른 사람의 여행 후기가 궁금하신가요?</p>
            <p>후기를 확인하고 여행 계획을 세워봅시다!</p>
          </div>
        </div>
        <!-- End Service Item -->

        <!-- 가입 -->
        <div class="col-md-3 d-flex" data-aos="zoom-out" data-aos-delay="600">
          <div class="service-item position-relative">
            <div class="icon"><i class="bi bi-person-gear"></i></div>
            <h4>
              <router-link :to="{ name: 'user-join' }" class="stretched-link">나만의 계획</router-link>
            </h4>
            <p>아직 회원이 아니신가요?</p>
            <p><b>Miyeo</b>에 가입하고 계획을 세워보세요!</p>
          </div>
        </div>
        <!-- End Service Item -->
      </div>
    </div>
  </section>
</template>

<style>
@font-face {
  font-family: "Pretendard-Regular";
  src: url("https://cdn.jsdelivr.net/gh/Project-Noonnu/noonfonts_2107@1.1/Pretendard-Regular.woff")
    format("woff");
  font-weight: 400;
  font-style: normal;
}
.featured-services .service-item {
  padding: 30px;
  transition: all ease-in-out 0.4s;
  background: var(--color-white);
  height: 100%;
  width: 100%;
  box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
}
.featured-services .service-item .icon {
  margin-bottom: 10px;
  color: var(--color-primary);
  font-size: 36px;
  transition: 0.3s;
}
.featured-services .service-item h4 {
  font-weight: 600;
  margin-bottom: 15px;
  font-size: 24px;
}
.featured-services .service-item h4 a {
  color: var(--color-secondary);
  transition: ease-in-out 0.3s;
}
.featured-services .service-item p {
  line-height: 24px;
  font-size: 14px;
  margin-bottom: 0;
}
.featured-services .service-item:hover {
  transform: translateY(-10px);
  /* box-shadow: 0px 20px 60px 5px rgba(var(--color-secondary-rgb), 0.2); */
  /* box-shadow: 0px 10px 35px rgba(0, 0, 0, 0.5); */
  border: 1px solid (0, 0, 0, 0.5);
}
.featured-services .service-item::after {
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  box-shadow: 0px 10px 35px rgba(0, 0, 0, 0.3);

  opacity: 0;
  transition: ease-in-out 0.5s;
}
.featured-services .service-item:hover::after {
  opacity: 1;
}
.featured-services .service-item:hover h4 a {
  color: var(--color-primary);
}

.stretched-link {
  display: block;
  width: 100%;
  height: 100%;
}
</style>
