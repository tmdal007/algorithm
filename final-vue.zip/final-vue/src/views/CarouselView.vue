<script setup>
</script>

<template>
  <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
    <ol class="carousel-indicators">
      <li data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"></li>
      <li data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"></li>
      <li data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100" src="@/assets/ai3.png" alt="First slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="@/assets/ai3.png" alt="Second slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="@/assets/ai3.png" alt="Third slide">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only"></span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only"></span>
    </a>
  </div>
</template>

<style scoped>
/* 숫자 제거 */
.carousel-indicators li {
  text-indent: -9999px; /* 숫자를 화면에서 보이지 않도록 숨김 */
}

/* 숫자가 점으로 표시되는 경우 */
.carousel-indicators {
  list-style: none; /* 기본 list 스타일 제거 */
}

/* 필요 시 추가로 여백을 줄이기 위해 */
.carousel-indicators li {
  width: 10px; /* 점 크기 조정 */
  height: 10px;
  margin: 5px;
  border-radius: 50%; /* 원형으로 유지 */
  background-color: gray; /* 점 색상 */
}
</style>
