<script setup>
import { ref } from "vue";
import UserNavbar from "@/components/layout/UserNavbar.vue";
import ThePlanList from "@/components/plans/ThePlanList.vue";
import DayPlans from "@/components/plans/DayPlans.vue";
import PKakaoMap from "@/components/plans/PKakaoMap.vue";

const selectedPlanNo = ref(null);
const selectedDayPlanNo = ref(null);
const mapComponent = ref(null); // PKakaoMap 컴포넌트 참조

const handlePlanSelect = (planNo) => {
  selectedPlanNo.value = planNo;
  selectedDayPlanNo.value = null;
};

const handleDayPlanSelect = (dayPlanNo) => {
  selectedDayPlanNo.value = dayPlanNo;
};

const handleAttractionsReordered = (data) => {
  if (mapComponent.value) {
    mapComponent.value.updateAttractions(data.attractions);
  }
};
</script>

<template>
  <div class="plan-container">
    <UserNavbar />
    <div class="plan-content">
      <!-- 여행 계획 리스트를 화면 위쪽 중앙에 배치 -->
      <div class="plan-list-container">
        <ThePlanList @selectPlan="handlePlanSelect" />
      </div>
      <div class="dayplan-map-container" v-if="selectedPlanNo">
        <DayPlans
          :planNo="selectedPlanNo"
          @selectDayPlan="handleDayPlanSelect"
          @attractionsReordered="handleAttractionsReordered"
        />
        <PKakaoMap
          v-if="selectedDayPlanNo"
          ref="mapComponent"
          :dayPlanNo="selectedDayPlanNo"
        />
      </div>
    </div>
  </div>
</template>

<style scoped>
.plan-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: white;
  min-height: 100vh;
}

.plan-content {
  margin-top: 30px;
  width: 80%;
  max-width: 1200px;
  position: relative;
}

h2 {
  text-align: center;
  margin-bottom: 20px;
  color: black;
}

/* ThePlanList를 화면 위쪽 중앙에 배치 */
.plan-list-container {
  display: flex;
  justify-content: center; /* 가로 중앙 정렬 */
  margin-top: 10px; /* 화면 상단에서 간격 */
  margin-bottom: 20px; /* ThePlanList와 아래 컨텐츠 간격 */
}

.dayplan-map-container {
  display: flex;
  align-items: flex-start; /* 두 컴포넌트를 위쪽으로 정렬 */
  gap: 20px; /* 컴포넌트 사이 간격 */
  margin-top: 20px; /* 전체 컨테이너의 상단 간격 */
}

.dayplan-map-container > * {
  flex: 1;
  max-width: 50%;
  margin: 0; /* 컴포넌트 자체 여백 제거 */
  padding: 0; /* 컴포넌트 내부 여백 제거 */
}


@media (max-width: 768px) {
  .dayplan-map-container {
    flex-direction: column;
  }

  .dayplan-map-container > * {
    max-width: 100%;
  }
}
</style>
