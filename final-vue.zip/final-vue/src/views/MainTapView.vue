<template>
    <div class="carousel-container">
      <!-- 텍스트 섹션 -->
      <div class="text-section">
        <div class="badge">이달의 추천여행지</div>
        <h2>{{ slides[currentSlide].title }}</h2>
        <a href="#" class="detail-link">자세히 보기</a>
  
        <!-- 하단 컨트롤러 -->
        <div class="carousel-controls">
          <span class="current-slide">{{ currentSlide + 1 }}</span>/<span class="total-slide">{{ slides.length }}</span>
          <button class="control-btn" @click="prevSlide">←</button>
          <button class="control-btn" @click="togglePlayPause">{{ isPlaying ? '⏸' : '▶' }}</button>
          <button class="control-btn" @click="nextSlide">→</button>
        </div>
      </div>
  
      <!-- 이미지 섹션 -->
      <div class="image-section">
        <img :src="slides[currentSlide].image" :alt="slides[currentSlide].title" class="main-image" />
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted, onBeforeUnmount } from "vue";
  import image1 from "@/assets/test1.jpg"; // 이미지 파일 가져오기
  import image2 from "@/assets/test2.jpg"; // 이미지 파일 가져오기
  import image3 from "@/assets/test3.jpg"; // 이미지 파일 가져오기
  
  // 캐러셀 데이터
  const slides = ref([
    { title: "금강산도 식후경! 광주 식도락 여행", image: image1 },
    { title: "아름다운 해안길! 부산 바다 여행", image: image2 },
    { title: "단풍이 가득한 설악산 가을 트레킹", image: image3 },
  ]);
  
  const currentSlide = ref(0); // 현재 슬라이드 인덱스
  const isPlaying = ref(true); // 자동 재생 상태
  let slideInterval = null;
  
  // 다음 슬라이드로 이동
  const nextSlide = () => {
    currentSlide.value = (currentSlide.value + 1) % slides.value.length;
  };
  
  // 이전 슬라이드로 이동
  const prevSlide = () => {
    currentSlide.value = (currentSlide.value - 1 + slides.value.length) % slides.value.length;
  };
  
  // 자동 재생 토글
  const togglePlayPause = () => {
    isPlaying.value = !isPlaying.value;
    if (isPlaying.value) {
      startAutoPlay();
    } else {
      stopAutoPlay();
    }
  };
  
  // 자동 재생 시작
  const startAutoPlay = () => {
    stopAutoPlay(); // 중복 방지
    slideInterval = setInterval(nextSlide, 3000); // 3초 간격
  };
  
  // 자동 재생 중지
  const stopAutoPlay = () => {
    if (slideInterval) {
      clearInterval(slideInterval);
      slideInterval = null;
    }
  };
  
  // 컴포넌트가 마운트될 때 자동 재생 시작
  onMounted(() => {
    startAutoPlay();
  });
  
  // 컴포넌트가 언마운트될 때 자동 재생 중지
  onBeforeUnmount(() => {
    stopAutoPlay();
  });
  </script>
  
  <style scoped>
  /* 글로벌 폰트 설정 */
  @font-face {
    font-family: "Pretendard-Regular";
    src: url("https://cdn.jsdelivr.net/gh/Project-Noonnu/noonfonts_2107@1.1/Pretendard-Regular.woff")
      format("woff");
    font-weight: 400;
    font-style: normal;
  }
  
  /* 전체 컨테이너 */
  .carousel-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #e9e6d3; /* 배경색 */
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    font-family: "Pretendard-Regular"; /* 폰트 적용 */
  }
  
  /* 텍스트 섹션 */
  .text-section {
    flex: 1;
    margin-right: 20px;
  }
  
  .badge {
    display: inline-block;
    background-color: black;
    color: white;
    font-size: 0.9rem;
    font-weight: bold;
    padding: 5px 10px;
    border-radius: 5px;
    margin-bottom: 10px;
    font-family: "Pretendard-Regular"; /* 폰트 적용 */
  }
  
  h2 {
    font-size: 1.7rem;
    color: #333;
    margin-bottom: 20px;
    font-family: "Pretendard-Regular"; /* 폰트 적용 */
  }
  
  .detail-link {
    color: #007bff;
    text-decoration: none;
    font-size: 1rem;
    margin-bottom: 20px;
    display: block;
    font-family: "Pretendard-Regular"; /* 폰트 적용 */
  }
  
  .detail-link:hover {
    text-decoration: underline;
  }
  
  /* 이미지 섹션 */
  .image-section {
    position: relative;
    flex: 1.0; /* 더 큰 영역 차지 */
    display: flex;
    justify-content: flex-end;
  }
  
  .main-image {
    width: 450px; /* 더 큰 이미지 크기 */
    height: 350px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  }
  
  /* 하단 컨트롤러 */
  .carousel-controls {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    margin-top: 20px;
    font-family: "Pretendard-Regular"; /* 폰트 적용 */
  }
  
  .current-slide {
    font-size: 1.2rem;
    font-weight: bold;
    margin-right: 5px;
  }
  
  .total-slide {
    font-size: 1.2rem;
    margin-right: 20px;
  }
  
  .control-btn {
    background: none;
    border: none;
    font-size: 1.2rem;
    cursor: pointer;
    margin: 0 5px;
    color: #333;
  }
  
  .control-btn:hover {
    color: #007bff;
  }
  </style>
  