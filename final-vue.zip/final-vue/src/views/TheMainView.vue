<script setup>
import { ref } from "vue";
import WeatherView from "@/components/weather/WeatherView.vue";
import Chatbot from "@/components/chatbot/Chatbot.vue";
import CarouselView from "@/views/CarouselView.vue";
import MainTapView from "@/views/MainTapView.vue";
import TapListView from "@/views/TapListView.vue";
import MainRecommend from "@/views/MainRecommend.vue";

const isChatbotOpen = ref(false); // Chatbot 모달 상태

const openChatbot = () => {
  isChatbotOpen.value = true;
};

const closeChatbot = () => {
  isChatbotOpen.value = false;
};
</script>

<template>
  <div class="container mt-4">
    <!-- 메인 탭 뷰 -->
    <div id="recommandview">
      <MainTapView />
    </div>

    <div class="tap-container">
      <TapListView />
    </div>

    <!-- 날씨 섹션 -->
    <div class="weather-container shadow-container" style="margin-top: 50px;">
      <!-- 제목과 Chat 버튼 -->
      <div class="d-flex align-items-center justify-content-center">
        <h4 class="weather-title me-3">오늘의 날씨</h4>
        <button class="btn btn-sm btn-primary" @click="openChatbot">Chat</button>
      </div>

      <!-- 날씨 컴포넌트 -->
      <div class="d-flex justify-content-center">
        <WeatherView />
      </div>
    </div>

    <!-- Chatbot 모달 -->
    <div
      class="modal"
      tabindex="-1"
      :class="{ show: isChatbotOpen }"
      :style="{ display: isChatbotOpen ? 'block' : 'none' }"
    >
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Chat with us</h5>
            <button
              type="button"
              class="btn-close"
              @click="closeChatbot"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <Chatbot />
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeChatbot">
              Close
            </button>
          </div>
        </div>
      </div>
    </div>

    <MainRecommend />
  </div>
</template>

<style scoped>
/* 전체 페이지 레이아웃 */
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 10px;
  background-color: #fff;
  border-radius: 10px;
}

/* 날씨 섹션 스타일 */
.weather-container {
  text-align: center;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 10px;
}

/* 그림자 추가 */
.shadow-container {
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

/* 제목 스타일 */
.weather-title {
  font-size: 1.5rem;
  font-weight: bold;
  color: #333;
}

/* Chat 버튼 스타일 */
.btn-primary {
  padding: 5px 10px;
  font-size: 0.9rem;
}

.tap-container {
  margin-top: 20px;
}

/* 반응형 레이아웃 */
@media (max-width: 768px) {
  .weather-container {
    text-align: center;
  }

  .weather-title {
    font-size: 1.2rem;
  }

  .btn-primary {
    font-size: 0.8rem;
    padding: 4px 8px;
  }
}
</style>
