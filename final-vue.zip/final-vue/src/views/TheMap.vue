<script setup>
import { ref, onMounted } from 'vue';
import { KakaoMap, KakaoMapMarker } from 'vue3-kakao-maps';
import { useMemberStore } from '@/stores/member';
import { addToFavorites, deleteFavorite } from '@/api/like'; // deleteFavorite 추가
import { sidoList, attractionTypeList, attractionListJs } from '@/api/attraction';

const memberStore = useMemberStore();

const areas = ref([]); // 지역 정보
const trips = ref([]); // 관광지 유형
const selectedArea = ref('0'); // 선택된 지역
const selectedContentId = ref('0'); // 선택된 관광지 유형
const searchKeyword = ref(''); // 검색 키워드
const positions = ref([]); // 지도 마커 위치
const mapCenter = ref({ lat: 37.500613, lng: 127.036431 }); // 지도 중심
const attracionList = ref([]); // 관광지 목록

// 지역 정보 가져오기
const fetchAreas = async () => {
  sidoList(
    (response) => {
      const data = response.data;
      areas.value = data;
    },
    (error) => {
      console.error('Error fetching areas:', error);
    }
  );
};

// 관광지 유형 가져오기
const searchTrips = async () => {
  attractionTypeList(
    (response) => {
      const data = response.data;
      trips.value = data;
    },
    (error) => {
      console.error('Error fetching areas:', error);
    }
  );
};

// 관광지 목록 가져오기
const attractionList = async () => {
  let param = {};
  if (memberStore.isLogin) {
    param = {
      sidoCode: selectedArea.value,
      contentTypeId: selectedContentId.value,
      title: searchKeyword.value,
      userId: memberStore.userInfo.userId,
    };
  } else {
    param = {
      sidoCode: selectedArea.value,
      contentTypeId: selectedContentId.value,
      title: searchKeyword.value,
    };
  }

  attractionListJs(
    param,
    (response) => {
      const data = response.data;
      attracionList.value = data.map((item) => ({
        ...item,
        liked: item.liked ?? false, // liked 기본값 설정
      }));
      console.log('관광지 정보', attracionList.value);
    },
    (error) => {
      console.error('Error fetching attractions:', error);
    }
  );
};

// 지도 중심 이동
const moveCenter = (lat, lng) => {
  mapCenter.value = { lat, lng };
};

// 찜 상태 토글
const toggleLike = async (trip) => {
  const token = sessionStorage.getItem('accessToken');
  if (!token) {
    alert('로그인이 필요합니다.');
    return;
  }

  const userInfo = memberStore.userInfo;
  if (!userInfo) {
    alert('사용자 정보가 없습니다.');
    return;
  }

  const likeData = {
    userId: userInfo.userId,
    contentId: trip.contentId,
  };

  if (trip.liked) {
    // 찜 삭제
    await deleteFavorite(
      likeData,
      () => {
        trip.liked = false; // 상태 업데이트
        console.log('찜 삭제 완료:', trip.title);
      },
      (error) => {
        console.error('찜 삭제 실패:', error);
        alert('찜 삭제에 실패했습니다.');
      }
    );
  } else {
    // 찜 추가
    await addToFavorites(
      likeData,
      () => {
        trip.liked = true; // 상태 업데이트
        console.log('찜 추가 완료:', trip.title);
      },
      (error) => {
        console.error('찜 추가 실패:', error);
        alert('찜 추가에 실패했습니다.');
      }
    );
  }
};

onMounted(() => {
  fetchAreas();
  searchTrips();
});
</script>

<template>
  <div class="container">
    <div class="col-10 ms-4">
      <div class="title mt-3 text-center fw-bold" role="alert">
        여행지 검색
      </div>

      <!-- 검색 폼 -->
      <form class="d-flex my-3" @submit.prevent="attractionList">
        <select v-model="selectedArea" class="form-select me-2">
          <option value="0">광역시, 도</option>
          <option v-for="area in areas" :key="area.sidoCode" :value="area.sidoCode">
            {{ area.sidoName }}
          </option>
        </select>

        <select v-model="selectedContentId" class="form-select me-2">
          <option value="0">관광지 유형</option>
          <option v-for="type in trips" :key="type.attractionTypeId" :value="type.attractionTypeId">
            {{ type.attractionTypeName }}
          </option>
        </select>

        <input v-model="searchKeyword" class="form-control me-2" type="search" placeholder="검색어" />
        <button class="btn btn-outline-success" type="submit">검색</button>
      </form>

      <!-- 카카오 맵 -->
      <KakaoMap 
        :lat="mapCenter.lat" 
        :lng="mapCenter.lng" 
        :draggable="true"
        style="width: 100%; height: 400px"
      >
        <KakaoMapMarker 
          v-for="position in positions"
          :key="position.contentid"
          :lat="position.lat"
          :lng="position.lng"
          :options="{
            image: {
              src: getMarkerImageByType(position.type),
              size: { width: 24, height: 35 }
            }
          }"
          @click="moveCenter(position.lat, position.lng)"
        />
      </KakaoMap>

      <!-- 관광지 목록 -->
      <div class="row mt-3">
        <table class="table table-striped" v-if="attracionList.length">
          <thead>
            <tr>
              <th>대표이미지</th>
              <th>관광지명</th>
              <th>주소</th>
              <th>찜</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="attraction in attracionList"
              :key="attraction.contentId"
              @click="moveCenter(attraction.latitude, attraction.longitude)"
            >
              <td><img :src="attraction.firstImage1" width="100px" /></td>
              <td>{{ attraction.title }}</td>
              <td>{{ attraction.addr1 }} {{ attraction.addr2 }}</td>
              <td>
                <button
                  class="btn btn-sm btn-primary"
                  @click.stop="toggleLike(attraction)"
                >
                  {{ attraction.liked ? "♥" : "♡" }}
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
