<script setup></script>

<template>
  <div
    class="container my-5"
    id="recommandreview"
    style="font-family: 'Pretendard-Regular', sans-serif"
  >
    <div
      class="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg"
    >
      <div class="col-lg-12 p-3 p-lg-5 pt-lg-3">
        <h2
          class="display-4 fw-bold lh-1 text-body-emphasis"
          style="margin-top: 10px; margin-bottom: 30px; font-size: 2.0rem;"
        >
          이 달의 추천 후기
        </h2>
        <div class="flex-container">
          <div
            class="flex-item content h-100 p-4 bg-body-tertiary border rounded-3"
          >
            <h2 class="h4"><b>수정</b></h2>
            <p class="small">
              수정
            </p>
            <img
              class="rounded-lg-3 mb-3"
              src="@/assets/ai1.jpg"
              alt=""
              style="object-fit: cover; height: 200px;"
            />
            <button class="btn btn-sm btn-outline-secondary" type="button">
              자세히 보기
            </button>
          </div>

          <div
            class="flex-item content h-100 p-4 bg-body-tertiary border rounded-3"
          >
            <h2 class="h4"><b>수정</b></h2>
            <p class="small">
              수정
            </p>
            <img
              class="rounded-lg-3 mb-3"
              src="@/assets/ai2.jpg"
              alt=""
              style="object-fit: cover; height: 200px;"
            />
            <button class="btn btn-sm btn-outline-secondary" type="button">
              자세히 보기
            </button>
          </div>

          <div
            class="flex-item content h-100 p-4 bg-body-tertiary border rounded-3"
          >
            <h2 class="h4"><b>수정</b></h2>
            <p class="small">
              수정
            </p>
            <img
              class="rounded-lg-3 mb-3"
              src="@/assets/ai3.png"
              alt=""
              style="object-fit: cover; height: 200px;"
            />
            <button class="btn btn-sm btn-outline-secondary" type="button">
              자세히 보기
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@font-face {
  font-family: "Pretendard-Regular";
  src: url("https://cdn.jsdelivr.net/gh/Project-Noonnu/noonfonts_2107@1.1/Pretendard-Regular.woff")
    format("woff");
  font-weight: 400;
  font-style: normal;
}
.flex-container {
  display: flex;
  gap: 15px; /* 더 균등한 간격 */
}

.flex-item {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.flex-item:hover {
  transform: scale(1.05);
  transition: transform 0.5s ease;
}

.content {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
}

img {
  width: 100%;
  max-height: 200px;
  object-fit: cover;
}

.btn-outline-secondary {
  align-self: flex-start;
  margin-top: 10px;
}
</style>