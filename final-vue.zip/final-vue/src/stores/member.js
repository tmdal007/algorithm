import { ref, nextTick } from "vue";
import { useRouter } from "vue-router";
import { defineStore } from "pinia";
import { useMenuStore } from "@/stores/menu"; // 메뉴 store 추가
import { jwtDecode } from "jwt-decode";

import { userConfirm, findById, tokenRegeneration, logout, updateUserField } from "@/api/user";
import { httpStatusCode } from "@/util/http-status";

export const useMemberStore = defineStore("memberStore", () => {
  const router = useRouter();
  const menuStore = useMenuStore(); // 메뉴 상태 관리
  const isLogin = ref(false);
  const isLoginError = ref(false);
  const userInfo = ref(null);
  const isValidToken = ref(false);

  const initializeLoginState = async () => {
    const token = sessionStorage.getItem("accessToken");
    if (token) {
      try {
        // 토큰 유효성 검증 및 사용자 정보 로드
        await getUserInfo(token);
        isLogin.value = true;
        isValidToken.value = true;
        menuStore.updateMenuState(true); // 메뉴 상태 업데이트
      } catch (error) {
        console.error("로그인 상태 초기화 실패:", error);
        await userLogout(); // 토큰이 유효하지 않으면 로그아웃 처리
      }
    } else {
      isLogin.value = false;
      isValidToken.value = false;
      menuStore.updateMenuState(false);
    }
  };

  const userLogin = async (loginUser) => {
    await userConfirm(
      loginUser,
      (response) => {
        if (response.status === httpStatusCode.CREATE) {
          let { data } = response;
          let accessToken = data["access-token"];
          let refreshToken = data["refresh-token"];
          isLogin.value = true;
          isLoginError.value = false;
          isValidToken.value = true;
          sessionStorage.setItem("accessToken", accessToken);
          sessionStorage.setItem("refreshToken", refreshToken);
          menuStore.updateMenuState(true); // 로그인 후 메뉴 업데이트
        }
      },
      (error) => {
        isLogin.value = false;
        isLoginError.value = true;
        isValidToken.value = false;
        console.error(error);
      }
    );
  };

  const getUserInfo = async (token) => {
    try {
      const decodeToken = jwtDecode(token);
      console.log("Decoded Token:", decodeToken);
      await findById(
        decodeToken.userId,
        (response) => {
          console.log("API 응답:", response); // 디버깅 추가
          if (response.status === httpStatusCode.OK) {
            console.log("User Info:", response.data.userInfo); // 디버깅 추가
            userInfo.value = response.data.userInfo;
          } else {
            console.log("유저 정보 없음!!!!");
          }
        },
        async (error) => {
          console.error(
            "토큰 만료되어 사용 불가능: ",
            error.response.status,
            error.response.statusText
          );
          isValidToken.value = false;
          // 토큰 재발급 시도
          try {
            await tokenRegenerate();
          } catch (regenerateError) {
            // 토큰 재발급 실패 시 로그아웃 처리
            await userLogout();
            // 로그인 페이지로 리다이렉트
            router.push({ name: `user-login` });
          }
        }
      );
    } catch (error) {
      console.error("getUserInfo 실패:", error); // 디버깅 추가
      // 예외 발생 시에도 로그아웃 처리
      await userLogout();
      router.push({ name: "user-login" });
    }
  };

  const userLogout = async () => {
    if (userInfo.value?.userId) {
      await logout(userInfo.value.userId);
    }
    isLogin.value = false;
    userInfo.value = null;
    isValidToken.value = false;
    sessionStorage.removeItem("accessToken");
    sessionStorage.removeItem("refreshToken");
    // 메뉴 상태 강제 업데이트
    menuStore.updateMenuState(false);

    // 상태 변경 후 강제 UI 갱신
    await nextTick(); // Vue에서 DOM 변경이 완료된 후 UI 갱신 강제 트리거
  };

  // 회원 정보 업데이트 (비밀번호/이메일)
  // member.js의 defineStore 내부에 추가할 함수
const updateUser = async (params) => {
    try {
      await updateUserField(
        params,
        (response) => {
          if (response.status === httpStatusCode.OK) {
            // 사용자 정보 업데이트 성공
            if (params.column === "email") {
              userInfo.value = {
                ...userInfo.value,
                email: params.value
              };
            }
            return true;
          }
          return false;
        },
        (error) => {
          console.error("사용자 정보 업데이트 실패:", error);
          throw error;
        }
      );
    } catch (error) {
      throw error;
    }
  };

  return {
    isLogin,
    isLoginError,
    userInfo,
    isValidToken,
    initializeLoginState,
    userLogin,
    getUserInfo,
    userLogout,
    updateUser,
  };
});
