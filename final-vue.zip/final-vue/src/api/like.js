import { localAxios } from "@/util/http-commons";

const local = localAxios();

/**
 * 관광지 찜하기 추가
 * @param {Object} likeData - 찜할 데이터 (userId, attractionNo)
 * @param {Function} success - 성공 시 호출할 콜백 함수
 * @param {Function} fail - 실패 시 호출할 콜백 함수
 */
function addToFavorites(data, success, fail) {
  local
    .post(`/like/attraction`,  data )
    .then(success)
    .catch(fail);
}

/**
 * 찜한 관광지 중복 확인
 * @param {string} userId - 사용자 ID
 * @param {string} title - 관광지 제목
 * @param {Function} success - 성공 시 호출할 콜백 함수
 * @param {Function} fail - 실패 시 호출할 콜백 함수
 */
function checkIfLiked(userId, title, success, fail) {
  local
    .get(`/like/exists`, { params: { userId, title } })
    .then(success)
    .catch(fail);
}

/**
 * 찜한 관광지 삭제
 * @param {Object} attractionNo - 관광지 ID
 * @param {Function} success - 성공 시 호출할 콜백 함수
 * @param {Function} fail - 실패 시 호출할 콜백 함수
 */
function deleteFavorite(data, success, fail) {
  local
    .delete(`/like/attraction`,{ data })
    .then(success)
    .catch(fail);
}

/**
 * 찜한 관광지 목록 조회
 * @param {string} userId - 사용자 ID
 * @param {Function} success - 성공 시 호출할 콜백 함수
 * @param {Function} fail - 실패 시 호출할 콜백 함수
 */
function getFavoriteList(userId, success, fail) {
  local
    .get(`/like/attractionList`, { params: { userId } })
    .then(success)
    .catch(fail);
}

export { addToFavorites, checkIfLiked, deleteFavorite, getFavoriteList };
