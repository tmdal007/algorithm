import { fileAxios, localAxios } from "@/util/http-commons";

// 로컬 API 호출을 위한 Axios 인스턴스
const local = localAxios();
const file = fileAxios();

async function writeReview(form) {
  console.log("review write ", form);
  try {
    const response = await local.post(`/posts/write`, form);
    console.log("writeReview 응답:", response);
    return response; // Axios 응답을 반환
  } catch (error) {
    console.error("writeReview 실패:", error);
    throw error; // 오류를 상위 함수로 전달
  }
}

async function writeReviewFile(formData, success, fail) {
  console.log("review post write file", formData);
  await file
    .post(`/posts/write/file`, formData)
    .then(success)
    .catch(fail);
}


/**
 * 특정 게시글의 정보를 조회합니다.
 *
 * @param {number} postNo - 조회하려는 게시글의 고유 번호
 * @param {Function} success - API 호출 성공 시 실행되는 콜백 함수
 * @param {Function} fail - API 호출 실패 시 실행되는 콜백 함수
 */
function getPost(postNo, success, fail) {
  local
    .get(`/posts/${postNo}`)
    .then(success)
    .catch(fail);
}

/**
 * 특정 플랜에 연결된 게시글들을 조회합니다.
 *
 * @param {number} planNo - 플랜의 고유 번호
 * @param {Function} success - API 호출 성공 시 실행되는 콜백 함수
 * @param {Function} fail - API 호출 실패 시 실행되는 콜백 함수
 */
function getPostsByPlan(planNo, success, fail) {
  local
    .get(`/posts/${planNo}`)
    .then(success)
    .catch(fail);
}

/**
 * 전체 여행 후기 목록을 가져옵니다.
 *
 * @param {Function} success - API 호출 성공 시 실행되는 콜백 함수
 * @param {Function} fail - API 호출 실패 시 실행되는 콜백 함수
 */
function getAllPosts(success, fail) {
  local
    .get(`/posts`)
    .then(success)
    .catch(fail);
}

/**
 * 특정 사용자의 여행 후기 목록을 가져옵니다.
 *
 * @param {string} userId - 조회할 사용자의 ID
 * @param {Function} success - API 호출 성공 시 실행되는 콜백 함수
 * @param {Function} fail - API 호출 실패 시 실행되는 콜백 함수
 */
function getPostsByUser(userId, success, fail) {
  local
    .get(`/posts/user/${userId}`)
    .then(success)
    .catch(fail);
}

/**
 * 조회수가 많은 순으로 후기 목록을 가져옵니다.
 *
 * @param {Function} success - API 호출 성공 시 실행되는 콜백 함수
 * @param {Function} fail - API 호출 실패 시 실행되는 콜백 함수
 */
function getTopHitsPosts(success, fail) {
  local
    .get(`/posts/top-hits`)
    .then(success)
    .catch(fail);
}

/**
 * 게시글을 수정합니다.
 *
 * @param {number} postNo - 수정하려는 게시글의 고유 번호
 * @param {FormData} formData - 수정할 게시글 정보와 파일 데이터를 포함하는 FormData 객체
 * @param {Function} success - API 호출 성공 시 실행되는 콜백 함수
 * @param {Function} fail - API 호출 실패 시 실행되는 콜백 함수
 */
function updatePost(postNo, formData, success, fail) {
  local
    .put(`/posts/${postNo}`, formData, {
      headers: { "Content-Type": "multipart/form-data" }, // 수정 시에도 파일 업로드를 처리
    })
    .then(success)
    .catch(fail);
}

/**
 * 게시글을 삭제합니다.
 *
 * @param {number} postNo - 삭제하려는 게시글의 고유 번호
 * @param {Function} success - API 호출 성공 시 실행되는 콜백 함수
 * @param {Function} fail - API 호출 실패 시 실행되는 콜백 함수
 */
function deletePost(postNo, success, fail) {
  local
    .delete(`/posts/${postNo}`)
    .then(success)
    .catch(fail);
}




export {
  writeReview,
  writeReviewFile,
  getAllPosts,
  getTopHitsPosts,
  // createPost,
  getPost,
  getPostsByPlan,
  updatePost,
  deletePost,
  getPostsByUser,
};
