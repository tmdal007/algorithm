import { localAxios } from "@/util/http-commons";

const local = localAxios();

function sidoList(success, fail) {
  console.log("sidolist ");
  local.get(`/attraction/sido`).then(success).catch(fail);
}

function gugunList(selectedSido, success, fail) {
  console.log("gugunlist in ", selectedSido);
  local.get(`/attraction/gugun/${selectedSido}`).then(success).catch(fail);
}

function attractionTypeList(success, fail) {
  console.log("attractionTypeList ");
  local.get(`/attraction/attractionType`).then(success).catch(fail);
}

function attractionListJs(data, success, fail) {
  local
    .post(`/attraction/list`, data)
    .then(success)
    .catch(fail);
}

function getAttration(contentId, success, fail) {
  console.log("getAttraction in ", contentId);
  local.get(`/attraction/getAttraction/${contentId}`).then(success).catch(fail);
}

function getAttrationNo(attractionNo, success, fail) {
  console.log("getAttractionNo in ", attractionNo);
  local.get(`/attraction/getAttractionNo/${attractionNo}`).then(success).catch(fail);
}

function getOverview(contentId, success, fail) {
  local.get(`/attraction/getOverview/${contentId}`).then(success).catch(fail);
}

export { sidoList, gugunList, attractionListJs, getAttration,getAttrationNo, getOverview, attractionTypeList };
