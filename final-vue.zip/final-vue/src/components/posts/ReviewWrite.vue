<script setup>
import { ref, computed } from "vue";
import { useRouter, useRoute } from "vue-router";
import { useMemberStore } from "@/stores/member";
import {writeReview, writeReviewFile} from "@/api/post.js";
import { storeToRefs } from "pinia";

const router = useRouter();
const route = useRoute();

const memberStore = useMemberStore();
const { userInfo } = storeToRefs(memberStore);

// Route에서 Plan 정보 가져오기
const planNo = ref(route.params.planNo || null);
const planName = ref(route.query.planName || "");
const startDate = ref(route.query.startDate || "");
const endDate = ref(route.query.endDate || "");

// 리뷰 작성 폼 데이터
const form = ref({
  content: "",
  score: 0,
  person: 1,
  money: 0,
  userId: userInfo.value.userId,
  planNo: planNo.value, // planNo 추가
});
const postNo = ref(0);

// 파일 데이터 관리
const file = ref(null);
const preview = ref(null);

// 이미지 객체
const image = ref({
  file: null,
  preview: null,
});

// 파일 선택 시 처리
const handleFileChange = (event) => {
  image.file = event.target.files[0];
  image.value.preview = URL.createObjectURL(event.target.files[0]);
};

// 리뷰 작성/등록 함수
const handleSubmit = async () => {
  if (!planNo.value) {
    alert("유효하지 않은 Plan 정보입니다.");
    return;
  }

  try {
    // 첫 번째 요청: 리뷰 작성
    const reviewResponse = await writeReview({
      planNo: planNo.value,
      content: form.value.content,
      score: form.value.score,
      person: form.value.person,
      money: form.value.money,
      userId: userInfo.value.userId,
    });

    console.log("writeReview 응답:", reviewResponse);
    // reviewResponse가 유효한지 확인
    if (!reviewResponse || !reviewResponse.data) {
      throw new Error("리뷰 작성 요청 실패");
    }

    postNo.value = reviewResponse.data; // 응답에서 postNo 설정

    // 두 번째 요청: 파일 업로드
    if (image.file) {
      const formData = new FormData();
      formData.append("upfile", image.file);
      formData.append("postNo", postNo.value);

      const fileResponse = await writeReviewFile(formData);

      console.log("파일 업로드 성공:", fileResponse);
    }

    // 성공 후 페이지 이동
    moveList();
  } catch (error) {
    console.error("작성 중 오류 발생:", error);
    alert("작성 중 오류가 발생했습니다. 다시 시도해주세요.");
  }
};



// ReviewList.vue로 이동
const moveList = () => {
  router.push({ name: "post-list"});
};

</script>

<template>
  <div class="container mt-5 mb-5">
    <!-- 여행 계획 정보 -->
    <div v-if="planNo" class="plan-details mb-4">
      <h4 class="fw-bold">여행 계획 정보</h4>
      <p><strong>여행 이름:</strong> {{ planName }}</p>
      <p><strong>기간:</strong> {{ startDate }} ~ {{ endDate }}</p>
    </div>

    <!-- 리뷰 작성/수정 폼 -->
    <div class="review-form">
      <h3 class="fw-bold mb-4">리뷰 작성</h3>
      <form @submit.prevent="handleSubmit">
        <div class="mb-3">
          <label for="content" class="form-label">내용:</label>
          <textarea 
            id="content" 
            class="form-control" 
            v-model="form.content" 
            rows="10" 
            required
          ></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label">별점:</label>
          <div class="star-rating">
            <span 
              v-for="star in 5" 
              :key="star" 
              class="star fs-3"
              :class="{ 'text-warning': star <= form.score }"
              @click="form.score = star"
            >
              ★
            </span>
            <span class="ms-2">{{ form.score }}점</span>
          </div>
        </div>
        <div class="mb-3">
          <label for="person" class="form-label">인원:</label>
          <input
            type="number"
            id="person"
            class="form-control"
            v-model.number="form.person"
            required
          />
        </div>
        <div class="mb-3">
          <label for="money" class="form-label">예산:</label>
          <input
            type="number"
            id="money"
            class="form-control"
            v-model.number="form.money"
            required
          />
        </div>
        <div class="mb-3">
          <label for="file" class="form-label">이미지 업로드:</label>
          <input
            type="file"
            id="file"
            class="form-control"
            @change="handleFileChange"
          />
        </div>

        <!-- 이미지 미리보기 -->
        <div v-if="image.preview" class="mb-3">
          <h5>미리보기</h5>
          <img :src="image.preview" alt="이미지 미리보기" class="img-thumbnail" />
        </div>

        <div class="text-center">
          <button 
            type="submit" 
            class="btn btn-primary me-2"
          >
            작성
          </button>
          <button 
            type="button" 
            class="btn btn-secondary"
            @click="moveList"
          >
            취소
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<style scoped>
.star-rating .star {
  cursor: pointer;
  color: #dee2e6;
  transition: color 0.2s;
}

.star-rating .star:hover,
.star-rating .star:hover ~ .star {
  color: #ffc107;
}

.plan-details {
  background-color: #f8f9fa;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
</style>
