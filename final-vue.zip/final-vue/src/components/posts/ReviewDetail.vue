<script>
  import { getPostsByPlan } from "@/api/post";
  import { useMemberStore } from "@/stores/member"; // 사용자 정보 가져오기
  
  export default {
    name: "ReviewDetailModal",
    props: {
      postNo: {
        type: Number,
        required: true,
      },
    },
    data() {
      return {
        post: null, // 특정 후기 데이터를 저장
      };
    },
    computed: {
      currentUser() {
        const memberStore = useMemberStore();
        return memberStore.userInfo; // 로그인된 사용자 정보
      },
    },
    created() {
      if (this.postNo) {
        this.fetchPost(this.postNo);
      }
    },
    methods: {
      fetchPost(postNo) {
        getPostsByPlan(
          postNo,
          (response) => {
            this.post = response.data;
          },
          (error) => {
            console.error("후기 데이터를 불러오는 중 오류 발생:", error);
          }
        );
      },
      getImagePath(folder, fileName) {
        return folder && fileName ? `/${folder}/${fileName}` : null;
      },
      close() {
        this.$emit("close");
      },
      delete() {
        if (this.post) {
          this.$emit("delete", this.post.postNo, this.post.userId); // 부모로 이벤트 전달
        }
      },
    },
  };
</script>
<template>
    <div class="modal-backdrop" @click.self="close">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">여행 후기 상세</h5>
            <button type="button" class="btn-close" @click="close"></button>
          </div>
          <div class="modal-body">
            <div v-if="post" class="review-detail">
              <h2 class="text-center mb-4">{{ post.title }}</h2>
              <p class="text-muted text-center"><strong>작성자: {{ post.userId }}</strong></p>
              <div class="text-center mb-4">
                <img
                  v-if="post.saveFolder && post.saveFile"
                  :src="`/${post.saveFolder}/${post.saveFile}`"
                  alt="후기 이미지"
                  class="img-fluid rounded"
                />
              </div>
              <p><strong>여행 번호:</strong> {{ post.planNo }}</p>
              <p><strong>내용:</strong> {{ post.content }}</p>
              <p><strong>인원:</strong> {{ post.person }}</p>
              <p><strong>예산:</strong> {{ post.money }}</p>
              <p><strong>별점:</strong> {{ post.score }} / 5</p>
              <p><strong>작성일:</strong> {{ post.register }}</p>
            </div>
            <div v-else class="text-center mt-5">
              <p>후기 데이터를 불러오는 중입니다...</p>
            </div>
          </div>
          
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="close">
              닫기
            </button>
          </div>
        </div>
      </div>
    </div>
</template>

<style scoped>
.modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7); /* 어두운 배경 */
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1050;
  animation: fadeIn 0.3s ease-out; /* 페이드 인 애니메이션 */
}

.modal-dialog {
  width: 90%; /* 작은 화면에서도 잘 보이도록 */
  max-width: 800px; /* 최대 너비 제한 */
  margin: auto;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  animation: slideDown 0.3s ease-out; /* 팝업 슬라이드 다운 효과 */
}

.modal-header {
  padding: 15px;
  border-bottom: 1px solid #dee2e6;
  background-color: #f8f9fa;
  border-radius: 10px 10px 0 0;
}

.modal-body {
  padding: 20px;
}

.modal-footer {
  padding: 15px;
  border-top: 1px solid #dee2e6;
  background-color: #f8f9fa;
  border-radius: 0 0 10px 10px;
  display: flex;
  justify-content: flex-end;
}

.btn-close {
  background: none;
  border: none;
  font-size: 1.5rem;
  color: #000;
  cursor: pointer;
}

.review-detail img {
  max-height: 300px;
  object-fit: cover;
  margin-bottom: 20px;
  border-radius: 8px;
  border: 1px solid #ddd;
}

/* 애니메이션 */
@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes slideDown {
  from {
    transform: translateY(-20%);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
</style>
