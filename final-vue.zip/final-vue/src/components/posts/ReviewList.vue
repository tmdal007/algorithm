<template>
  <div class="container mt-4">
    <h2 class="text-center mb-4">여행 후기 목록</h2>
    <div class="row">
      <div
        v-for="post in posts"
        :key="post.postNo"
        class="col-12 col-md-6 col-lg-4 mb-4 d-flex"
      >
        <div
          class="card shadow-sm w-100 position-relative"
          @click="viewPost(post.postNo)"
        >
          <!-- 후기 이미지 -->
          <img
            v-if="post.saveFolder && post.saveFile"
            :src="`/${post.saveFolder}/${post.saveFile}`"
            class="card-img-top"
            alt="후기 이미지"
          />
          <div class="card-body">
            <!-- 후기 제목 -->
            <h5 class="card-title">{{ post.title }}</h5>
            <!-- 작성자(userId) -->
            <p class="text-muted">작성자: {{ post.userId }}</p>
            <!-- 내용 -->
            <!-- <p class="card-text text-truncate">{{ post.content }}</p> -->
            <!-- 삭제 버튼 -->
            <div class="d-flex justify-content-end mt-3">
              <button
                v-if="currentUser.userId === post.userId"
                class="btn btn-danger btn-sm"
                @click.stop="deletePost(post.postNo, post.userId)"
              >
                삭제
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 모달 컴포넌트 추가 -->
    <ReviewDetail 
      v-if="showModal" 
      :postNo="selectedPostNo"
      @close="closeModal"
      @delete="deletePost"
    />
  </div>
</template>

<script>
import { getAllPosts, deletePost } from "@/api/post"; // API 호출
import ReviewDetail from './ReviewDetail.vue'; // 모달 컴포넌트
import { useMemberStore } from "@/stores/member"; // 사용자 정보 가져오기

export default {
  name: "ReviewList",
  components: {
    ReviewDetail,
  },
  data() {
    return {
      posts: [], // 여행 후기를 저장할 배열
      selectedPostNo: null, // 선택된 게시물 번호를 저장할 상태
      showModal: false, // 모달 표시 상태
    };
  },
  computed: {
    // 현재 로그인된 사용자 정보
    currentUser() {
      const memberStore = useMemberStore();
      return memberStore.userInfo;
    },
  },
  created() {
    this.fetchPosts();
  },
  methods: {
    // 모든 여행 후기를 불러오는 함수
    fetchPosts() {
      getAllPosts(
        (response) => {
          this.posts = response.data;
        },
        (error) => {
          console.error("여행 후기 목록을 불러오는 중 오류 발생:", error);
        }
      );
    },
    // 특정 후기를 보는 함수
    viewPost(postNo) {
      this.selectedPostNo = postNo;
      this.showModal = true;
    },
    closeModal() {
      this.showModal = false;
      this.selectedPostNo = null;
    },
    // 삭제 처리 함수
    deletePost(postNo, userId) {
      if (this.currentUser.userId !== userId) {
        alert("삭제 권한이 없습니다.");
        return;
      }

      if (confirm("정말로 삭제하시겠습니까?")) {
        deletePost(
          postNo,
          () => {
            alert("후기가 성공적으로 삭제되었습니다.");
            this.fetchPosts(); // 삭제 후 목록 갱신
          },
          (error) => {
            console.error("후기 삭제 중 오류 발생:", error);
            alert("삭제에 실패했습니다.");
          }
        );
      }
    },
  },
};
</script>

<style scoped>
.card {
  position: relative;
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
}

.card-img-top {
  height: 180px;
  object-fit: cover;
}

.card-title {
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.card-text {
  font-size: 0.9rem;
  color: #6c757d;
}

.text-muted {
  font-size: 0.85rem;
}

.btn-danger {
  font-size: 0.8rem;
  color: #fff;
}
</style>
