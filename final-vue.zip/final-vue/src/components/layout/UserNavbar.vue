<script setup>
import { useRouter } from "vue-router";

const router = useRouter();

// 네비게이션 이동 함수
const navigateTo = (routeName) => {
  router.push({ name: routeName });
};
</script>

<template>
  <div class="mypage-header">
    <!-- <router-link :to="{ name: 'attraction' }" class="nav-link"
              ><i class="bi bi-map"></i> 지역별관광지</router-link
            > -->
    <span 
      :class="{ active: $route.name === 'myplan' }" 
      @click="navigateTo('myplan')">
      나의 계획
    </span>
    <span
      :class="{ active: $route.name === 'user-myreview' }" 
      @click="navigateTo('user-myreview')">
      나의 후기
    </span>
    <span 
      :class="{ active: $route.name === 'user-favorites' }" 
      @click="navigateTo('user-favorites')">
      즐겨찾기
    </span>
    <span 
      :class="{ active: $route.name === 'user-mypage' }" 
      @click="navigateTo('user-mypage')">
      회원정보 수정
    </span>
    <span 
      :class="{ active: $route.name === 'user-withdraw' }" 
      @click="navigateTo('user-withdraw')"
    >
      회원 탈퇴
    </span>
  </div>
</template>

<style scoped>
.mypage-header {
  display: flex;
  justify-content: center;
  margin-top: 20px;
  gap: 20px;
  font-size: 16px;
}

.mypage-header span {
  cursor: pointer;
  padding: 5px 10px;
  border-radius: 20px;
  color: #755645;
}

.mypage-header .active {
  background-color: #d5a67d;
  color: #fff;
}
</style>
