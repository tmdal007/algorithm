<script setup>
import VKakaoMap from "@/components/attraction/VKakaoMap.vue";
import { ref, onMounted } from "vue";
import { getFavoriteList } from "@/api/like";
import { useMemberStore } from "@/stores/member";
import noImage from "@/assets/no_image.jpg";

// 이벤트 정의
const emit = defineEmits(["select-attraction", "addPlan"]);

const userId = useMemberStore().userInfo?.userId || null; // 사용자 ID
const attractionList = ref([]); // 찜한 관광지 목록

// 찜한 관광지 목록 가져오기
const fetchFavorites = () => {
  if (!userId) {
    console.error("로그인하지 않은 사용자입니다.");
    return;
  }

  getFavoriteList(
    userId,
    ({ data }) => {
      attractionList.value = data.map((attraction) => ({
        ...attraction,
        latitude: attraction.latitude || 37.5665, // 기본 좌표 설정 (서울)
        longitude: attraction.longitude || 126.9780,
      }));
    },
    (error) => {
      console.error("Error fetching attractions:", error);
    }
  );
};

// 선택된 관광지를 부모로 emit
const emitAttraction = (attraction) => {
  emit("select-attraction", attraction);
};

// 지도와 관련된 상태 및 함수
const selectAttraction = ref(null); // 선택된 관광지 정보
const viewAttraction = (attraction) => {
  selectAttraction.value = attraction; // 선택된 관광지 정보 저장
};

// 마커 클릭 시 부모로 contentId 전달
const contentId = ref(0);
const addPlan = (markerContentId) => {
  contentId.value = markerContentId;
  emit("addPlan", markerContentId);
  console.log("마커 클릭 이벤트 발생, 전달된 contentId:", markerContentId);
};

// 컴포넌트 로드 시 데이터 가져오기
onMounted(() => {
  fetchFavorites();
});
</script>

<template>
  <div>
    <!-- 카카오 지도 -->
    <VKakaoMap
      :attractions="attractionList"
      :selectAttraction="selectAttraction"
      @addPlan="addPlan"
    />

    <!-- 관광지 리스트 -->
    <div class="attractions-container mt-3">
      <div v-if="attractionList.length > 0" class="row flex-nowrap px-3" style="overflow-x: auto;">
        <div v-for="attraction in attractionList" :key="attraction.contentId" class="col-auto">
          <div
            class="card attraction-card"
            style="width: 200px;"
            @click="emitAttraction(attraction); viewAttraction(attraction)"
          >
            <img
              :src="attraction.firstImage1 || noImage"
              class="card-img-top"
              :alt="attraction.title"
              style="height: 200px; object-fit: cover;"
            />
            <div class="card-body">
              <h5 class="card-title text-truncate">{{ attraction.title }}</h5>
            </div>
          </div>
        </div>
      </div>
      <p v-else>찜한 관광지가 없습니다.</p>
    </div>
  </div>
</template>

<style scoped>
.attractions-container {
  padding: 20px;
}

.card-container {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}

.card {
  border: 1px solid #ddd;
  border-radius: 8px;
  width: 200px;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s;
}

.card:hover {
  transform: scale(1.02);
}

.card-img-top {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.card-body {
  padding: 10px;
  text-align: center;
}

.card-title {
  margin: 0;
  font-size: 1rem;
  color: #333;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.no-favorites {
  text-align: center;
  margin-top: 20px;
  font-size: 1.2rem;
  color: #888;
}
</style>
