<script setup>
import { ref, watch } from "vue";
import { KakaoMap, KakaoMapMarker } from "vue3-kakao-maps";

const emit = defineEmits(["addPlan"]);
const props = defineProps({
  attractions: {
    type: Array,
    default: () => [],
  },
  selectAttraction: {
    type: Object,
    default: () => null,
  },
});

// 기본 지도 중심 (서울)
const defaultCenter = { lat: 37.5665, lng: 126.9780 };
const mapCenter = ref(defaultCenter);

// 반응형 마커 리스트
const markerList = ref([]);
const map = ref();
const activeMarker = ref(null); // 현재 활성화된 마커

// props 변경 시 마커 업데이트
watch(
  () => props.attractions,
  (newAttractions) => {
    markerList.value = newAttractions.map((attraction) => ({
      lat: attraction.latitude,
      lng: attraction.longitude,
      infoWindow: {
        content: `
          <div style="padding:10px; max-width: 200px; word-wrap: break-word;">
            <strong>${attraction.title}</strong><br>
            ${attraction.addr1 || "주소 정보 없음"}
          </div>`,
        visible: false,
      },
    }));

    // 지도 중심 이동
    if (newAttractions.length > 0) {
      mapCenter.value = {
        lat: newAttractions[0].latitude,
        lng: newAttractions[0].longitude,
      };
    } else {
      mapCenter.value = defaultCenter;
    }
  },
  { immediate: true, deep: true }
);

// 선택된 관광지 변경 시 해당 마커 인포윈도우 표시
watch(
  () => props.selectAttraction,
  (newAttraction) => {
    if (newAttraction) {
      const marker = markerList.value.find(
        (m) =>
          m.lat === newAttraction.latitude && m.lng === newAttraction.longitude
      );
      if (marker) {
        // 다른 활성화된 마커의 인포윈도우 숨기기
        if (activeMarker.value) {
          activeMarker.value.infoWindow.visible = false;
        }

        // 현재 마커 활성화 및 인포윈도우 표시
        activeMarker.value = marker;
        marker.infoWindow.visible = true;

        // 지도 중심을 선택된 관광지로 이동
        mapCenter.value = {
          lat: newAttraction.latitude,
          lng: newAttraction.longitude,
        };
      }
    }
  },
  { immediate: true, deep: true }
);

// 마커 클릭 시 인포윈도우 표시 상태 토글
const onClickMapMarker = (marker) => {
  // 다른 활성화된 마커의 인포윈도우 숨기기
  if (activeMarker.value && activeMarker.value !== marker) {
    activeMarker.value.infoWindow.visible = false;
  }

  // 현재 마커 활성화 및 인포윈도우 표시 상태 토글
  activeMarker.value = marker;
  marker.infoWindow.visible = !marker.infoWindow.visible;
};

// 지도 로드 이벤트 핸들러
const onLoadKakaoMap = (mapRef) => {
  map.value = mapRef;
};
</script>

<template>
  <div id="map">
    <!-- 동적 중심의 카카오 지도 -->
    <KakaoMap
      :lat="mapCenter.lat"
      :lng="mapCenter.lng"
      style="width: 100%; height: 700px"
      @onLoadKakaoMap="onLoadKakaoMap"
    >
      <!-- 관광지 마커 -->
      <KakaoMapMarker
        v-for="(marker, index) in markerList"
        :key="index"
        :lat="marker.lat"
        :lng="marker.lng"
        :infoWindow="marker.infoWindow"
        :clickable="true"
        @onClickKakaoMapMarker="() => onClickMapMarker(marker)"
      />
    </KakaoMap>
  </div>
</template>

<style scoped>
#map {
  width: 100%;
  height: 700px;
}
</style>
