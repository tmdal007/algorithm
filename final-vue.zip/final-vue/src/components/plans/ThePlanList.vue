<script setup>
import { ref, onMounted } from "vue";
import { getUserPlans, deletePlan } from "@/api/myplan.js";
import { useMemberStore } from "@/stores/member";
import { useRouter } from "vue-router"; // 라우터 import

const memberStore = useMemberStore();
const router = useRouter(); // 라우터 인스턴스 사용
const userId = ref("");
const plans = ref([]);
const emit = defineEmits(["selectPlan"]);

const loadUserInfo = async () => {
  const token = sessionStorage.getItem("accessToken");
  if (token) {
    try {
      await memberStore.getUserInfo(token);
      if (memberStore.userInfo) {
        userId.value = memberStore.userInfo.userId || "";
      }
    } catch (error) {
      console.error("사용자 정보 로드 실패:", error);
    }
  }
};

const loadPlans = () => {
  if (!userId.value) {
    console.error("사용자 ID가 없습니다.");
    return;
  }
  getUserPlans(
    userId.value,
    (response) => {
      plans.value = response.data;
    },
    (error) => {
      console.error("사용자 여행 계획 로드 실패:", error);
    }
  );
};

const handleDeletePlan = (planNo, event) => {
  event.stopPropagation(); // 이벤트 버블링 방지
  if (confirm("정말로 이 여행 계획을 삭제하시겠습니까?")) {
    deletePlan(
      planNo,
      () => {
        alert("여행 계획 삭제 완료!");
        loadPlans(); // 목록 새로고침
      },
      (error) => {
        console.error("여행 계획 삭제 실패:", error);
        alert("여행 계획 삭제에 실패했습니다.");
      }
    );
  }
};

const handleWriteReview = (plan) => {
  // plan 객체 유효성 검사
  if (!plan || !plan.planNo) {
    console.error("plan 또는 planNo가 유효하지 않습니다:", plan);
    return;
  }

  // 라우터로 이동 시 경로 파라미터와 쿼리 파라미터를 함께 전달
  router.push({
    name: "post-write",
    params: { planNo: plan.planNo }, // 경로 파라미터
    query: {
      planName: plan.planName,
      startDate: plan.startDate,
      endDate: plan.endDate,
    },
  });
};



onMounted(async () => {
  await loadUserInfo();
  loadPlans();
});
</script>

<template>
  <div>
    <div class="plan-list">
      <div
        v-for="plan in plans"
        :key="plan.planNo"
        class="plan-card"
      >
        <div class="plan-content" @click="$emit('selectPlan', plan.planNo)">
          <h5>{{ plan.planName }}</h5>
          <span>{{ plan.startDate }} ~ {{ plan.endDate }}</span>
        </div>
        <div class="button-group">
          <button 
            @click="(e) => handleDeletePlan(plan.planNo, e)"
            class="delete-btn"
          >
            삭제
          </button>
          <button 
            @click="() => handleWriteReview(plan)"
            class="review-btn"
          >
            후기
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.plan-list {
  display: flex;
  gap: 20px;
  overflow-x: auto;
  padding: 20px 0;
}

.plan-card {
  min-width: 250px;
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.plan-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.plan-card.selected {
  border-color: #4CAF50;
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.2);
}

.plan-content {
  margin-bottom: 15px;
}

.plan-content h5 {
  margin: 0 0 8px 0;
  font-size: 1.2em;
  color: #333;
}

.plan-content span {
  color: #666;
  font-size: 0.9em;
}

.button-group {
  display: flex;
  gap: 10px;
}

.delete-btn,
.review-btn {
  width: 70px;
  height: 40px;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.delete-btn {
  background-color: #973131;
}

.delete-btn:hover {
  background-color: #cc0000;
}

.review-btn {
  background-color: #4CAF50;
}

.review-btn:hover {
  background-color: #45a049;
}
</style>
