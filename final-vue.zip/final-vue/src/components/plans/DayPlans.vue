<script setup>
import { ref, watch } from "vue";
import { getDayPlans, getAttractions, updateAttractionTime, saveAttractionsOrder } from "@/api/myplan.js";
import noImage from "@/assets/no_image.jpg";
import { VueDraggableNext } from "vue-draggable-next";

const props = defineProps({
  planNo: {
    type: Number,
    required: true,
  },
});

const dayPlans = ref([]);
const emit = defineEmits(["selectDayPlan", "highlightAttraction", "attractionsReordered"]);

const loadAttractionsForDayPlans = async (dayPlansData) => {
  const promises = dayPlansData.map((dayPlan) =>
    new Promise((resolve) => {
      getAttractions(
        dayPlan.dayPlanNo,
        (response) => {
          console.log("정렬된 데이터 (order_no 확인):", response.data); // order_no 확인
          dayPlan.attractions = response.data;
          resolve(dayPlan);
        },
        (error) => {
          console.error(`관광지 데이터 로드 실패 (DayPlanNo: ${dayPlan.dayPlanNo}):`, error);
          dayPlan.attractions = [];
          resolve(dayPlan);
        }
      );
    })
  );

  return Promise.all(promises);
};



const loadDayPlans = async () => {
  if (!props.planNo) return;

  getDayPlans(
    props.planNo,
    async (response) => {
      console.log("서버에서 가져온 데이터 (dayPlans):", response.data); // 전체 데이터 확인
      const dayPlansData = response.data.map((dayPlan) => {

        const sortedAttractions = [...dayPlan.attractions].sort((a, b) => a.orderNo - b.orderNo);

        return {
          ...dayPlan,
          attractions: sortedAttractions,
        };
      });

      const updatedDayPlans = await loadAttractionsForDayPlans(dayPlansData);
      dayPlans.value = updatedDayPlans;
    },
    (error) => {
      console.error("하루 일정 데이터 로드 실패:", error);
    }
  );
};


const prepareOrderData = (attractions) => {
  return attractions.map((attraction, index) => ({
    attractionNo: attraction.no, // `no`는 attraction의 고유 식별자
    orderNo: index + 1,          // 1부터 시작하는 순서
  }));
};


const handleDragEnd = (dayPlanNo) => {
  const dayPlan = dayPlans.value.find((dp) => dp.dayPlanNo === dayPlanNo);
  if (dayPlan) {
    const orderData = prepareOrderData(dayPlan.attractions); // 데이터를 변환
    console.log("저장 요청 데이터:", orderData); // 전송할 데이터 확인
    saveAttractionsOrder(
      dayPlanNo,
      orderData,
      () => {
        console.log("순서 저장 성공");
      },
      (error) => {
        console.error("순서 저장 실패:", error);
      }
    );
    emit("attractionsReordered", {
      dayPlanNo,
      attractions: dayPlan.attractions,
    });
  }
};
// 시간 수정
const updateTime = (dayPlanNo, attractionNo, newTime) => {
  updateAttractionTime(
    dayPlanNo,
    attractionNo,
    newTime,
    () => {
      console.log(`시간 업데이트 성공 (DayPlanNo: ${dayPlanNo}, AttractionNo: ${attractionNo}, Time: ${newTime})`);
      loadDayPlans(); // 성공 후 데이터를 다시 로드
    },
    (error) => {
      console.error(`시간 업데이트 실패 (DayPlanNo: ${dayPlanNo}, AttractionNo: ${attractionNo}, Time: ${newTime}):`, error);
    }
  );
};



watch(() => props.planNo, loadDayPlans, { immediate: true });
</script>

<template>
  <div class="day-plans-container">
    <div
      v-for="dayPlan in dayPlans"
      :key="dayPlan.dayPlanNo"
      class="timeline-item"
      @click="$emit('selectDayPlan', dayPlan.dayPlanNo)"
    >
      <div class="timeline-badge">{{ dayPlan.days }}일차</div>
      <div class="timeline-panel">
        <div class="timeline-heading">
          <h4>{{ dayPlan.memo || "메모 없음" }}</h4>
        </div>
        <div class="timeline-body">
          <VueDraggableNext
            v-model="dayPlan.attractions"
            group="attractions"
            @end="handleDragEnd(dayPlan.dayPlanNo)"
          >
            <div
              v-for="attraction in dayPlan.attractions"
              :key="attraction.no"
              class="attraction-card"
            >
              <img
                :src="attraction.firstImage1 || noImage"
                alt="관광지 이미지"
                class="attraction-image"
              />
              <div class="attraction-info">
                <h5>{{ attraction.title }}</h5>
                <p class="address">{{ attraction.addr1 || "주소 정보 없음" }}</p>
                <p class="time">
                  📅 
                  <input
                    type="time"
                    :value="attraction.time || ''"
                    @change="updateTime(dayPlan.dayPlanNo, attraction.no, $event.target.value)"
                  />
                </p>
              </div>
            </div>
          </VueDraggableNext>
        </div>
      </div>
    </div>
  </div>
</template>




<style scoped>
.day-plans-container {
  position: relative;
}

.timeline-item {
  position: relative;
  margin-bottom: 30px;
  cursor: pointer;
}

.timeline-item::before {
  content: '';
  position: absolute;
  left: 20px;
  top: 0;
  bottom: 0;
  width: 2px;
  background: #ddd;
}

.timeline-badge {
  position: absolute;
  left: 0;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #3b88c3;
  color: white;
  text-align: center;
  line-height: 40px;
  z-index: 1;
}

.timeline-panel {
  margin-left: 60px;
  background: white;
  border-radius: 12px;
  padding: 15px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.timeline-heading h4 {
  margin: 0 0 15px 0;
  color: #333;
}

.attraction-card {
  display: flex;
  align-items: center;
  padding: 10px;
  margin-bottom: 10px;
  border-radius: 8px;
  background: #f8f9fa;
  transition: transform 0.2s;
}

.attraction-card:hover {
  transform: translateX(5px);
}

.attraction-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
}

.attraction-info {
  margin-left: 15px;
  flex: 1;
}

.attraction-info h5 {
  margin: 0 0 5px 0;
  color: #333;
}

.address {
  font-size: 0.9em;
  color: #666;
  margin: 5px 0;
}

.time {
  font-size: 0.9em;
  color: #3b88c3;
  margin: 5px 0;
}

.attraction-card {
  display: flex;
  align-items: center;
  padding: 10px;
  margin-bottom: 10px;
  border-radius: 8px;
  background: #f8f9fa;
  transition: transform 0.2s;
  cursor: move; /* 드래그 가능함을 표시 */
}

.attraction-card:hover {
  transform: translateX(5px);
}

/* 드래그 중인 아이템 스타일 */
.sortable-ghost {
  opacity: 0.5;
  background: #c8ebfb;
}

.sortable-chosen {
  background: #e9ecef;
}
</style>