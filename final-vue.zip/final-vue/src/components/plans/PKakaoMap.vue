<script setup>
import { ref, watch, onMounted } from "vue";
import { getAttractions } from "@/api/myplan.js";

const props = defineProps({
  dayPlanNo: {
    type: Number,
    required: true,
  },
});

let map = null;
const mapCenter = ref({ lat: 37.5665, lng: 126.9780 }); // 기본값: 서울
const positions = ref([]); // 마커 데이터
const polylines = ref([]); // 폴리라인 데이터
const infoWindows = ref([]); // 인포윈도우 데이터
const routeDetails = ref([]); // 경로 세부 정보
const openInfoWindows = ref(new Map()); // 열린 인포윈도우 상태 관리
const noImage = "/default-image.jpg"; // 기본 이미지

const KAKAO_API_KEY = import.meta.env.VITE_KAKAO_MOBILITY_KEY; // Kakao Mobility API Key
const colors = ["#FF0000", "#00FF00", "#0000FF", "#FFA500", "#800080"]; // 경로 색상 배열

const initMap = () => {
  const container = document.getElementById("map");
  const options = {
    center: new kakao.maps.LatLng(mapCenter.value.lat, mapCenter.value.lng),
    level: 5,
  };
  map = new kakao.maps.Map(container, options);
};

const clearMapObjects = () => {
  positions.value.forEach((position) => {
    if (position.marker) {
      position.marker.setMap(null);
    }
  });
  polylines.value.forEach((polyline) => polyline.setMap(null));
  polylines.value = [];
  infoWindows.value.forEach((infoWindow) => infoWindow.close());
  infoWindows.value = [];
  routeDetails.value = [];
  openInfoWindows.value.clear();
};

const loadAttractions = () => {
  if (!props.dayPlanNo) return;

  getAttractions(
    props.dayPlanNo,
    async (response) => {
      positions.value = response.data.map((attraction) => ({
        latlng: new kakao.maps.LatLng(attraction.latitude, attraction.longitude),
        title: attraction.title,
        imageUrl: attraction.firstImage1 || noImage, // 이미지 URL 추가
        content: `
          <div style="text-align: center; padding:5px; max-width:200px; white-space:normal; word-wrap:break-word;">
            <img src="${attraction.firstImage1 || noImage}" alt="${attraction.title}" style="width:80px; border-radius:5px; display:block; margin:0 auto;"/>
            <strong style="display:block; margin-top:5px;">${attraction.title}</strong>
          </div>`,
      }));

      if (positions.value.length > 0) {
        mapCenter.value = {
          lat: positions.value[0].latlng.getLat(),
          lng: positions.value[0].latlng.getLng(),
        };
        map.setCenter(new kakao.maps.LatLng(mapCenter.value.lat, mapCenter.value.lng));
      }

      await renderMarkersAndRoutes();
    },
    (error) => {
      console.error("관광지 데이터 로드 실패:", error);
    }
  );
};

const updateAttractions = async (newAttractions) => {
  positions.value = newAttractions.map((attraction) => ({
    latlng: new kakao.maps.LatLng(attraction.latitude, attraction.longitude),
    title: attraction.title,
    imageUrl: attraction.firstImage1 || noImage, // 이미지 URL 추가
    content: `
      <div style="text-align: center; padding:5px; max-width:200px; white-space:normal; word-wrap:break-word;">
        <img src="${attraction.firstImage1 || noImage}" alt="${attraction.title}" style="width:80px; border-radius:5px; display:block; margin:0 auto;"/>
        <strong style="display:block; margin-top:5px;">${attraction.title}</strong>
      </div>`,
  }));

  await renderMarkersAndRoutes();
};

const fetchRouteData = async (origin, destination) => {
  const url = `https://apis-navi.kakaomobility.com/v1/directions?origin=${origin}&destination=${destination}&priority=DISTANCE`;
  const headers = {
    Authorization: `KakaoAK ${KAKAO_API_KEY}`,
  };

  try {
    const response = await fetch(url, { method: "GET", headers });
    if (!response.ok) return null;
    return await response.json();
  } catch (error) {
    console.error("경로 데이터 요청 중 오류 발생:", error);
    return null;
  }
};

const renderMarkersAndRoutes = async () => {
  clearMapObjects();
  const bounds = new kakao.maps.LatLngBounds();

  for (let i = 0; i < positions.value.length; i++) {
    const position = positions.value[i];
    const marker = new kakao.maps.Marker({
      map: map,
      position: position.latlng,
      title: position.title,
    });

    position.marker = marker;
    bounds.extend(position.latlng);

    const infoWindow = new kakao.maps.InfoWindow({
      content: position.content,
      removable: true,
    });

    kakao.maps.event.addListener(marker, "click", () => {
      if (openInfoWindows.value.has(marker)) {
        openInfoWindows.value.get(marker).close();
        openInfoWindows.value.delete(marker);
      } else {
        infoWindow.open(map, marker);
        openInfoWindows.value.set(marker, infoWindow);
      }
    });

    infoWindows.value.push(infoWindow);

    if (i < positions.value.length - 1) {
      const origin = `${position.latlng.getLng()},${position.latlng.getLat()}`;
      const destination = `${positions.value[i + 1].latlng.getLng()},${positions.value[i + 1].latlng.getLat()}`;
      const routeData = await fetchRouteData(origin, destination);

      if (routeData) {
        drawRoute(routeData, colors[i % colors.length]);

        const summary = routeData.routes[0]?.summary || {};
        routeDetails.value.push({
          origin: positions.value[i].title,
          destination: positions.value[i + 1].title,
          distance: (summary.distance / 1000).toFixed(2),
          duration: Math.ceil(summary.duration / 60),
          color: colors[i % colors.length],
        });
      }
    }
  }

  map.setBounds(bounds);
};

const drawRoute = (routeData, color) => {
  if (!routeData?.routes?.[0]?.sections?.[0]?.roads) return;

  const path = [];
  const roads = routeData.routes[0].sections[0].roads;

  roads.forEach((road) => {
    const vertexes = road.vertexes;
    for (let i = 0; i < vertexes.length; i += 2) {
      path.push(new kakao.maps.LatLng(vertexes[i + 1], vertexes[i]));
    }
  });

  const polyline = new kakao.maps.Polyline({
    map: map,
    path,
    strokeWeight: 5,
    strokeColor: color,
    strokeOpacity: 0.8,
    strokeStyle: "solid",
  });

  polylines.value.push(polyline);
};

onMounted(() => {
  if (window.kakao && window.kakao.maps) {
    initMap();
    loadAttractions();
  } else {
    const script = document.createElement("script");
    script.src = `//dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=${
      import.meta.env.VITE_KAKAO_MAP_SERVICE_KEY
    }&libraries=services`;
    script.onload = () =>
      kakao.maps.load(() => {
        initMap();
        loadAttractions();
      });
    document.head.appendChild(script);
  }
});

defineExpose({ updateAttractions });

watch(() => props.dayPlanNo, loadAttractions);
</script>

<template>
  <div>
    <div id="map" style="width: 100%; height: 500px;"></div>
    <div class="route-info-container">
      <div
        v-for="(detail, index) in routeDetails"
        :key="index"
        class="route-card"
        :style="{ borderLeft: `4px solid ${detail.color}` }"
      >
        <h4><i class="bi bi-car-front-fill"></i> 경로 {{ index + 1 }}</h4>
        <p><i class="bi bi-geo-alt-fill"></i> 출발지: {{ detail.origin }}</p>
        <p><i class="bi bi-geo-alt-fill"></i> 목적지: {{ detail.destination }}</p>
        <p><i class="bi bi-sign-turn-slight-right-fill"></i> 거리: {{ detail.distance }} km</p>
        <p><i class="bi bi-clock-fill"></i> 소요 시간: {{ detail.duration }} 분</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.route-card {
  padding: 15px;
  margin-top: 15px;
  margin-bottom: 15px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease;
}

.route-card:hover {
  transform: translateX(5px);
}
</style>
