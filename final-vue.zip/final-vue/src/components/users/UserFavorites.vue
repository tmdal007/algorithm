<script setup>
import UserNavbar from "@/components/layout/UserNavbar.vue"; // UserNavbar 컴포넌트 import
import { ref, onMounted } from "vue";
import { useMemberStore } from "@/stores/member"; // memberStore 가져오기
import {
  getFavoriteList,
  addToFavorites,
  deleteFavorite,
} from "@/api/like";
import noImage from "@/assets/no_image.jpg";

// Pinia Store 사용
const memberStore = useMemberStore();
const attractionList = ref([]); // 찜한 관광지 목록

// 찜한 관광지 목록 가져오기
const fetchFavorites = () => {
  const userInfo = memberStore.userInfo;
  const userId = userInfo?.userId || null;

  if (!userId) {
    console.error("로그인하지 않은 사용자입니다.");
    return;
  }

  getFavoriteList(
    userId,
    ({ data }) => {
      attractionList.value = data.map((attraction) => ({
        ...attraction,
        liked: true, // 기존 찜된 상태
      }));
      console.log("찜한 관광지 목록:", attractionList.value);
    },
    (error) => {
      console.error("Error fetching attractions:", error);
    }
  );
};

// 찜 상태 토글
const toggleLike = async (attraction) => {
  const userInfo = memberStore.userInfo;
  const userId = userInfo?.userId || null;

  const likeData = {
    userId: userId,
    contentId: attraction.contentId,
  };

  if (!userId) {
    alert("로그인이 필요합니다.");
    return;
  }

  if (attraction.liked) {
  // 찜 삭제
  await deleteFavorite(
    likeData,
    () => {
      attraction.liked = false; // 반응형 상태 업데이트
      attractionList.value = [...attractionList.value]; // Vue에서 강제 렌더링
      console.log("찜 삭제 완료:", attraction.title);
    },
    (error) => {
      console.error("찜 삭제 실패:", error);
      alert('찜 삭제에 실패했습니다.');
    }
  );
} else {
  // 찜 추가
  await addToFavorites(
    likeData,
    () => {
      attraction.liked = true; // liked 상태 업데이트
      attractionList.value = [...attractionList.value]; // Vue에서 강제 렌더링
      console.log('찜한 관광지 정보 확인:', attraction);
      // alert('찜한 목록에 추가되었습니다.');
    },
    (error) => {
      console.error('찜 추가 실패:', error);
      alert('찜하기에 실패했습니다.');
    }
  );
}

};

// 컴포넌트 로드 시 데이터 가져오기
onMounted(async () => {
  // 사용자 로그인 상태 초기화
  await memberStore.initializeLoginState();

  if (memberStore.isLogin && memberStore.userInfo?.userId) {
    console.log("로그인 상태 유지됨, 찜 목록 가져오기");
    fetchFavorites();
  } else {
    console.error("유효한 사용자 정보가 없어 찜 목록을 가져오지 못했습니다.");
  }
});
</script>

<template>
  <div class="container mt-4">
    <!-- UserNavbar 컴포넌트 사용 -->
    <UserNavbar />
    <div class="d-flex align-items-center justify-content-between mb-3">
      <h4 class="fw-bold">즐겨찾기</h4>
      <select class="form-select" style="width: 150px;">
        <option value="all">전체</option>
        <option value="travel">여행지</option>
        <option value="festival">축제</option>
      </select>
    </div>

    <div v-if="attractionList.length > 0" class="row row-cols-1 g-4">
      <div v-for="attraction in attractionList" :key="attraction.contentId" class="col">
        <div
          class="card h-100 position-relative"
          style="border-radius: 15px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);"
        >
          <!-- 찜 버튼 -->
          <button
            class="btn btn-sm position-absolute top-0 end-0 m-2"
            :class="attraction.liked ? 'btn-danger' : 'btn-outline-danger'"
            @click.stop="toggleLike(attraction)"
          >
            {{ attraction.liked ? "♥" : "♡" }}
          </button>

          <div class="row g-0">
            <!-- 이미지 -->
            <div class="col-md-4">
              <img
                :src="attraction.firstImage1 || noImage"
                class="img-fluid rounded-start"
                :alt="attraction.title"
                style="height: 100%; object-fit: cover; border-radius: 15px 0 0 15px;"
              />
            </div>
            <!-- 텍스트 콘텐츠 -->
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">{{ attraction.title }}</h5>
                <p class="card-text">
                  <strong>타입:</strong> {{ attraction.contentTypeName }}<br />
                  <strong>시도:</strong> {{ attraction.sidoName }}<br />
                  <strong>구군:</strong> {{ attraction.gugunName }}<br />
                  <strong>전화번호:</strong> {{ attraction.tel || "없음" }}<br />
                  <strong>홈페이지:</strong>
                  <a
                    :href="attraction.homepage"
                    target="_blank"
                    rel="noopener"
                  >
                    {{ attraction.homepage || "없음" }}
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <p v-else class="text-center">찜한 관광지가 없습니다.</p>
  </div>
</template>

<style scoped>
.container {
  max-width: 900px;
  margin: auto;
}

.card {
  border: 1px solid #ddd;
  border-radius: 15px;
  transition: transform 0.2s ease-in-out;
}

.card:hover {
  transform: scale(1.02);
}

.card-title {
  font-size: 1.25rem;
  font-weight: bold;
  color: #333;
}

.card-text {
  font-size: 0.9rem;
  color: #555;
}

.text-center {
  font-size: 1.2rem;
  color: #888;
}

.position-absolute {
  z-index: 10;
}
</style>
