<script>
import { getPostsByUser, deletePost } from "@/api/post"; // API 호출
import { useMemberStore } from "@/stores/member"; // 사용자 정보 가져오기
import ReviewDetail from '@/components/posts/ReviewDetail.vue'; // 모달 컴포넌트
import UserNavbar from '@/components/layout/UserNavbar.vue';

export default {
  name: "UserReviewList",
  components: {
    UserNavbar,
  },
  data() {
    return {
      reviews: [], // 사용자의 후기 목록
    };
  },
  computed: {
    // 현재 로그인된 사용자 정보
    currentUser() {
      const memberStore = useMemberStore();
      return memberStore.userInfo || {}; // 안전한 접근
    },
  },
  created() {
    this.fetchUserReviews();
  },
  methods: {
    // 현재 로그인된 사용자의 후기 목록을 가져오는 함수
    fetchUserReviews() {
      const userId = this.currentUser.userId; // currentUser에서 userId 추출
      if (!userId) {
        console.error("userId가 존재하지 않습니다. 로그인이 필요합니다.");
        return;
      }

      getPostsByUser(
        userId,
        (response) => {
          if (response && response.data) {
            this.reviews = response.data;
            console.log("가져온 리뷰 목록:", this.reviews);
          } else {
            console.error("API 응답 데이터가 비어 있습니다.");
            this.reviews = []; // 비어있는 목록으로 초기화
          }
        },
        (error) => {
          console.error("내 후기 목록을 불러오는 중 오류 발생:", error);
        }
      );
    },
    // 삭제 처리 함수
    deleteReview(postNo) {
      if (confirm("정말로 삭제하시겠습니까?")) {
        deletePost(
          postNo,
          () => {
            alert("후기가 성공적으로 삭제되었습니다.");
            this.fetchUserReviews(); // 삭제 후 목록 갱신
          },
          (error) => {
            console.error("후기 삭제 중 오류 발생:", error);
            alert("삭제에 실패했습니다.");
          }
        );
      }
    },
  },
};
</script>

<template>
  <div class="container mt-4">
    <UserNavbar/>
    <div v-if="reviews.length === 0" class="text-center">
      <p>작성된 후기가 없습니다.</p>
    </div>
    <div class="row">
      <div
        v-for="review in reviews"
        :key="review.postNo"
        class="col-12 col-md-6 col-lg-4 mb-4 d-flex"
      >
        <div class="card shadow-sm w-100 position-relative">
          <!-- 후기 이미지 -->
          <img
            v-if="review.saveFolder && review.saveFile"
            :src="`/${review.saveFolder}/${review.saveFile}`"
            class="card-img-top"
            alt="후기 이미지"
          />
          <div class="card-body">
            <!-- 후기 제목 -->
            <h5 class="card-title">여행 후기</h5>
            <!-- 내용 -->
            <p class="card-text text-truncate">{{ review.content }}</p>
            <!-- 삭제 버튼 -->
            <div class="d-flex justify-content-end mt-3">
              <button
                class="btn btn-danger btn-sm"
                @click="deleteReview(review.postNo)"
              >
                삭제
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.card {
  position: relative;
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
}

.card-img-top {
  height: 180px;
  object-fit: cover;
}

.card-title {
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.card-text {
  font-size: 0.9rem;
  color: #6c757d;
}

.text-muted {
  font-size: 0.85rem;
}

.btn-danger {
  font-size: 0.8rem;
  color: #fff;
}
.row{
  margin-top: 40px;
}
</style>
