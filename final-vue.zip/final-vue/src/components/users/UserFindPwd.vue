<script setup>
import { ref } from "vue";
import { findPassword } from "@/api/user"; // findPassword 함수 import

// 입력값 관리
const mbId = ref(""); // 아이디
const mbEmail = ref(""); // 이메일
const emailCheckWarn = ref(""); // 경고 메시지

// 비밀번호 찾기 처리
const handleFindPassword = async () => {
  if (!mbId.value || !mbEmail.value) {
    emailCheckWarn.value = "아이디와 이메일을 입력해주세요.";
    return;
  }

  try {
    const params = {
      userId: mbId.value,
      userEmail: mbEmail.value,
    };

    // findPassword 함수 호출
    await findPassword(
      params,
      (response) => {
        if (response.status === 200) {
          emailCheckWarn.value = "임시 비밀번호가 이메일로 발송되었습니다.";
        }
      },
      (error) => {
        if (error.response?.status === 400) {
          emailCheckWarn.value = "아이디와 이메일이 일치하지 않습니다.";
        } else {
          emailCheckWarn.value = "비밀번호 찾기 요청 중 오류가 발생했습니다.";
        }
      }
    );
  } catch (error) {
    console.error("handleFindPassword 실패:", error);
    emailCheckWarn.value = "비밀번호 찾기 요청 중 예상치 못한 오류가 발생했습니다.";
  }
};
</script>

<template>
  <div class="password-recovery-container">
    <div class="password-recovery-form">
      <div class="logo">
        <img src="@/assets/logo.PNG" alt="Miyeo Logo" />
      </div>
      <p class="description">
        가입시 등록한 아이디와 이메일을 입력하면, <br />
        임시 비밀번호를 이메일로 전송해드립니다.
      </p>
      <div class="form-group">
        <input
          v-model="mbId"
          type="text"
          placeholder="아이디"
          class="input-field"
        />
      </div>
      <div class="form-group">
        <input
          v-model="mbEmail"
          type="email"
          placeholder="이메일"
          class="input-field"
        />
      </div>
      <button class="register-button" @click="handleFindPassword">임시 비밀번호 발급</button>
      <p class="error-message">{{ emailCheckWarn }}</p>
    </div>
  </div>
</template>

<style scoped>
/* 마지막 코드에서 주어진 스타일과 동일 */
.password-recovery-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 90vh;
  background-color: #f6e7d8;
}

.password-recovery-form {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 30px;
  border-radius: 15px;
  width: 400px;
}

.logo img {
  width: 200px;
  margin-bottom: 20px;
}

.description {
  text-align: center;
  font-size: 14px;
  color: #6b6b6b;
  margin-bottom: 20px;
}

.input-field {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 25px;
  font-size: 16px;
  margin-bottom: 15px;
  background-color: #f9f9f9;
}

.register-button {
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 25px;
  font-size: 16px;
  color: #fff;
  background-color: #d5a67d;
  cursor: pointer;
  transition: background-color 0.3s ease;
  margin-top: 10px;
}

.register-button:hover {
  background-color: #c1906d;
}

.error-message {
  color: red;
  font-size: 12px;
  margin-top: 10px;
  text-align: center;
}

.form-group {
  width: 100%;
  display: flex;
  justify-content: center;
}
</style>
