<template>
  <div class="chatbot-container">
    <div class="chatbot-header">
      <h3>AI 채팅</h3>
    </div>
    
    <div class="chatbot-messages" ref="messagesContainer">
      <div 
        v-for="(message, index) in messages" 
        :key="index" 
        :class="['message', message.role]"
      >
        <div class="message-icon">
          {{ message.role === 'user' ? '👤' : '🤖' }}
        </div>
        <div class="message-content">
          {{ message.content }}
        </div>
      </div>
      
      <div v-if="isLoading" class="message bot loading">
        <div class="message-icon">🤖</div>
        <div class="message-content">
          입력 중...
        </div>
      </div>
    </div>
    
    <div class="chatbot-input">
      <input 
        type="text" 
        v-model="userMessage" 
        @keyup.enter="sendMessage"
        placeholder="메시지를 입력하세요..."
      />
      <button 
        @click="sendMessage" 
        :disabled="!userMessage.trim()"
      >
        전송
      </button>
    </div>
  </div>
</template>

<script>
import { localAxios } from "@/util/http-commons";

export default {
  data() {
    return {
      userMessage: "",
      messages: [],
      isLoading: false
    };
  },
  methods: {
    async sendMessage() {
      if (!this.userMessage.trim()) return;

      const local = localAxios();
      
      this.messages.push({ role: "user", content: this.userMessage });
      const currentMessage = this.userMessage;
      this.userMessage = "";
      this.isLoading = true;

      try {
        const response = await local.put("/api/chat", {
          message: currentMessage
        });

        this.messages.push({ 
          role: "bot", 
          content: response.data 
        });
      } catch (error) {
        console.error("챗봇 응답 오류:", error);
        this.messages.push({
          role: "bot",
          content: "죄송합니다. 오류가 발생했습니다."
        });
      } finally {
        this.isLoading = false;
        this.$nextTick(() => {
          this.scrollToBottom();
        });
      }
    },
    scrollToBottom() {
      const container = this.$refs.messagesContainer;
      container.scrollTop = container.scrollHeight;
    }
  }
};
</script>

<style scoped>
.chatbot-container {
  width: 460px; /* 기존 400px에서 500px으로 확장 */
  height: 600px;
  border: 1px solid #e0e0e0;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.chatbot-header {
  background-color: #4a90e2;
  color: white;
  padding: 15px;
  text-align: center;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}

.chatbot-messages {
  flex-grow: 1;
  overflow-y: auto;
  padding: 15px;
  display: flex;
  flex-direction: column;
}

.message {
  display: flex;
  margin-bottom: 15px;
  align-items: flex-start;
}

.message-icon {
  margin-right: 10px;
  font-size: 24px;
}

.message-content {
  display: inline-block; /* 글씨 크기에 맞게 박스 조정 */
  padding: 10px;
  border-radius: 10px;
  word-wrap: break-word; /* 긴 텍스트 줄 바꿈 */
}

.message.user {
  align-self: flex-end;
  text-align: right;
}

.message.user .message-content {
  background-color: #4a90e2;
  color: white;
}

.message.bot .message-content {
  background-color: #f1f0f0;
  color: black;
}

.loading .message-content {
  animation: pulse 1.5s infinite;
}

.chatbot-input {
  display: flex;
  padding: 15px;
  border-top: 1px solid #e0e0e0;
}

.chatbot-input input {
  flex-grow: 1;
  padding: 10px;
  border: 1px solid #e0e0e0;
  border-radius: 5px;
  margin-right: 10px;
}

.chatbot-input button {
  padding: 10px 20px;
  background-color: #4a90e2;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.chatbot-input button:disabled {
  background-color: #a0a0a0;
  cursor: not-allowed;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}
</style>
