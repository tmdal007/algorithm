import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'main',
      component: () => import('@/views/TheMainView.vue'),
    },
    {
      path: "/user",
      name: "user",
      component: () => import("@/views/TheUserView.vue"),
      children: [
        {
          path: "login",
          name: "user-login",
          component: () => import("@/components/users/UserLogin.vue"),
        },
        {
          path: "join",
          name: "user-join",
          component: () => import("@/components/users/UserRegister.vue"),
        },
        {
          path: "mypage",
          name: "user-mypage",
          component: () => import("@/components/users/UserMyPage.vue"),
        },
        {
          path: "myreview",
          name: "user-myreview",
          component: () => import("@/components/users/UserReviewList.vue"),
        },
        {
          path: "favorites",
          name: "user-favorites",
          component: () => import("@/components/users/UserFavorites.vue"),
        },
        {
          path: "findpwd",
          name: "user-findpwd",
          component: () => import("@/components/users/UserFindPwd.vue"),
        },
        {
          path: "withdraw",
          name: "user-withdraw",
          component: () => import("@/components/users/UserWithdraw.vue"),
        },
      ],
    },
    {
      path: "/search",
      name: "search",
      component: () => import("../views/TheMap.vue"),
    },
    {
      path: "/plans",
      name: "plans",
      component: () => import("../views/TheMyPlan.vue"),
    },
    {
      path: "/myplan",
      name: "myplan",
      component: () => import("../views/ThePlanView.vue"),
    },
    {
      path: "/notice",
      name: "notice",
      component: () => import("../views/TheNoticeView.vue"),
      redirect: { name: "article-list" },
      children: [
        {
          path: "list",
          name: "article-list",
          component: () => import("@/components/notices/NoticeList.vue"),
        },
        {
          path: "view/:articleno",
          name: "article-view",
          component: () => import("@/components/notices/NoticeDetail.vue"),
        },
        {
          path: "write",
          name: "article-write",
          component: () => import("@/components/notices/NoticeWrite.vue"),
        },
        {
          path: "modify/:articleno",
          name: "article-modify",
          component: () => import("@/components/notices/NoticeModify.vue"),
        },
      ],
    },
    {
      path: "/post",
      name: "post",
      component: () => import("../views/ThePostView.vue"),
      redirect: { name: "post-list" },
      children: [
        {
          path: "list",
          name: "post-list",
          component: () => import("@/components/posts/ReviewList.vue"),
        },
        {
          path: "write/:planNo",
          name: "post-write",
          component: () => import("@/components/posts/ReviewWrite.vue"),
          props: (route) => ({
            planNo: route.params.planNo, // 경로 파라미터로 전달
            planName: route.query.planName, // 쿼리 파라미터로 전달
            startDate: route.query.startDate,
            endDate: route.query.endDate,
          }),
        },
        {
          path: "/posts/:postNo",
          name: "post-detail",
          component: () => import("@/components/posts/ReviewDetail.vue"),
        },
        {
          path: "edit/:planNo/:postNo",
          name: "post-edit",
          component: () => import("@/components/posts/ReviewWrite.vue"),
          props: (route) => ({
            planNo: parseInt(route.params.planNo),
            postNo: parseInt(route.params.postNo),
          }),
        },
      ],
    },    
  ],
})
export default router
