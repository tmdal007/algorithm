package com.ssafy.board.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.board.model.BoardDto;
import com.ssafy.util.DBUtil;

public class BoardDaoImpl implements BoardDao {
	
	private static BoardDao boardDao = new BoardDaoImpl();
	
	private BoardDaoImpl() {
	}

	public static BoardDao getBoardDao() {
		return boardDao;
	}
	
	@Override
	public void registerArticle(BoardDto boardDto) {
		Connection conn = null;
		PreparedStatement pstmt = null;
//		TODO : boardDto의 내용을 board table에 insert 하세요!!!
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder("insert into board (article_no, user_id, subject, content) \n");
			sql.append("values(?,?,?,?)");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, boardDto.getArticleNo());
			pstmt.setString(2, boardDto.getUserId());
			pstmt.setString(3, boardDto.getSubject());
			pstmt.setString(4, boardDto.getContent());
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) {
					pstmt.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
//		END
	}

	@Override
	public List<BoardDto> searchListAll() {
//		TODO : board table의 모든 글정보를 글번호순으로 정렬하여 list에 담고 return 하세요!!!
		List<BoardDto> list = new ArrayList<BoardDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder("select * from board \n");
			sql.append("order by register_time desc");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while(rs.next()) {
				BoardDto b = new BoardDto();
				b.setArticleNo(rs.getInt("article_no"));
				b.setUserId(rs.getString("user_id"));
				b.setSubject(rs.getString("subject"));
				b.setContent(rs.getString("content"));
				b.setRegisterTime(rs.getString("register_time"));
				
				list.add(b);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.getInstance().close(rs,pstmt,conn);
		}	
		return list;
	}

	@Override
	public List<BoardDto> searchListBySubject(String subject) {
		List<BoardDto> list = new ArrayList<BoardDto>();
//		TODO : board table에서 제목에 subject를 포함하고 있는 글정보를 list에 담고 return 하세요!!!
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder("select * from board \n");
			sql.append("order by register_time desc");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while(rs.next()) {
				BoardDto b = new BoardDto();
				b.setArticleNo(rs.getInt("article_no"));
				b.setUserId(rs.getString("user_id"));
				b.setSubject(rs.getString("subject"));
				b.setContent(rs.getString("content"));
				b.setRegisterTime(rs.getString("register_time"));
				
				if(b.getSubject().contains(subject)){
					list.add(b);
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.getInstance().close(rs,pstmt,conn);
		}	
		return list;
//		END
	}

	@Override
	public BoardDto viewArticle(int no) {
		BoardDto boardDto = null;
//		TODO : board table에서 글번호가 no인 글 한개를 return 하세요!!!
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder("select * from board \n");
			sql.append("order by register_time desc");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while(rs.next()) {
				BoardDto b = new BoardDto();
				b.setArticleNo(rs.getInt("article_no"));
				b.setUserId(rs.getString("user_id"));
				b.setSubject(rs.getString("subject"));
				b.setContent(rs.getString("content"));
				b.setRegisterTime(rs.getString("register_time"));
				
				if(b.getArticleNo() == no){
					boardDto = b;
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.getInstance().close(rs,pstmt,conn);
		}
		return boardDto;
//		END
	}

	@Override
	public void modifyArticle(BoardDto boardDto) {
//		TODO : boardDto의 내용을 이용하여 글번호에 해당하는 글제목과 내용을 수정하세요!!!
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder("update board \n");
			sql.append("set subject = ?, content = ? \n");
			sql.append("where article_no = ? ");
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.setString(1, boardDto.getSubject());
			pstmt.setString(2, boardDto.getContent());
			pstmt.setInt(3, boardDto.getArticleNo());
					
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.getInstance().close(pstmt,conn);
		}
//		END
	}

	@Override
	public void deleteArticle(int no) {
//		TODO : board table에서 글번호가 no인 글 정보를 삭제하세요!!!
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder("delete from board \n");
			sql.append("where article_no = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, no);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.getInstance().close(pstmt,conn);
		}
//		END
	}

}
