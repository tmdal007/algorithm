package com.ssafy.board;

import java.io.IOException;
import java.util.List;

import com.ssafy.board.dao.BoardDaoImpl;
import com.ssafy.board.model.BoardDto;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/board")
public class BoardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1. 요청 받아서, 어떤 요청인지 확인
		String action = request.getParameter("act");
		
		if(action.equals("list")) {
			// 2. DB에서 데이터 얻어오기
			List<BoardDto> list = BoardDaoImpl.getBoardDao().listArticle();
			// 2-2. jsp에서 필요한 데이터 request 셋팅
			request.setAttribute("list", list);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/board/list.jsp");
			dispatcher.forward(request, response);
		}else if(action.equals("register")) {
			// request.setCharacterEncoding("utf-8");
			//1. 작성자아이디, 글제목, 글내용을 얻으세요. 
			BoardDto boardDto = new BoardDto();
			boardDto.setUserId(request.getParameter("userid"));
			boardDto.setSubject(request.getParameter("subject"));
			boardDto.setContent(request.getParameter("content"));

			//2. 1의 data를 BoardDao의 writeArticle(BoardDto)메소드에 전달하고 DB에 insert 하세요.
			int cnt = BoardDaoImpl.getBoardDao().writeArticle(boardDto); // 0 or 1
			
			//3. 등록 결과 숫자 전달, register.jsp로!
			request.setAttribute("cnt", cnt);
			
			//4. 페이지 이동(서버 내)
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/board/register.jsp"); // context 입력x
//			dispatcher.forward(request, response);
			
			//4. 페이지 이동(내 서버, 남의 페이지 가능)
			response.sendRedirect("/board2_jsp/board?act=list"); //URL 전체 입력
			
		}else if(action.equals("modify")) {
			
			
			
			
		}else if(action.equals("delete")) {
		}
			
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
