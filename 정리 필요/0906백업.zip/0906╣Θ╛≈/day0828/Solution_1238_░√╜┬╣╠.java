package day0828;
/*
 * SWEA 1238. [S/W 문제해결 기본] 10일차 - Contact
 */
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.StringTokenizer;

public class Solution_1238_곽승미 {
	static int[][] adjMatrix;
	static int N,start,max_num;
	
	public static void main(String[] args) throws Exception{
		//System.setIn(new FileInputStream("res/s_1238_input.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		for(int tc=1; tc<=10; tc++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			StringBuilder sb = new StringBuilder();
			N = Integer.parseInt(st.nextToken());
			start = Integer.parseInt(st.nextToken());
			
			st = new StringTokenizer(br.readLine());
			
			adjMatrix = new int[101][101]; 
			for (int i = 0; i < (int)N/2; i++) {
					int from = Integer.parseInt(st.nextToken());
					int to = Integer.parseInt(st.nextToken());
					adjMatrix[from][to] = 1; //from->to 인접행렬 저장
			}

			max_num = Integer.MIN_VALUE;
			bfs(start);

			sb.append("#").append(tc).append(" ").append(max_num);
			System.out.println(sb.toString());
		}
	}
	static void bfs(int start) {
		Queue<Integer> queue = new ArrayDeque<>();
		boolean[] visited = new boolean[101];
		
		visited[start] = true;
		queue.offer(start);
		
		while(!queue.isEmpty()) {
			
			int size = queue.size(); // 큐의 크기체크
			max_num = 0; 
			
			while(--size >=0) { // 기존 큐의 크기만큼만 뺌
				
				int cur = queue.poll();
				max_num = Math.max(max_num, cur);
				
				 //자신의 인접정점들 다음 탐색위한 준비!
				 for (int i = 0; i < adjMatrix.length; i++) {
					 if(adjMatrix[cur][i] == 0 || visited[i]) continue;
					 
					 visited[i] = true;
					 queue.offer(i);
				}
			}
		}
	}
}
