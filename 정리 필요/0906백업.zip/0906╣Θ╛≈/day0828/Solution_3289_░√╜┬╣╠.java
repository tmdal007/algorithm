package day0828;

/*
 * SWEA 3289. 서로소집합
 */
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution_3289_곽승미 {
	static int N,M;
	static int[] parents;
	static int[] cal;
	static int[] a,b;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/s_3289_input.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		for(int tc=1; tc<=T; tc++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			StringBuilder sb = new StringBuilder();
			
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			
			parents = new int[N+1];
			a = new int[M];
			b = new int[M];
			cal = new int[M];
			
			make();
			for(int i=0; i<M; i++) {
				st = new StringTokenizer(br.readLine());
				cal[i] = Integer.parseInt(st.nextToken());
				a[i] = Integer.parseInt(st.nextToken());
				b[i] = Integer.parseInt(st.nextToken());			
			}
			
			StringBuffer result = new StringBuffer();
			for(int i=0; i<cal.length; i++) {
				if(cal[i] == 0) {
					union(a[i], b[i]);
				}
				else {
					int aRoot = findSet(a[i]);
					int bRoot = findSet(b[i]);
					
					if(aRoot == bRoot) {
						result.append("1");
					}else {
						result.append("0");
					}
				}
			}
			sb.append("#").append(tc).append(" ").append(result);
			System.out.println(sb.toString());
		}
		
	}
	static void make() {
		for (int i = 1; i < N+1; i++) {
			parents[i] = i; // make-set i : 자신의 부모를 자신으로하여 대표자가 되도록 설정
		}
	}
	static int findSet(int a) {
		if(a==parents[a]) return a; // 자신이 자신의 부모라면 루트노드이고 집합의 대표자가 됨
//		return findSet(parents[a]);
		return parents[a] = findSet(parents[a]);
	}
	
	static boolean union(int a, int b) {
		int aRoot = findSet(a);
		int bRoot = findSet(b);
		if(aRoot == bRoot) return false; // 두 집합의 대표자가 같으면 이미 같은 집합이므로 합집합 연산 불가
		//aRoot에 bRoot를 흡수 : 두 집합 합치기
		parents[bRoot] = aRoot;
		return true;
	}
}
