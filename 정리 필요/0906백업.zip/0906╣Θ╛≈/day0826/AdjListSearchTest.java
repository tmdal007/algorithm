package day0826;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;
import java.util.Scanner;

public class AdjListSearchTest {
	static class Node{
		int to;
		Node next;
		
		public Node(int to, Node next) {
			super();
			this.to = to;
			this.next = next;
		}

		@Override
		public String toString() {
			return "Node [to=" + to + ", next=" + next + "]";
		}	
		
	}
	
	static int V;
	static Node[] adjList;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		V = sc.nextInt(); // 정점 개수
		int E = sc.nextInt(); // 간선 개수
		
		adjList = new Node[V];
		for (int i = 0; i < E; ++i) {
			int from = sc.nextInt();
			int to = sc.nextInt();
			adjList[from] = new Node(from,adjList[from]);
			adjList[to] = new Node(from,adjList[to]); 
		}
		bfs1(0);
		dfs(0, new boolean[V]);

	}
	private static void dfs(int cur, boolean[] visited) {
		
		visited[cur] = true;
		
		// 방문했을때 해야할 작업들....
		 System.out.println((char)(cur+65));
		 
		 //자신의 인접정점들 다음 탐색위한 준비!
		 for (Node temp = adjList[cur]; temp != null; temp = temp.next) {
			 if(visited[temp.to]) continue;
			 
			 dfs(temp.to,visited);
		}
	}
	private static void bfs1(int start) {
		
		Queue<Integer> queue = new ArrayDeque<>();
		boolean[] visited = new boolean[V];
		
		visited[start] = true;
		queue.offer(start);
		
		while(!queue.isEmpty()) {
			
			int cur = queue.poll();
			
			// 방문했을때 해야할 작업들....
			 System.out.println((char)(cur+65));
			 
			 //자신의 인접정점들 다음 탐색위한 준비!
			 for (Node temp = adjList[cur]; temp != null; temp = temp.next) {
				 if(visited[temp.to]) continue;
				 
				 visited[temp.to] = true;
				 queue.offer(temp.to);
			}
		}
	}

}
