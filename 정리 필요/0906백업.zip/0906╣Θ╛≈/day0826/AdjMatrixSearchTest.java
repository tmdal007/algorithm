package day0826;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Queue;
import java.util.Scanner;

import day0823.AdjMatrixTest;
/*
 * 7
8
0 1
0 2	
1 3
1 4
2 4
3 5
4 5
5 6	
 */
public class AdjMatrixSearchTest {

	static int[][] adjMatrix;
	static int V,E;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		V = sc.nextInt();
		E = sc.nextInt();
		
		// 무향 그래프
		adjMatrix = new int[V][V]; // 기본 초기화값 0 : 인접하지 않는 상태
		for (int i = 0; i < E; ++i) {
				int from = sc.nextInt();
				int to = sc.nextInt();
				adjMatrix[to][from] = adjMatrix[from][to] = 1; 
		}
		
//		bfs1(0);
		System.out.println("=================");
//		bfs2(0);
//		bfs3(0);
		dfs(0,new boolean[V]);
	}
	private static void dfs(int cur, boolean[] visited) {
		
		visited[cur] = true;
		
		// 방문했을때 해야할 작업들....
//		 System.out.println((char)(cur+65));
		 System.out.println(cur);
		 
		 //자신의 인접정점들 다음 탐색위한 준비!
		 for (int i = 0; i < V; i++) {
			 if(adjMatrix[cur][i] == 0 || visited[i]) continue;
			 
			 dfs(i,visited);
		}
	}
	private static void bfs1(int start) {
		
		Queue<Integer> queue = new ArrayDeque<>();
		boolean[] visited = new boolean[V];
		
		visited[start] = true;
		queue.offer(start);
		
		while(!queue.isEmpty()) {
			
			int cur = queue.poll();
			
			// 방문했을때 해야할 작업들....
			 System.out.println((char)(cur+65));
			 
			 //자신의 인접정점들 다음 탐색위한 준비!
			 for (int i = 0; i < V; i++) {
				 if(adjMatrix[cur][i] == 0 || visited[i]) continue;
				 
				 visited[i] = true;
				 queue.offer(i);
				
			}
		}
	}
	private static void bfs2(int start) {
		
		Queue<Integer> queue = new ArrayDeque<>();
		boolean[] visited = new boolean[V];
		
		queue.offer(start);
		
		while(!queue.isEmpty()) {
			
			int cur = queue.poll();
			visited[cur] = true;
			// 방문했을때 해야할 작업들....
			 System.out.println((char)(cur+65));
			 
			 //자신의 인접정점들 다음 탐색위한 준비!
			 for (int i = 0; i < V; i++) {
				 if(adjMatrix[cur][i] == 0 || visited[i]) continue;
	
				 queue.offer(i);
				
			}
		}
	}
	
	private static void bfs3(int start) {
		
		Queue<Integer> queue = new ArrayDeque<>();
		boolean[] visited = new boolean[V];
		
		visited[start] = true;
		queue.offer(start);
		int breadth = 0;
		
		while(!queue.isEmpty()) {
			
			int size = queue.size(); // 큐의 크기체크
			
			while(--size >=0) { // 기존 큐의 크기만큼만 뺌
				
				int cur = queue.poll();
				
				// 방문했을때 해야할 작업들....
				 System.out.print((char)(cur+65)+" ");
				 
				 //자신의 인접정점들 다음 탐색위한 준비!
				 for (int i = 0; i < V; i++) {
					 if(adjMatrix[cur][i] == 0 || visited[i]) continue;
					 
					 visited[i] = true;
					 queue.offer(i);
					
				}
			} // 동일 너비 처리
			System.out.println();
			++breadth; // 너비 증가
		}
	}

}
