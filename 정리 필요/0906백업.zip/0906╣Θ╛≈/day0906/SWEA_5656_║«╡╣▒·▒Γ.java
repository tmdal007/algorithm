package day0906;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class SWEA_5656_벽돌깨기 {
	static int N,W,H, map[][],copy[][], num[];
	static boolean[] visited;
	static int[] dx = {-1,1,0,0};
	static int[] dy = {0,0,-1,1};
	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/s_5656_input.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		StringTokenizer st = new StringTokenizer(br.readLine());
		N = Integer.parseInt(st.nextToken());
		W = Integer.parseInt(st.nextToken());
		H = Integer.parseInt(st.nextToken());
		map = new int[W][H];
		copy = new int[W][H];
		visited = new boolean[W];
		for(int i=0; i<W; i++) {
			st = new StringTokenizer(br.readLine());
			for(int j=0; j<H; j++) {
				map[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		perm(0);
		
		
	}
	static void perm(int cnt) {
		if(cnt == N) { // 구슬 개수의 원소를 가진 중복 순열이 생성되면
			start(num); // 해당 중복 순열을 이용해서 bfs 탐색 시작
			
		}
		for(int i=0; i<W; i++) {
			num[cnt] = i;
			perm(cnt+1);
		}
	}
	static void start(int [] number) {
		int x = 0;
		int y = 0;
		for(int i = 0; i < H; i++) {
			for (int j = 0; j < W; j++) { 
				if(map[j][i] != 0) { // 해당 위치의 값이 0이 아니면 블록
					x = j;
					y = i;
					break;
				}
			}
		}
		bfs(x,y);
		crush();
	}
	static void bfs(int x, int y) {
		Queue<int[]> q = new LinkedList<>();
		q.offer(new int[] {x,y,map[x][y]});
		map[x][y] = 0;
		
		while(!q.isEmpty()) {
			int[] cur = q.poll();
			int curX = cur[0];
			int curY = cur[1];
			int power = cur[2];
			
			for(int i=1; i<=power; i++) {
				for(int d = 0; d < 4; d++) {
					int nx = curX + dx[d] * i;
					int ny = curY + dy[d] * i;
					
					if(nx < 0 || nx >= W || ny < 0 || ny >= H) continue;
				
				}
			}
		}
		
	}
	static void crush() {
		
	}

}
