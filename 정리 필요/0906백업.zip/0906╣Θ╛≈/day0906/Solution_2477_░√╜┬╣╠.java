package day0906;
/*
 * SWEA 2477. 차량 정비소
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Queue;
import java.util.StringTokenizer;

public class Solution_2477_곽승미 {
	static int N,M,K,A,B;
	static class Person{
		int number, time, a,b;

		public Person(int number, int time, int a, int b) {
			super();
			this.number = number;
			this.time = time;
			this.a = a;
			this.b = b;
		}
	}
	public static void main(String[] args) throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		for(int tc=1; tc<=T; tc++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			K = Integer.parseInt(st.nextToken());
			A = Integer.parseInt(st.nextToken());
			B = Integer.parseInt(st.nextToken());
			
			int[] costA = new int[N]; // 접수 창구
			int[] costB = new int[M]; // 정비 창구
			st = new StringTokenizer(br.readLine());
			for (int i = 0; i < N; i++) {
				costA[i] = Integer.parseInt(st.nextToken());
			}
			st = new StringTokenizer(br.readLine());
			for (int i = 0; i < M; i++) {
				costB[i] = Integer.parseInt(st.nextToken());
			}
			Person[] person = new Person[K];
			st = new StringTokenizer(br.readLine());
			for (int i = 0; i < K; i++) {
				person[i] = new Person(i+1, Integer.parseInt(st.nextToken()), 0, 0);
			}
			
			
		}
	}

}
