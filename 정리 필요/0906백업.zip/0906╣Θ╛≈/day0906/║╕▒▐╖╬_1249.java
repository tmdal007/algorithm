package day0906;
/*
 * SWEA 1249. 보급로
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.PriorityQueue;

public class 보급로_1249 {
	static int N, map[][],result;
	static boolean visited[][];
	static int[] dx = {-1,1,0,0};
	static int[] dy = {0,0,-1,1};
	
	static class Location{
		int x,y,time;

		public Location(int x, int y, int time) {
			super();
			this.x = x;
			this.y = y;
			this.time = time;
		}
		private int compareTo(Location o) {
			return this.time - o.time;
		}
		
	}
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		for (int tc = 1; tc <= T; tc++) {
			int N = Integer.parseInt(br.readLine());
			map = new int[N][N];
			visited = new boolean[N][N];
			for (int i = 0; i < N; i++) {
				char[] line = br.readLine().toCharArray();
				for (int j = 0; j < N; j++) {
					map[i][j] = line[j]-'0';
				}
			}
			result = 0;
			cal();
			System.out.println("#"+tc+" "+result);
		}
	}
	static int cal() {
		PriorityQueue<Location> pq = new PriorityQueue<>();
		pq.offer(new Location(0, 0, 0));
		
		while(!pq.isEmpty()) {
			Location cur = pq.poll();
			int x = cur.x;
			int y = cur.y;
			int t = cur.time;
			
			for(int d=0; d<4; d++) {
				int nx = x + dx[d];
				int ny = y + dy[d];
				
				if(nx == N-1 && ny == N-1) {
					return cur.time;
				}
				if(nx < 0 || nx >= N || ny < 0 || ny >= N) {
					continue;
				}
				if(!visited[nx][ny]) {
					visited[nx][ny] = true;
					t += map[nx][ny];
					pq.offer(new Location(nx, ny, t));
				}
			}
		}

		return -1;
	}
}
