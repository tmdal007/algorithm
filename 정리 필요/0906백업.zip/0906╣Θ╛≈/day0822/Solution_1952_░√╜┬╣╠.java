package day0822;

public class Solution_1952_곽승미 {

	public static void main(String[] args) {
		

	}

}
