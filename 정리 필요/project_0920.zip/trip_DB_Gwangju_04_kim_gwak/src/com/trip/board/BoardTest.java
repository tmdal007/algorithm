package com.trip.board;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.trip.board.model.TourDto;
import com.trip.board.model.UserDto;
import com.trip.board.model.service.BoardServiceImpl;

public class BoardTest {
	static BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	
	static BoardServiceImpl service = BoardServiceImpl.getBoardService();
	
	static void tourInfo() throws NumberFormatException, IOException {
		List<TourDto> list = null;
		int sido = service.selectSido();
		int gugun = service.selectGugun(sido);
		
		list = service.tourInfo(sido, gugun);
		for(TourDto article : list) {
			System.out.println(article);
		}
	}
	static void userInfo(int c) throws NumberFormatException, IOException {
		switch (c) {
		case 1:
			service.userJoin();
			break;
		case 2:
			service.userUpdate();
			break;
		case 3:
			List<UserDto> list = null;
			list = service.userSearchOne();
			for(UserDto article : list) {
				System.out.println(article.toString());
			}
			break;
		case 4:
			List<UserDto> searchlist = null;
			searchlist = service.userSearchAll();
			for(UserDto article : searchlist) {
				System.out.println(article.toString());
			}
			break;
		case 5:
			service.userDelete();
		default:
			System.exit(0);
		}
	}

	
	public static void main(String[] args) throws NumberFormatException, IOException {
		while(true) {
			
			System.out.println("1. 회원 관리");
			System.out.println("2. 관광지 조회");
			System.out.println("3. 게시판 관리");
			System.out.println("4. 로그인 관리");
			System.out.println("5. 종료");
			
			System.out.print("번호를 선택하세요 : ");
			
			int n = Integer.parseInt(bf.readLine());
			
			if (n == 1) {
				
				System.out.println("1. 회원 가입"); // INSERT
				System.out.println("2. 정보 수정"); // UPDATE
				System.out.println("3. 특정 회원 조회"); // SELECT
				System.out.println("4. 전체 회원 조회");
				System.out.println("5. 회원 탈퇴"); // DELETE
				System.out.print("번호를 입력해주세요 : ");
				
				int click = Integer.parseInt(bf.readLine());
				
				userInfo(click);
				
			} else if (n == 2) {
				
				tourInfo();
				
			} else if (n == 3) {
				
//				boardManager();
				
			} else if (n == 4){
				
//				login();
				
			} else if (n == 5){
				break;
			}
		}

	}

}
