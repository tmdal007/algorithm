package com.trip.board.model.service;

import java.io.IOException;
import java.util.List;

import com.trip.board.model.BoardDto;
import com.trip.board.model.NoticeDto;
import com.trip.board.model.TourDto;
import com.trip.board.model.UserDto;
import com.trip.board.model.dao.BoardDaoImpl;

public class BoardServiceImpl implements BoardService {
	private BoardServiceImpl() {}
	private static BoardServiceImpl instance = new BoardServiceImpl();
	public static BoardServiceImpl getBoardService() {
		return instance;
	}
	
	@Override
	public int selectSido() throws NumberFormatException, IOException {
		return BoardDaoImpl.getBoardDao().selectSido();
	}
	
	@Override
	public int selectGugun(int sido) throws NumberFormatException, IOException {
		return BoardDaoImpl.getBoardDao().selectGugun(sido);
	}

	@Override
	public List<TourDto> tourInfo(int sido, int gugun) throws NumberFormatException, IOException {
		return BoardDaoImpl.getBoardDao().tourInfo(sido, gugun);
	}

	@Override
	public void userJoin() throws NumberFormatException, IOException {
		BoardDaoImpl.getBoardDao().userJoin();
	}

	@Override
	public void userUpdate() throws NumberFormatException, IOException {
		BoardDaoImpl.getBoardDao().userUpdate();
		
	}

	@Override
	public List<UserDto> userSearchOne() throws NumberFormatException, IOException {
		return BoardDaoImpl.getBoardDao().userSearchOne();
	}

	@Override
	public List<UserDto> userSearchAll() throws NumberFormatException, IOException {
		return BoardDaoImpl.getBoardDao().userSearchAll();
	}

	@Override
	public void userDelete() throws NumberFormatException, IOException {
		BoardDaoImpl.getBoardDao().userDelete();
		
	}

	@Override
	public void cWriting(int x) throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cUpdate(int x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cDelete(int x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<BoardDto> cSelect() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<NoticeDto> nSelect() {
		// TODO Auto-generated method stub
		return null;
	}
}
