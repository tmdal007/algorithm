package com.ssafy.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.board.model.BoardDto;
import com.ssafy.util.DBUtil;

public class BoardDaoImpl implements BoardDao{

	private static BoardDao boardDao = new BoardDaoImpl();
	
	private BoardDaoImpl() {
	}

	public static BoardDao getBoardDao() {
		return boardDao;
	}
	
	@Override
	public int writeArticle(BoardDto boardDto) {
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			conn = dbu.getConnection();

			StringBuilder sql = new StringBuilder("insert into board (user_id, subject, content) \n");
			sql.append("values (?, ?, ?)");
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setString(1, boardDto.getUserId());
			pstmt.setString(2, boardDto.getSubject());
			pstmt.setString(3, boardDto.getContent());
			
			pstmt.executeUpdate();
		
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		
		return 1;
	}

	@Override
	public List<BoardDto> listArticle() {
		List<BoardDto> board_list = new ArrayList<BoardDto>();
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			conn = dbu.getConnection();
			
			StringBuilder sql = new StringBuilder("select * from board");
			pstmt = conn.prepareStatement(sql.toString());
			
			rs = pstmt.executeQuery();
		
			while(rs.next()) {
				BoardDto bto = new BoardDto();
				
				bto.setArticleNo(rs.getInt("article_no"));
				bto.setUserId(rs.getString("user_id"));
				bto.setSubject(rs.getString("subject"));
				bto.setContent(rs.getString("content"));
				bto.setHit(rs.getInt("hit"));
				bto.setRegisterTime(rs.getString("register_time"));
				
				board_list.add(bto);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}

		return board_list;
	}

	@Override
	public BoardDto viewArticle(int articleNo) {
		
		DBUtil dbu = DBUtil.getInstance();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		BoardDto bto = new BoardDto();
		
		try {
			
			conn = dbu.getConnection();
			
			StringBuilder sql = new StringBuilder("select user_id, subject, content, hit, register_time from board where article_no = "+articleNo+" \n");
			pstmt = conn.prepareStatement(sql.toString());
			
			rs = pstmt.executeQuery();
		
			if(rs.next()) {
				bto.setArticleNo(articleNo);
				bto.setUserId(rs.getString("user_id"));
				bto.setSubject(rs.getString("subject"));
				bto.setContent(rs.getString("content"));
				bto.setHit(rs.getInt("hit"));
				bto.setRegisterTime(rs.getString("register_time"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		
		return bto;
	}

	@Override
	public void updateHit(int articleNo) {
		// TODO Auto-generated method stub
		
	}

}
