package com.ssafy.board.service;

import java.util.List;

import com.ssafy.board.model.BoardDto;

public interface BoardService {

	int writeArticle(BoardDto boardDto);
	List<BoardDto> listArticle();
	BoardDto viewArticle(int articleNo);
	void updateHit(int articleNo);
}
