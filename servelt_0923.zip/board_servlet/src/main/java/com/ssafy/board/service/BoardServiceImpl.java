package com.ssafy.board.service;

import java.util.List;

import com.ssafy.board.dao.BoardDaoImpl;
import com.ssafy.board.model.BoardDto;

public class BoardServiceImpl implements BoardService{

	private BoardServiceImpl() {}
	private static BoardServiceImpl instance = new BoardServiceImpl();
	public static BoardServiceImpl getBoardService() {
		return instance;
	}
	
	@Override
	public int writeArticle(BoardDto boardDto) {
		return BoardDaoImpl.getBoardDao().writeArticle(boardDto);
	}

	@Override
	public List<BoardDto> listArticle() {
		return BoardDaoImpl.getBoardDao().listArticle();
	}

	@Override
	public BoardDto viewArticle(int articleNo) {
		// TODO Auto-generated method stub
		return BoardDaoImpl.getBoardDao().viewArticle(articleNo);
	}

	@Override
	public void updateHit(int articleNo) {
		// TODO Auto-generated method stub
		
	}

}
