package com.ssafy.notice.model.service;

import com.ssafy.notice.model.NoticeDto;
import com.ssafy.notice.model.NoticeListDto;
import com.ssafy.notice.model.mapper.NoticeMapper;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class NoticeServiceImpl implements NoticeService {

    private final NoticeMapper boardMapper;

    public NoticeServiceImpl(NoticeMapper boardMapper) {
        this.boardMapper = boardMapper;
    }

    // 게시글 전체 목록 조회
    @Override
    public NoticeListDto getAllArticles(Map<String, String> map) throws SQLException {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("word", map.get("word") == null ? "" : map.get("word"));
		int currentPage = Integer.parseInt(map.get("pgno") == null ? "1" : map.get("pgno"));
		int sizePerPage = Integer.parseInt(map.get("spp") == null ? "20" : map.get("spp"));
		int start = currentPage * sizePerPage - sizePerPage;
		param.put("start", start);
		param.put("listsize", sizePerPage);

		String key = map.get("key");
		param.put("key", key == null ? "" : key);
		if ("user_id".equals(key))
			param.put("key", key == null ? "" : "b.user_id");
		List<NoticeDto> list = boardMapper.getAllArticles(param);

		if ("user_id".equals(key))
			param.put("key", key == null ? "" : "user_id");
		int totalArticleCount = boardMapper.getTotalArticleCount(param);
		int totalPageCount = (totalArticleCount - 1) / sizePerPage + 1;

		NoticeListDto boardListDto = new NoticeListDto();
		boardListDto.setArticles(list);
		boardListDto.setCurrentPage(currentPage);
		boardListDto.setTotalPageCount(totalPageCount);
        return boardListDto;
    }

    // 특정 게시글 조회
    @Override
    public NoticeDto getArticle(int articleNo) {
        return boardMapper.getArticle(articleNo);
    }
    // 게시글 조회수 업데이트
	@Override
	public void updateHit(int articleNo){
		boardMapper.updateHit(articleNo);
	}

    // 게시글 작성
    @Transactional
    @Override
    public void createArticle(NoticeDto boardDto) {
        boardMapper.createArticle(boardDto);
    }

    // 게시글 수정
    @Transactional
    @Override
    public boolean updateArticle(NoticeDto boardDto) {
        return boardMapper.updateArticle(boardDto) > 0;
    }

    // 게시글 삭제
    @Transactional
    @Override
    public boolean deleteArticle(int articleNo) {
        return boardMapper.deleteArticle(articleNo) > 0;
    }
}
