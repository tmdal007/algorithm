package com.ssafy.plan.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DayPlanDto {
	private int dayPlanNo;
	private int planNo;
	private int days;
	private String memo;

	// 추가: 하루 일정에 포함된 관광지 리스트
	private List<AttractionDto> attractions;
}
