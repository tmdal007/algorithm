package com.ssafy.plan.model.service;

import com.ssafy.attraction.model.AttractionDetailDto;
import com.ssafy.attraction.model.AttractionInfoDto;
import com.ssafy.plan.model.AttractionDto;
import com.ssafy.plan.model.DayPlanDto;
import com.ssafy.plan.model.PlanDto;

import java.util.List;

public interface PlanService {

    // 여행 계획 관련
    void createPlan(PlanDto planDto, List<DayPlanDto> dayPlans);
    void updatePlan(PlanDto planDto, List<DayPlanDto> dayPlans);
    void deletePlan(int planNo);
    PlanDto getPlan(int planNo);
    List<PlanDto> getAllPlans();

    // 하루 일정 관련
    void addDayPlan(DayPlanDto dayPlanDto);
    void deleteDayPlan(int dayPlanNo);
    List<DayPlanDto> getDayPlans(int planNo);

    // 관광지 관련
    void addAttraction(AttractionDto attractionDto);
    void deleteAttraction(int dayPlanNo, int attractionNo);
    List<AttractionDto> getAttractions(int dayPlanNo);
    void updateAttractionTime(int dayPlanNo, int attractionNo, String time); // 관광지 방문 시간(time) 수정
    void updateAttractionsOrder(int dayPlanNo, List<AttractionDto> attractions); // plan에서 관광지 순서 관리

    // 사용자 관련
    int getMaxPlanNo(String userId);
    List<PlanDto> getUserPlans(String userId);
    
    List<AttractionDetailDto> getAttractionInfo(int dayPlanNo); // 특정 하루 일정의 관광지 정보
}
