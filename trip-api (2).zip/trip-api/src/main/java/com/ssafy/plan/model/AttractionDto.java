package com.ssafy.plan.model;

import java.sql.Time;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AttractionDto {
	private int attractionPlanNo;
	private int dayPlanNo;
	private int attractionNo;
	private String time; // 관광지 방문 예정 시간
	private int orderNo;
}
