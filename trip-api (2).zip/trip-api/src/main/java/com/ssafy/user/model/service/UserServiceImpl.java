package com.ssafy.user.model.service;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ssafy.user.model.UserDto;
import com.ssafy.user.model.mapper.UserMapper;

@Service
public class UserServiceImpl implements UserService {
	
//	@Autowired
//	private SqlSession sqlSession;
	
	private final UserMapper memberMapper;

	public UserServiceImpl(UserMapper memberMapper) {
		super();
		this.memberMapper = memberMapper;
	}

//	@Override
//	public int idCheck(String userId) throws Exception {
////		return sqlSession.getMapper(MemberMapper.class).idCheck(userId);
//		return memberMapper.idCheck(userId);
//	}
//
//	@Override
//	public void joinMember(MemberDto memberDto) throws Exception {
////		sqlSession.getMapper(MemberMapper.class).joinMember(memberDto);
//		memberMapper.joinMember(memberDto);
//	}

    // 로그인 처리
	@Override
	public UserDto login(UserDto memberDto) throws Exception {
		return memberMapper.login(memberDto);
	}
	
	// 사용자 정보 가져오기(토큰을 통해 아이디 반환)
	@Override
	public UserDto userInfo(String userId) throws Exception {
		return memberMapper.userInfo(userId);
	}

	// 리프레쉬토큰 저장
	@Override
	public void saveRefreshToken(String userId, String refreshToken) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("token", refreshToken);
		memberMapper.saveRefreshToken(map);
	}

	// 
	@Override
	public Object getRefreshToken(String userId) throws Exception {
		return memberMapper.getRefreshToken(userId);
	}

	@Override
	public void deleRefreshToken(String userId) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("token", null);
		memberMapper.deleteRefreshToken(map);
	}
	
	/* ADMIN */
	@Override
	public List<UserDto> listMember(Map<String, Object> map) throws Exception {
		return memberMapper.listMember(map);
	}

	@Override
	public UserDto getMember(String userId) throws Exception {
		return memberMapper.getMember(userId);
	}

	@Override
	public void updateMember(UserDto memberDto) throws Exception {
		memberMapper.updateMember(memberDto);
	}

	@Override
	public void deleteMember(String userId) throws Exception {
		memberMapper.deleteMember(userId);		
	}

	@Override
	public void newPassword(String userId, String pwd) throws Exception{
		memberMapper.newPassword(userId,pwd);
	}

	@Override
	public boolean isIdDuplicate(String userId) {
		return memberMapper.selectById(userId) != null; // Mapper에서 해당 아이디를 조회
	}

	@Override
	public boolean register(UserDto memberDto) {
		return memberMapper.insert(memberDto) > 0; // Mapper에서 삽입 성공 시 1 반환
	}

	@Override
	public boolean updateUserField(String userId, String currentPassword, String newPassword) throws Exception {
		// 1. 현재 비밀번호 검증
	    UserDto member = memberMapper.selectById(userId);
	    if (member == null || !member.getUserPwd().equals(currentPassword)) {
	        return false;
	    }
	    
	    // 2. 비밀번호 업데이트 (컬럼 검증 포함)
	    if (!isValidColumn("user_password")) {
	        throw new IllegalArgumentException("유효하지 않은 컬럼");
	    }
	    
	    // 2. 비밀번호 업데이트
	    return memberMapper.updateUserField(userId, "user_password", newPassword) > 0;
	}

	private boolean isValidColumn(String column) {
		 List<String> validColumns = Arrays.asList("email", "user_password");
	     return validColumns.contains(column);
	}

	@Override
	public boolean updateEmail(String userId, String emailId, String emailDomain) {
		return memberMapper.updateEmail(userId, emailId, emailDomain) > 0;
	}

	@Override
	public boolean withdrawMember(String userId, String password) throws SQLException {
		UserDto member = memberMapper.userInfo(userId);
		if(member == null) {
			return false;
		}
		if(!password.equals(member.getUserPwd())) {
			return false;
		}
		int result = memberMapper.deleteMember(userId);
		return result > 0;
	}
	
	

}
