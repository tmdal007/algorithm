package com.ssafy.user.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import com.ssafy.email.model.EmailMessage;
import com.ssafy.email.model.service.EmailService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ssafy.user.model.UserDto;
import com.ssafy.user.model.service.UserService;
import com.ssafy.util.JWTUtil;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@Slf4j
@RestController 
@RequestMapping("/user")
@Tag(name = "UserController", description = "사용자의 회원가입, 로그인, 로그아웃을 처리하는 클래스")
public class UserController {

	private final UserService memberService;
	private final JWTUtil jwtUtil;
	private final EmailService emailService;

	public UserController(UserService memberService, JWTUtil jwtUtil, EmailService emailService) {
		super();
		this.memberService = memberService;
		this.jwtUtil = jwtUtil;
		this.emailService = emailService;
	}

	@Operation(summary = "로그인", description = "아이디와 비밀번호를 이용하여 로그인 처리.")
	@PostMapping("/login")
	public ResponseEntity<Map<String, Object>> login(
			@RequestBody @Parameter(description = "로그인 시 필요한 회원정보(아이디, 비밀번호).", required = true) UserDto memberDto) {
		log.debug("login user : {}", memberDto);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HttpStatus status = HttpStatus.ACCEPTED;
		try {
			UserDto loginUser = memberService.login(memberDto);
			if(loginUser != null) {
				String accessToken = jwtUtil.createAccessToken(loginUser.getUserId());
				String refreshToken = jwtUtil.createRefreshToken(loginUser.getUserId());
				log.debug("access token : {}", accessToken);
				log.debug("refresh token : {}", refreshToken);
				
//				발급받은 refresh token 을 DB에 저장.
				memberService.saveRefreshToken(loginUser.getUserId(), refreshToken);
				
//				JSON 으로 token 전달.
				resultMap.put("access-token", accessToken);
				resultMap.put("refresh-token", refreshToken);
				
				status = HttpStatus.CREATED;
			} else {
				resultMap.put("message", "아이디 또는 패스워드를 확인해 주세요.");
				status = HttpStatus.UNAUTHORIZED;
			} 
			
		} catch (Exception e) {
			log.debug("로그인 에러 발생 : {}", e);
			resultMap.put("message", e.getMessage());
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
	
	@Operation(summary = "회원인증", description = "회원 정보를 담은 Token 을 반환한다.")
	@GetMapping("/info/{userId}")
	public ResponseEntity<Map<String, Object>> getInfo(
			@PathVariable("userId") @Parameter(description = "인증할 회원의 아이디.", required = true) String userId,
			@RequestHeader("Authorization") String header) {
		log.debug("userId : {}, header : {} ", userId, header);
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = HttpStatus.ACCEPTED;
//		if (jwtUtil.checkToken(request.getHeader("Authorization"))) {
		if (jwtUtil.checkToken(header)) {
			log.info("사용 가능한 토큰!!!");
			try {
//				로그인 사용자 정보.
				UserDto memberDto = memberService.userInfo(userId);
				resultMap.put("userInfo", memberDto);
				status = HttpStatus.OK;
			} catch (Exception e) {
				log.error("정보조회 실패 : {}", e);
				resultMap.put("message", e.getMessage());
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
		} else {
			log.error("사용 불가능 토큰!!!");
			status = HttpStatus.UNAUTHORIZED;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}

	@Operation(summary = "로그아웃", description = "회원 정보를 담은 Token 을 제거한다.")
	@GetMapping("/logout/{userId}")
	@Hidden
	public ResponseEntity<?> removeToken(@PathVariable ("userId") @Parameter(description = "로그아웃 할 회원의 아이디.", required = true) String userId) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = HttpStatus.ACCEPTED;
		try {
			memberService.deleRefreshToken(userId);
			status = HttpStatus.OK;
		} catch (Exception e) {
			log.error("로그아웃 실패 : {}", e);
			resultMap.put("message", e.getMessage());
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}

	@Operation(summary = "Access Token 재발급", description = "만료된 access token 을 재발급 받는다.")
	@PostMapping("/refresh")
	public ResponseEntity<?> refreshToken(@RequestBody UserDto memberDto, @RequestHeader("refreshToken") String token)
			throws Exception {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = HttpStatus.ACCEPTED;
//		String token = request.getHeader("refreshToken");
		log.debug("token : {}, memberDto : {}", token, memberDto);
		if (jwtUtil.checkToken(token)) {
			if (token.equals(memberService.getRefreshToken(memberDto.getUserId()))) {
				String accessToken = jwtUtil.createAccessToken(memberDto.getUserId());
				log.debug("token : {}", accessToken);
				log.debug("정상적으로 access token 재발급!!!");
				resultMap.put("access-token", accessToken);
				status = HttpStatus.CREATED;
			}
		} else {
			log.debug("refresh token 도 사용 불가!!!!!!!");
			status = HttpStatus.UNAUTHORIZED;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
	
	@Operation(summary = "아이디 중복 확인", description = "입력받은 아이디가 이미 존재하는지 확인합니다.")
	@PostMapping("/check-id")
	public ResponseEntity<Map<String, Object>> checkIdDuplicate(
	        @RequestBody @Parameter(description = "중복 확인할 아이디", required = true) Map<String, String> param) {
	    String userId = param.get("userId");
	    log.debug("checkIdDuplicate userId: {}", userId);

	    Map<String, Object> resultMap = new HashMap<>();
	    HttpStatus status = HttpStatus.ACCEPTED;

	    try {
	        boolean isDuplicate = memberService.isIdDuplicate(userId);
	        if (isDuplicate) {
	            resultMap.put("message", "아이디가 이미 존재합니다.");
	            status = HttpStatus.CONFLICT; // 409 Conflict
	        } else {
	            resultMap.put("message", "사용 가능한 아이디입니다.");
	            status = HttpStatus.OK;
	        }
	    } catch (Exception e) {
	        log.error("아이디 중복 확인 실패: {}", e);
	        resultMap.put("message", e.getMessage());
	        status = HttpStatus.INTERNAL_SERVER_ERROR;
	    }

	    return new ResponseEntity<>(resultMap, status);
	}
	
	@Operation(summary = "회원가입", description = "입력받은 정보로 회원을 등록합니다.")
	@PostMapping("/register")
	public ResponseEntity<Map<String, Object>> registerUser(
	        @RequestBody @Parameter(description = "회원가입에 필요한 정보", required = true) UserDto memberDto) {
	    log.debug("registerUser: {}", memberDto);

	    Map<String, Object> resultMap = new HashMap<>();
	    HttpStatus status = HttpStatus.ACCEPTED;

	    try {
	        boolean isRegistered = memberService.register(memberDto);
	        if (isRegistered) {
	            resultMap.put("message", "회원가입 성공");
	            status = HttpStatus.CREATED; // 201 Created
	        } else {
	            resultMap.put("message", "회원가입 실패");
	            status = HttpStatus.BAD_REQUEST; // 400 Bad Request
	        }
	    } catch (Exception e) {
	        log.error("회원가입 실패: {}", e);
	        resultMap.put("message", e.getMessage());
	        status = HttpStatus.INTERNAL_SERVER_ERROR; // 500 Internal Server Error
	    }

	    return new ResponseEntity<>(resultMap, status);
	}
	
	@Operation(summary = "회원 정보 업데이트", description = "회원의 정보를 업데이트합니다.")
	@PutMapping("/update")
	public ResponseEntity<?> updateField(@RequestBody Map<String, String> param) {
	    String userId = param.get("userId");
	    String column = param.get("column");
	    String value = param.get("value");
	    String currentPassword = param.get("currentPassword"); // Add this

	    try {
	        // 이메일 처리 로직
	        if ("email".equalsIgnoreCase(column)) {
	            if (value.contains("@")) {
	                String[] emailParts = value.split("@");
	                if (emailParts.length == 2) {
	                    String emailId = emailParts[0];
	                    String emailDomain = emailParts[1];
	                    boolean isUpdated = memberService.updateEmail(userId, emailId, emailDomain);
	                    if (isUpdated) {
	                        return ResponseEntity.ok("이메일 정보가 성공적으로 업데이트되었습니다.");
	                    } else {
	                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("이메일 업데이트 실패");
	                    }
	                } else {
	                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("잘못된 이메일 형식입니다.");
	                }
	            } else {
	                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("이메일에는 '@'가 포함되어야 합니다.");
	            }
	        }

	        // 일반 필드 업데이트
	        boolean isUpdated = memberService.updateUserField(userId, currentPassword, value);
	        if (isUpdated) {
	            return ResponseEntity.ok("회원 정보가 성공적으로 업데이트되었습니다.");
	        } else {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("회원 정보 업데이트 실패");
	        }
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("오류 발생: " + e.getMessage());
	    }
	}
	
	 @Operation(summary = "회원 탈퇴", description = "회원 아이디와 비밀번호 검증 후 회원 정보를 삭제합니다.")
	@PostMapping("/withdraw")
	public ResponseEntity<Map<String, Object>> withdrawMember(
			@RequestBody @Parameter(description = "회원 탈퇴 정보", required = true) Map<String, String> param) {

		String userId = param.get("userId");
		String password = param.get("password");
		log.debug("withdrawMember userId: {}", userId);

		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = HttpStatus.ACCEPTED;

		// 필수 파라미터 검증
		if (userId == null || password == null || userId.isEmpty() || password.isEmpty()) {
			resultMap.put("message", "아이디와 비밀번호를 모두 입력해주세요.");
			return new ResponseEntity<>(resultMap, HttpStatus.BAD_REQUEST);
		}

		try {
			boolean isWithdrawn = memberService.withdrawMember(userId, password);

			if (isWithdrawn) {
				resultMap.put("message", "회원 탈퇴가 완료되었습니다.");
				status = HttpStatus.OK;
			} else {
				resultMap.put("message", "아이디 또는 비밀번호가 일치하지 않습니다.");
				status = HttpStatus.BAD_REQUEST;
			}
		} catch (Exception e) {
			log.error("회원 탈퇴 실패: {}", e);
			resultMap.put("message", "회원 탈퇴 처리 중 오류가 발생했습니다.");
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}

		return new ResponseEntity<>(resultMap, status);
	}

	@Operation(summary = "비밀번호 찾기", description = "회원 아이디와 비밀번호 검증 후 회원 정보를 삭제합니다.")
	@PostMapping("/findpwd")
	public ResponseEntity<?> findPassword(@RequestBody Map<String, String> param){
		String userId = param.get("userId");
		String userEmail = param.get("userEmail");

		try{
			UserDto userDto = memberService.userInfo(userId);

			if(userDto == null || !(userDto.getEmailId()+"@"+userDto.getEmailDomain()).equals(userEmail)){
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("데이터 불일치");
			}

			int tmpPwd = ThreadLocalRandom.current().nextInt(100000, 1000000);
			String tmp = Integer.toString(tmpPwd);
			memberService.newPassword(userId, tmp);

			EmailMessage emailMessage = new EmailMessage();
			emailMessage.setTo(userEmail);
			emailMessage.setSubject("miyeo 임시 비밀번호 발급");
			emailMessage.setMessage("임시 비밀번호는 [ " + tmpPwd + " ] 입니다.");

			emailService.sendMail(emailMessage);

			return ResponseEntity.ok("임시 비밀번호가 성공적으로 발급되었습니다.");

		}catch (Exception e){
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("오류 발생: " + e.getMessage());
		}
	}

}
