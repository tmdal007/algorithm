package com.ssafy.user.model.mapper;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.user.model.UserDto;

@Mapper
public interface UserMapper {

//	int idCheck(String userId) throws SQLException;
//	void joinMember(MemberDto memberDto) throws SQLException;
//	MemberDto loginMember(Map<String, String> map) throws SQLException;
	
    // 아이디로 회원 조회
    UserDto selectById(String userId);
    // 회원 정보 삽입
    int insert(UserDto memberDto);
	
	UserDto login(UserDto memberDto) throws SQLException;
	UserDto userInfo(String userId) throws SQLException;
	void saveRefreshToken(Map<String, String> map) throws SQLException;
	Object getRefreshToken(String userid) throws SQLException;
	void deleteRefreshToken(Map<String, String> map) throws SQLException;

	void newPassword(@Param("userId") String userId, @Param("pwd") String pwd) throws SQLException;
	
	/* Admin */
	List<UserDto> listMember(Map<String, Object> map) throws SQLException;
	UserDto getMember(String userId) throws SQLException;
	void updateMember(UserDto memberDto) throws SQLException;
	
	 // 유저 필드 업데이트
    int updateUserField(@Param("userId") String userId, @Param("column") String column, @Param("value") String value);
    int updateEmail(@Param("userId") String userId, @Param("emailId") String emailId, @Param("emailDomain") String emailDomain);
	
    // 유저 삭제
    int deleteMember(String userId) throws SQLException;
}
