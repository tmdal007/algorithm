package com.ssafy.attraction.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ssafy.attraction.model.*;
import com.ssafy.like.model.LikeDto;
import org.springframework.stereotype.Service;

import com.ssafy.attraction.model.mapper.AttractionMapper;

@Service
public class AttractionServiceImpl implements AttractionService {

    private final AttractionMapper attractionMapper;

    public AttractionServiceImpl(AttractionMapper attractionMapper) {
        this.attractionMapper = attractionMapper;
    }

    @Override
    public List<AttractionInfoDto> attractionList(AttractionInfoDto attractionInfoDto) throws Exception {
        Map<String, Object> map = new HashMap<>();
        map.put("sidoCode", attractionInfoDto.getSidoCode());
        map.put("sigunguCode", attractionInfoDto.getSigunguCode());
        map.put("contentTypeId", attractionInfoDto.getContentTypeId());
        map.put("title", attractionInfoDto.getTitle() != null ? attractionInfoDto.getTitle() : ""); // Null 처리

        // userId가 null이면 찜 데이터를 제외하고 조회
        if (attractionInfoDto.getUserId() == null) {
            return attractionMapper.getAttractionsWithoutLikes(map);
        }

        // userId가 존재하면 찜 데이터를 포함하여 조회
        map.put("userId", attractionInfoDto.getUserId());
        return attractionMapper.attractionList(map);
    }

    @Override
    public List<GugunDto> gugunList(int sidoCode) throws Exception {
        return attractionMapper.gugunList(sidoCode);
    }

    @Override
    public List<SidoDto> sidoList() throws Exception {
        return attractionMapper.sidoList();
    }

@   Override
    public List<AttractionTypeDto> attractionTypeList() throws Exception{
        return attractionMapper.attractionTypeList();
    }

    @Override
    public AttractionInfoDto getAttraction(int contentId) throws Exception {
        return attractionMapper.getAttraction(contentId);
    }

    @Override
    public AttractionInfoDto getAttractionNo(int attractionNo) throws Exception{
        return attractionMapper.getAttractionNo(attractionNo);
    }
    @Override
    public AttractionDescriptionDto getOverview(int contentId) throws Exception {
        String overview = attractionMapper.getOverview(contentId);
        return new AttractionDescriptionDto(contentId, "Attraction Overview", overview, "Additional Details");
    }
}
