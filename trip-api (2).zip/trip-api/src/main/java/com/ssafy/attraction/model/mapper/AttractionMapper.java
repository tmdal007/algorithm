package com.ssafy.attraction.model.mapper;

import java.sql.SQLException;

import java.util.List;
import java.util.Map;

import com.ssafy.attraction.model.AttractionTypeDto;
import org.apache.ibatis.annotations.Mapper;

import com.ssafy.attraction.model.AttractionInfoDto;
import com.ssafy.attraction.model.GugunDto;
import com.ssafy.attraction.model.SidoDto;

@Mapper
public interface AttractionMapper {
	
	List<AttractionInfoDto> attractionList(Map<String, Object> map) throws SQLException;
	List<AttractionInfoDto> getAttractionsWithoutLikes(Map<String, Object> map) throws SQLException;
	List<GugunDto> gugunList(int sidoCode) throws SQLException;
	List<SidoDto> sidoList() throws SQLException;
	List<AttractionTypeDto> attractionTypeList() throws SQLException;
	AttractionInfoDto getAttraction(int contentId) throws SQLException;
	AttractionInfoDto getAttractionNo(int attractionNo) throws SQLException;
	String getOverview(int contentId) throws SQLException;
}
