package com.ssafy.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

//Swagger-UI 확인
//http://localhost/swagger-ui.html

@Configuration
public class SwaggerConfiguration {

	@Bean
	public OpenAPI openAPI() {
		Info info = new Info().title("EnjoyTrip 명세서").description(
				"<h3>여행 웹서비스 프로젝트</h3>Swagger를 이용한 EnjoyTrip 프로젝트 명세서 작성<br><img src=\"/assets/img/ssafy_logo.png\" width=\"150\">")
				.version("v1").contact(new io.swagger.v3.oas.models.info.Contact().name("곽승미, 김경은")
						.url("https://lab.ssafy.com/tmdal25680/trip_spring"));

		return new OpenAPI().components(new Components()).info(info);
	}
	
	@Bean
	public GroupedOpenApi boardApi() {
		return GroupedOpenApi.builder().group("ssafy-board").pathsToMatch("/board/**").build();
	}
	@Bean
	public GroupedOpenApi likeApi() {
		return GroupedOpenApi.builder().group("ssafy-like").pathsToMatch("/like/**").build();
	}
	@Bean
	public GroupedOpenApi adminApi() {
		return GroupedOpenApi.builder().group("ssafy-admin").pathsToMatch("/admin/**").build();
	}

	@Bean
	public GroupedOpenApi userApi() {
		return GroupedOpenApi.builder().group("ssafy-user").pathsToMatch("/user/**").build();
	}

}