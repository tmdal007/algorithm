package com.ssafy.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

import java.io.File;

/**
 * 서버 시작 시 업로드 디렉토리를 생성하는 클래스.
 */
@Component
public class UploadDirInitializer {

    @Value("${file.upload-dir}") // application.properties에서 업로드 디렉토리 경로 가져오기
    private String uploadDir;

    @PostConstruct
    public void createUploadDir() {
        File dir = new File(uploadDir);
        if (!dir.exists()) {
            dir.mkdirs(); // 디렉토리 생성
            System.out.println("업로드 디렉토리 생성 완료: " + uploadDir);
        } else {
            System.out.println("업로드 디렉토리가 이미 존재합니다: " + uploadDir);
        }
    }
}
