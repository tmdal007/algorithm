package com.ssafy.post.model.service;

import com.ssafy.post.model.CommentDto;

import java.util.List;

public interface CommentService {
    List<CommentDto> getCommentsByPost(int postNo); // 특정 후기에 대한 모든 댓글 조회
    void addComment(CommentDto commentDto); // 댓글 등록
    void editComment(CommentDto commentDto); // 댓글 수정
    void removeComment(int commentNo); // 댓글 삭제
    List<CommentDto> getCommentsByUser(String userId); // 특정 사용자가 작성한 댓글 조회
    String getCommentAuthor(int commentNo); // 댓글 작성자 조회
}
