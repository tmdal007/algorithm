package com.ssafy.post.controller;

import com.ssafy.config.Result;
import com.ssafy.post.model.PostDto;
import com.ssafy.post.model.service.PostService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.ServletContext;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@RestController
@RequestMapping("/posts")
@Tag(name = "PostController", description = "여행 후기 관리 API")
public class PostController {

    private final PostService postService;
    private ServletContext servletContext;

    public PostController(ServletContext servletContext, PostService postService) {
    	this.servletContext = servletContext;
        this.postService = postService;
    }
    
//    @PostMapping("/write")
//    public ResponseEntity<?> write(@RequestBody PostDto postDto) {
//        log.debug("PostDto ======> {}", postDto);
//        try {
//            postService.write(postDto);
//            return ResponseEntity.ok(postDto.getPostNo()); // postNo만 반환
//        } catch (Exception e) {
//            log.error("write 실패", e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                                 .body(new Result("fail", "파일 제외 핫플 write 실패"));
//        }
//    }
    
    @PostMapping("/write")
    public ResponseEntity<Integer> writeReview(@RequestBody PostDto postDto) {
        try {
            int postNo = postService.createPost(postDto); // 삽입 후 생성된 postNo 가져오기
            System.out.println("생성된 postNo: " + postNo); // 디버깅용
            log.debug("생성된 postNo!!!!!!--->", postNo );
            return ResponseEntity.ok(postNo); // postNo 반환
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(0); // 실패 시 0 반환
        }
    }


    
    @Value("${file.upload-dir}") // application.properties에서 file.upload-dir 값을 가져옴
    private String uploadDir;

    @PostMapping("/write/file")
    public ResponseEntity<?> writeFile(
            @RequestParam("postNo") int postNo,
            @RequestParam("upfile") MultipartFile file) {
        log.debug("파일 업로드 요청: postNo={}, 파일={}", postNo, file.getOriginalFilename());

        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(new Result("fail", "파일이 없습니다."));
        }

        try {
            // 오늘 날짜 폴더 생성
            String today = new SimpleDateFormat("yyMMdd").format(new Date());
            String saveFolder = uploadDir + File.separator + today;

            File folder = new File(saveFolder);
            if (!folder.exists()) {
                boolean created = folder.mkdirs();
                log.debug("폴더 생성 여부: {}", created);
            }

            // 파일 이름 생성
            String originalFileName = file.getOriginalFilename();
            String fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
            String saveFileName = UUID.randomUUID().toString() + fileExtension;

            // 파일 저장
            File saveFile = new File(folder, saveFileName);
            file.transferTo(saveFile);
            log.debug("파일 저장 경로: {}", saveFile.getAbsolutePath());

            // DB에 저장할 데이터 준비
            Map<String, Object> params = new HashMap<>();
            params.put("postNo", postNo);
            params.put("saveFolder", today);
            params.put("saveFile", saveFileName);
            params.put("originalFile", originalFileName);

            postService.writeFile(params); // 파일 정보를 DB에 저장
            return ResponseEntity.ok(new Result("success", "파일 업로드 성공"));
        } catch (Exception e) {
            log.error("파일 업로드 중 오류", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Result("fail", "파일 업로드 실패"));
        }
    }


    
//    @PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
//    public ResponseEntity<?> createPost(
//    		@RequestPart("post") PostDto postDto,
//            @RequestPart(value = "files", required = false) List<MultipartFile> files) {
//        log.info("후기글 쓰기!!!!-{}", postDto);
//
//        try {
//            // 파일 저장 로직
//            if (files != null && !files.isEmpty()) {
//                for (MultipartFile file : files) {
//                    // 파일 처리 로직 추가 (예: 저장 폴더, DB 기록 등)
//                    log.info("Uploaded file: {}", file.getOriginalFilename());
//                }
//            }
//            postService.createPost(postDto);
//            return new ResponseEntity<>("여행 후기가 작성되었습니다.", HttpStatus.CREATED);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new ResponseEntity<>("여행 후기 작성 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }




    @Operation(summary = "여행 후기 수정", description = "여행 후기를 수정합니다.")
    @PutMapping
    public ResponseEntity<String> updatePost(
    		@RequestBody @Parameter(description = "수정 후기글 정보.", required = true) PostDto postDto) {
        postService.updatePost(postDto);
        return new ResponseEntity<>("여행 후기가 수정되었습니다.", HttpStatus.OK);
    }

    @Operation(summary = "여행 후기 삭제", description = "여행 후기를 삭제합니다.")
    @DeleteMapping("/{postNo}")
    public ResponseEntity<String> deletePost(@PathVariable int postNo) {
        postService.deletePost(postNo);
        return new ResponseEntity<>("여행 후기가 삭제되었습니다.", HttpStatus.OK);
    }

    @Operation(summary = "전체 여행 후기 조회", description = "전체 여행 후기를 조회합니다.")
    @GetMapping
    public ResponseEntity<List<PostDto>> getAllPosts() {
        List<PostDto> posts = postService.getAllPosts();
        log.debug("여행 후기 요!----------->",posts);
        return new ResponseEntity<>(posts, HttpStatus.OK);
    }

    @Operation(summary = "특정 유저 여행 후기 조회", description = "특정 유저의 여행 후기를 조회합니다.")
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<PostDto>> getPostsByUser(@PathVariable String userId) {
        List<PostDto> posts = postService.getPostsByUser(userId);
        return new ResponseEntity<>(posts, HttpStatus.OK);
    }

    @Operation(summary = "조회수 증가", description = "특정 여행 후기의 조회수를 증가시킵니다.")
    @PatchMapping("/{postNo}/hit")
    public ResponseEntity<String> updateHit(@PathVariable int postNo) {
        postService.updateHit(postNo);
        return new ResponseEntity<>("조회수가 증가되었습니다.", HttpStatus.OK);
    }

    @Operation(summary = "조회수 기준 후기 조회", description = "조회수가 많은 순서대로 여행 후기를 조회합니다.")
    @GetMapping("/top-hits")
    public ResponseEntity<List<PostDto>> getTopHitsPosts() {
        List<PostDto> posts = postService.getTopHitsPosts();
        return new ResponseEntity<>(posts, HttpStatus.OK);
    }
    
    @Operation(summary = "특정 여행 후기 조회", description = "postNo로 특정 여행 후기를 조회합니다.")
    @GetMapping("/{postNo}")
    public ResponseEntity<PostDto> getPostById(@PathVariable int postNo) {
        PostDto post = postService.getPostById(postNo);
        if (post != null) {
            return new ResponseEntity<>(post, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


}
