package com.ssafy.post.controller;

import com.ssafy.post.model.CommentDto;
import com.ssafy.post.model.service.CommentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comments")
@Tag(name = "CommentController", description = "댓글 관리 API")
public class CommentController {

    private final CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @Operation(summary = "댓글 목록 조회", description = "특정 후기에 대한 모든 댓글을 조회합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "댓글 목록 조회 성공")
    })
    @GetMapping("/post/{postNo}")
    public ResponseEntity<List<CommentDto>> getCommentsByPost(@PathVariable int postNo) {
        List<CommentDto> comments = commentService.getCommentsByPost(postNo);
        return ResponseEntity.ok(comments);
    }

    @Operation(summary = "댓글 등록", description = "새로운 댓글을 작성합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "댓글 등록 성공")
    })
    @PostMapping
    public ResponseEntity<?> addComment(@RequestBody CommentDto commentDto) {
        commentService.addComment(commentDto);
        return new ResponseEntity<>("댓글 등록 성공", HttpStatus.CREATED);
    }

    @Operation(summary = "댓글 수정", description = "특정 댓글을 수정합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "댓글 수정 성공")
    })
    @PutMapping("/{commentNo}")
    public ResponseEntity<?> editComment(@PathVariable int commentNo, @RequestBody CommentDto commentDto) {
        commentDto.setCommentNo(commentNo);
        commentService.editComment(commentDto);
        return ResponseEntity.ok("댓글 수정 성공");
    }

    @Operation(summary = "댓글 삭제", description = "특정 댓글을 삭제합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "댓글 삭제 성공")
    })
    @DeleteMapping("/{commentNo}")
    public ResponseEntity<?> removeComment(@PathVariable int commentNo) {
        commentService.removeComment(commentNo);
        return ResponseEntity.ok("댓글 삭제 성공");
    }

    @Operation(summary = "유저 댓글 목록 조회", description = "특정 사용자가 작성한 댓글 목록을 조회합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "유저 댓글 목록 조회 성공")
    })
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<CommentDto>> getCommentsByUser(@PathVariable String userId) {
        List<CommentDto> comments = commentService.getCommentsByUser(userId);
        return ResponseEntity.ok(comments);
    }

    @Operation(summary = "댓글 작성자 조회", description = "특정 댓글의 작성자를 조회합니다.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "댓글 작성자 조회 성공")
    })
    @GetMapping("/author/{commentNo}")
    public ResponseEntity<String> getCommentAuthor(@PathVariable int commentNo) {
        String author = commentService.getCommentAuthor(commentNo);
        return ResponseEntity.ok(author);
    }
}
