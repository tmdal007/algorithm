package com.ssafy.post.model.service;

import com.ssafy.post.controller.PostController;
import com.ssafy.post.model.FileInfoDto;
import com.ssafy.post.model.PostDto;
import com.ssafy.post.model.mapper.PostMapper;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
@Slf4j
@Service
public class PostServiceImpl implements PostService {

    private final PostMapper postMapper;

    public PostServiceImpl(PostMapper postMapper) {
        this.postMapper = postMapper;
    }
    
	@Override
	@Transactional
	public void write(PostDto postDto) throws Exception {
		postMapper.write(postDto);
	}
	
	@Override
	public void writeFile(Map<String, Object> params) throws Exception{
		postMapper.writeFile(params);
	}

    @Override
    public void deletePost(int postNo) {
        postMapper.deletePost(postNo);
    }

    @Override
    public List<PostDto> getAllPosts() {
        return postMapper.getAllPosts();
    }

    @Override
    public List<PostDto> getPostsByUser(String userId) {
        return postMapper.getPostsByUser(userId);
    }

    @Override
    public void updateHit(int postNo) {
        postMapper.updateHit(postNo);
    }

    @Override
    public List<PostDto> getTopHitsPosts() {
        return postMapper.selectTopHitsPosts();
    }

	@Override
	public void updatePost(PostDto postDto) {
		postMapper.updatePost(postDto);
		
	}

	@Override
	public int createPost(PostDto postDto) {
        postMapper.createPost(postDto);
        return postDto.getPostNo(); // MyBatis의 selectKey로 설정된 postNo 가져오기
    }

	@Override
	public PostDto getPostById(int postNo) {
		return postMapper.getPostById(postNo);
	}
	


}
