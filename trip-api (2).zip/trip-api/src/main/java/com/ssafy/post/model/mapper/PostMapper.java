package com.ssafy.post.model.mapper;

import com.ssafy.post.model.FileInfoDto;
import com.ssafy.post.model.PostDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface PostMapper {
    int createPost(PostDto postDto);
    
    void saveFileInfo(FileInfoDto fileInfo);
    
    void updatePost(PostDto postDto);
    
    void deletePost(int postNo);
    
    List<PostDto> getAllPosts();
    
    List<PostDto> getPostsByUser(@Param("userId") String userId);
    
    void updateHit(int postNo);
    
    List<PostDto> selectTopHitsPosts();
    
	void registerFile(PostDto postDto);
	
	List<FileInfoDto> fileInfoList(int postNo) throws Exception;

	void write(PostDto postDto);

	void writeFile(Map<String, Object> params);

	PostDto getPostById(int postNo);

}
