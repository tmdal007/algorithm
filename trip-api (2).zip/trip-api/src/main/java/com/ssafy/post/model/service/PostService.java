package com.ssafy.post.model.service;

import com.ssafy.post.model.PostDto;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface PostService {
    int createPost(PostDto postDto);
    void updatePost(PostDto postDto);
    void deletePost(int postNo);
    List<PostDto> getAllPosts();
    List<PostDto> getPostsByUser(String userId);
    void updateHit(int postNo);
    List<PostDto> getTopHitsPosts();
	void write(PostDto postDto) throws Exception;
	void writeFile(Map<String, Object> params) throws Exception;
	PostDto getPostById(int postNo);

}
