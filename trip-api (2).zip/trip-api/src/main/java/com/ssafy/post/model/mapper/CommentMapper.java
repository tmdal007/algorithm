package com.ssafy.post.model.mapper;

import com.ssafy.post.model.CommentDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommentMapper {
    List<CommentDto> getCommentsByPost(int postNo); // 특정 후기에 대한 모든 댓글 조회
    void insertComment(CommentDto commentDto); // 댓글 등록
    void updateComment(CommentDto commentDto); // 댓글 수정
    void deleteComment(int commentNo); // 댓글 삭제
    List<CommentDto> getCommentsByUser(String userId); // 특정 사용자가 작성한 댓글 조회
    String getCommentAuthor(int commentNo); // 댓글 작성자 조회
}
