package com.ssafy.post.model;

import java.sql.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PostDto {
	private int postNo;
	private int planNo;
	private String content;
	private int score;
	private int person;
	private int money;
	private Date register; //작성일
	private int hit; // 조회수
	private String userId;
    private String saveFolder;
    private String originalFile;
    private String saveFile;
}
