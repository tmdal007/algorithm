package com.ssafy.chatbot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/chat")
public class ChatbotController {

    @Autowired
    private ChatbotService chatbotService;

    @PutMapping
    public String chat(@RequestBody Map<String, String> request) {
        String userMessage = request.get("message");
        if (userMessage == null || userMessage.trim().isEmpty()) {
            return "Error: Message is empty.";
        }

        System.out.println("Received message: " + userMessage); // 로그 출력
        return chatbotService.getChatbotResponse(userMessage);
    }

}
