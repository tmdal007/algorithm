package com.ssafy.like.model.service;

import java.util.List;

import com.ssafy.attraction.model.AttractionInfoDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.like.model.DetailDto;
import com.ssafy.like.model.LikeDto;
import com.ssafy.like.model.mapper.LikeMapper;

import lombok.RequiredArgsConstructor;

@Service
public class LikeServiceImpl implements LikeService {

    private final LikeMapper likeMapper;
    
    public LikeServiceImpl(LikeMapper likeMapper) {
    	this.likeMapper = likeMapper;
    }

    // 찜한 관광지 추가
    @Transactional
    @Override
    public void insertLike(LikeDto likeDto) {
        likeMapper.insertLikeAttraction(likeDto);
    }

    // 찜한 관광지 목록 조회
    @Override
    public List<AttractionInfoDto> getLikeList(String userId) {

//        List<AttractionInfoDto> likeList = likeMapper.getLikeList(userId);
//        System.out.println("==============================================");
//        for (int i = 0; i <likeList.size(); i++) {
//            System.out.println(
//                    "service get("+i+") :::: "+likeList.get(i).toString()
//            );
//        }
//        System.out.println("==============================================");

        return likeMapper.getLikeList(userId);
    }

    // 관광지 상세 조회
    @Override
    public DetailDto getLikeById(String contentId) {
        return likeMapper.getLikeById(contentId);
    }

    // 찜한 관광지 상세 조회
    @Override
    public LikeDto getLikeByNo(int listNo) {
        return likeMapper.getLikeByNo(listNo);
    }

    // 찜한 관광지 삭제
    @Override
    public void deleteLikeAttraction(LikeDto likeDto) {
        likeMapper.deleteLikeAttraction(likeDto);
    }

    // 특정 제목의 관광지 존재 여부 확인
    @Override
    public boolean existsByTitle(String title) {
        return likeMapper.existsByTitle(title);
    }
}