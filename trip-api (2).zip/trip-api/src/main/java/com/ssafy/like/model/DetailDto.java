package com.ssafy.like.model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class DetailDto {
    private int no;                     // no
    private String contentId;           // content_id
    private String title;               // title
    private String contentTypeId;       // content_type_id
    private String areaCode;            // area_code
    private String siGunGuCode;         // si_gun_gu_code
    private String firstImage1;         // first_image1
    private String firstImage2;         // first_image2
    private int mapLevel;               // map_level
    private double latitude;             // latitude
    private double longitude;            // longitude
    private String tel;                  // tel
    private String addr1;                // addr1
    private String addr2;                // addr2
    private String homepage;             // homepage
    private String overview;             // overview

}
