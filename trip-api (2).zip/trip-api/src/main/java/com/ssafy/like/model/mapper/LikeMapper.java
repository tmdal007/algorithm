package com.ssafy.like.model.mapper;

import java.util.List;

import com.ssafy.attraction.model.AttractionInfoDto;
import com.ssafy.like.model.DetailDto;
import com.ssafy.like.model.LikeDto;

public interface LikeMapper {

	void insertLikeAttraction(LikeDto likeDto);

	void deleteLikeAttraction(LikeDto likeDto);

	void insertLikePost(LikeDto likeDto);

	List<AttractionInfoDto> getLikeList(String userId);

	DetailDto getLikeById(String contentId);

	LikeDto getLikeByNo(int listNo);

//	int deleteLike(int listNo);

	boolean existsByTitle(String title);


}
